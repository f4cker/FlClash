#!/bin/bash
set -euo pipefail
ROOT=/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup
cd "$ROOT"
export PATH="$ROOT/.airbuild/tools/fixed-candidate-xcrun-bin:$HOME/.cargo/bin:$HOME/fvm/versions/3.47.4/bin:/opt/homebrew/bin:$PATH"
EVIDENCE="$ROOT/.airbuild/buildcandidate/fixed-identity-2026111301-recovery-attempt02"
DEST="$ROOT/.airbuild/artifacts/fixed-identity-2026111301/Flash.app"
APP="$ROOT/build/macos/Build/Products/Release/Flash.app"
[[ ! -e "$DEST" ]]
exec > >(tee "$EVIDENCE/completion.log") 2>&1
trap 'result=$?; printf "completion_exit=%s\ncompleted_utc=%s\n" "$result" "$(date -u +%FT%TZ)" > "$EVIDENCE/completion-result.txt"; exit "$result"' EXIT
python3 - "$EVIDENCE" <<'VERIFY'
import base64
import json
import plistlib
from pathlib import Path
import subprocess
import sys
e = Path(sys.argv[1])
settings = json.loads((e / 'effective-xcode-settings.json').read_text())
runner = next(item['buildSettings'] for item in settings if item['target'] == 'Runner')
assert runner['FC_MANAGED_CANDIDATE_ENABLED'] == '1'
assert 'FC_MANAGED_CANDIDATE_ENABLED=1' in runner['GCC_PREPROCESSOR_DEFINITIONS'].split()
assert runner['CODE_SIGNING_ALLOWED'] == 'NO'
info = plistlib.loads(Path('build/macos/Build/Products/Release/Flash.app/Contents/Info.plist').read_bytes())
defines = [base64.b64decode(value).decode() for value in info['FlashDartDefines'].split(',') if value]
assert defines.count('MACOS_MANAGED_HELPER=true') == 1
(e / 'sealed-dart-defines.json').write_text(json.dumps(defines, indent=2) + '\n')
log = (e / 'native-clang-traces.txt').read_text()
for name in ('Supervisor.m', 'Maintenance.m'):
    assert any('clang' in line and '-DFC_MANAGED_CANDIDATE_ENABLED=1' in line and name in line for line in log.splitlines()), name
responses = []
for path in Path('build/macos/Build/Intermediates.noindex/Runner.build/Release/Runner.build').rglob('*.resp'):
    text = path.read_text()
    if '-DFC_MANAGED_CANDIDATE_ENABLED=1' in text:
        responses.append({'path': str(path), 'contents': text})
assert responses, 'Runner actual compile response with candidate macro missing'
(e / 'runner-compile-responses.json').write_text(json.dumps(responses, indent=2) + '\n')
(e / 'native-clang-traces.txt').write_text('\n'.join(line for line in log.splitlines() if 'clang' in line) + '\n')
(e / 'build-metadata.json').write_bytes((e / 'build-contract.json').read_bytes())
VERIFY
chmod 600 "$EVIDENCE/build-metadata.json"
SNAPSHOT_PHASE=after
python3 - "$EVIDENCE" "$SNAPSHOT_PHASE" <<'SNAPSHOT'
import hashlib
import json
from pathlib import Path
import subprocess
import sys
e, phase = Path(sys.argv[1]), sys.argv[2]
files = subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0')
fixed_packaging = {'macos/packaging/stage_managed_helper.sh', 'macos/packaging/stage_managed_payload.py', 'macos/packaging/candidate_policy.md'}
inputs = {}
for name in files:
    if not name or not (name.startswith(('lib/', 'macos/', 'plugins/', 'core/', 'assets/', 'arb/')) or name in ('pubspec.yaml', 'pubspec.lock', 'env.json', 'build_config.yaml', 'build.yaml')):
        continue
    if name.startswith('macos/packaging/') and name not in fixed_packaging:
        continue
    p = Path(name)
    if p.is_file():
        inputs[name] = hashlib.sha256(p.read_bytes()).hexdigest()
    elif p.is_symlink():
        inputs[name] = 'symlink:' + str(p.readlink())
(e / ('app-input-hashes-' + phase + '.json')).write_text(json.dumps(inputs, sort_keys=True, indent=2) + '\n')
if phase == 'after':
    assert inputs == json.loads((e / 'app-input-hashes-before.json').read_text()), 'Application build source inputs changed during compile'
SNAPSHOT
python3 macos/packaging/stage_managed_payload.py "$APP" "$DEST"
python3 macos/packaging/stage_managed_payload.py --verify "$DEST"
python3 - "$DEST" "$EVIDENCE" <<'PY'
import hashlib
import json
from pathlib import Path
import subprocess
import sys
app, evidence = map(Path, sys.argv[1:])
files = []
macho = {bytes.fromhex(value) for value in ('feedface', 'cefaedfe', 'feedfacf', 'cffaedfe', 'cafebabe', 'bebafeca', 'cafebabf', 'bfbafeca')}
for path in sorted(app.rglob('*')):
    if path.is_symlink():
        files.append({'path': str(path.relative_to(app)), 'symlink': path.readlink().as_posix()})
    elif path.is_file():
        data = path.read_bytes()
        item = {'path': str(path.relative_to(app)), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
        if data[:4] in macho:
            item['architectures'] = subprocess.check_output(['/usr/bin/lipo', '-archs', str(path)], text=True).strip().split()
        files.append(item)
(evidence / 'candidate-file-manifest.json').write_text(json.dumps(files, indent=2) + '\n')
print('Staged unsigned managed candidate; static load-boundary evidence only; no production executable run.')
PY
[[ ! -f .dart_tool/setup_build_cache/hook.log ]] || cp .dart_tool/setup_build_cache/hook.log "$EVIDENCE/setup-hook.log"
: # Source compile inputs are compared by their independently recorded hashes below.
git rev-parse HEAD > "$EVIDENCE/source-head-after.txt"
git status --short > "$EVIDENCE/source-status-after.txt"
shasum -a 256 "$DEST/Contents/MacOS/Flash" "$DEST/Contents/MacOS/FlClashCore" \
  "$DEST/Contents/Library/HelperTools/FlashHelper" "$DEST/Contents/Library/HelperTools/FlashMaintenance" \
  "$EVIDENCE/candidate-file-manifest.json" | tee "$EVIDENCE/sha256.txt"
printf 'STAGED_CANDIDATE=%s\n' "$DEST"
