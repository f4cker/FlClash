#!/bin/bash
# One-off packages-03 for 0.9.7+2026111303. Same flow as the pinned macos/packaging/build_split_packages.sh
# (unchanged), except: (1) the service copy is published with CodeResources 0644 so the non-root GUI can
# read the installed helper's seal; (2) the DMG uses the confirmed styled layout. No signing, no install.
set -euo pipefail
umask 077
ROOT=/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup
cd "$ROOT"
A="$ROOT/.airbuild/artifacts/split-2026111303-retry01"
B="$ROOT/.airbuild/buildcandidate/split-2026111303"
source_dir="$ROOT/macos/packaging"
gui="$A/gui/Flash.app"
service="$A/service/Flash.app"
output="$A/packages-03"
[[ ! -e "$output" && ! -L "$output" ]] || exit 78
python() { /usr/bin/env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C /usr/bin/python3 -I -S -B "$@"; }
split() { python "$source_dir/stage_split_payload.py" "$@"; }
publish() { python "$ROOT/.airbuild/tools/split-packages-03-publish.py" "$@"; }
raw_package() { python "$source_dir/normalize_package_info.py" "$@"; }
verify_evidence() {
  split verify-qualification --gui "$gui" --service "$service" \
    --evidence "$ROOT/.airbuild/evidence/split-native-load-qualification/split-2026111303-retry01-user2903.json" \
    --build-metadata "$B/continuation-04/build-metadata.json" \
    --service-compile-receipt "$A/service-compile/servicecompile-receipt.json" \
    --service-compile-sha256 15a9d3fac6b0bd69b0ec62029bc614311f42b1fdafa4b813e868184c9a07630d \
    --service-signing-receipt "$A/service/Flash.service-signing-static.json" \
    --service-signing-sha256 b469587073387d16b305a3fd8323efb0486e8c9d2a906368c2164153ab9f1764 \
    --tooling-delta "$B/service-continuation-01/tooling-delta-02.json" \
    --tooling-delta-sha256 fa07eca14cdef7d992f7b7d1baa300d55c4ac14cb709f4bc9dffe64180889a87
}
verify_evidence
/bin/mkdir -m 0700 "$output"
work="$output/payload"
/bin/mkdir -p "$work/Library/Application Support/Flash/.incoming"
/usr/bin/ditto "$service" "$work/Library/Application Support/Flash/.incoming/Flash.app"
publish publish "$service" "$work/Library/Application Support/Flash/.incoming/Flash.app"
components="$output/components.plist"
/usr/bin/pkgbuild --analyze --root "$work" "$components"
python "$source_dir/pin_component_policy.py" "$components"
for operation in install repair disable remove; do
  scripts="$output/$operation-scripts"
  /bin/mkdir "$scripts"
  /bin/cp "$source_dir/installer/$operation/"* "$scripts/"
  /bin/cp "$service/Contents/Library/HelperTools/FlashMaintenance" "$scripts/FlashMaintenance"
  /bin/chmod 0755 "$scripts/"*
  built="$output/$operation-built.pkg"
  package="$output/Flash-helper-$operation.pkg"
  if [[ "$operation" == install || "$operation" == repair ]]; then
    /usr/bin/pkgbuild --root "$work" --component-plist "$components" --ownership recommended --scripts "$scripts" \
      --identifier "com.layoute.flash.managed.$operation" --install-location / "$built"
  else
    /usr/bin/pkgbuild --nopayload --scripts "$scripts" --install-location / \
      --identifier "com.layoute.flash.managed.$operation" "$built"
  fi
  raw="$output/$operation-raw"
  snapshot="$output/$operation-raw-members.json"
  /bin/mkdir "$raw"
  /usr/bin/xar -xf "$built" -C "$raw"
  raw_package normalize "$raw" "$snapshot" "$operation"
  raw_package verify "$raw" "$snapshot" "$operation"
  (cd "$raw" && /usr/bin/xar -cf "$package" --compression=none *)
  final_raw="$output/$operation-final-raw"
  /bin/mkdir "$final_raw"
  /usr/bin/xar -xf "$package" -C "$final_raw"
  raw_package verify "$final_raw" "$snapshot" "$operation"
  expanded="$output/$operation-expanded"
  /usr/sbin/pkgutil --expand-full "$package" "$expanded"
  publish verify-expanded "$service" "$expanded" "$operation"
  if [[ "$operation" == install || "$operation" == repair ]]; then
    seal="$expanded/Payload/Library/Application Support/Flash/.incoming/Flash.app/Contents/_CodeSignature/CodeResources"
    /bin/ls -l "$seal"
    lsbom -p MUGf "$raw/Bom" | /usr/bin/grep "_CodeSignature/CodeResources$"
  fi
  verify_evidence
done
dmg_root="$output/dmg-root"
/bin/mkdir "$dmg_root"
/usr/bin/ditto "$gui" "$dmg_root/Flash.app"
split verify-copy --kind gui --original "$gui" --copy "$dmg_root/Flash.app"
verify_evidence
"$ROOT/tool/macos/make_styled_dmg.sh" "$dmg_root/Flash.app" "$output/Flash.dmg"
verify_evidence
for f in Flash.dmg Flash-helper-install.pkg Flash-helper-repair.pkg Flash-helper-disable.pkg Flash-helper-remove.pkg; do
  /usr/bin/shasum -a 256 "$output/$f"
done
echo 'PACKAGES_03_BUILT: service seal published 0644, styled DMG; installation remains unverified.'
