#!/bin/bash
set -euo pipefail
ROOT=/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup
cd "$ROOT"
export PATH="$HOME/.cargo/bin:$HOME/fvm/versions/3.47.4/bin:/opt/homebrew/bin:$PATH"
export GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local CARGO_NET_OFFLINE=true
export FLUTTER_SUPPRESS_ANALYTICS=true DART_SUPPRESS_ANALYTICS=true COCOAPODS_DISABLE_STATS=true
export FLUTTER_MACOS_ARM64_ONLY=true FLUTTER_XCODE_CODE_SIGNING_ALLOWED=NO
BUILD=2026111301
EVIDENCE="$ROOT/.airbuild/buildcandidate/fixed-identity-$BUILD"
DEST="$ROOT/.airbuild/artifacts/fixed-identity-$BUILD/Flash.app"
APP="$ROOT/build/macos/Build/Products/Release/Flash.app"
mkdir -p "$EVIDENCE"
[[ ! -e "$DEST" && ! -e "$EVIDENCE/build.started" ]]
touch "$EVIDENCE/build.started"
exec > >(tee "$EVIDENCE/build.log") 2>&1
trap 'result=$?; printf "build_exit=%s\ncompleted_utc=%s\n" "$result" "$(date -u +%FT%TZ)" > "$EVIDENCE/build-result.txt"; exit "$result"' EXIT
printf 'started_utc=%s\n' "$(date -u +%FT%TZ)"
git rev-parse HEAD > "$EVIDENCE/source-head.txt"
git status --short > "$EVIDENCE/source-status-before.txt"
git diff HEAD --binary > "$EVIDENCE/source-diff-before.patch"
git submodule status --recursive > "$EVIDENCE/submodules.txt"
{
  flutter --version
  go version
  cargo --version
  rustc --version
  rustup toolchain list
  xcodebuild -version
  xcrun clang --version
  printf 'flutter_path=%s\ngo_path=%s\ncargo_path=%s\n' "$(command -v flutter)" "$(command -v go)" "$(command -v cargo)"
} > "$EVIDENCE/toolchains.txt"
python3 - "$EVIDENCE" <<'PY'
import json
from pathlib import Path
import sys
root = Path.cwd()
identity = (root / 'macos/Shared/HelperIdentity.h').read_text()
assert '#define FC_PINNED_CERTIFICATE_SHA1 "BBA7F8529FD271B9848EC03A2CE3F4780F585556"' in identity
assert '#define FC_PRODUCTION_TEAM_ID ""' in identity
assert '#define FC_MANAGED_GUI_LOADS_VERIFIED 0' in identity
spec = (root / 'pubspec.yaml').read_text()
assert 'version: 0.9.7+2026111301' in spec
assert spec.count('build_assets: true') == 2
assert 'build_assets: false' not in spec
assert "bool.fromEnvironment('MACOS_MANAGED_HELPER')" in (root / 'lib/core/desktop/macos_helper_client.dart').read_text()
assert json.loads((root / 'env.json').read_text()) == {'APP_ENV': 'stable'}
(Path(sys.argv[1]) / 'build-contract.json').write_text(json.dumps({
    'version': '0.9.7', 'build_number': '2026111301',
    'defines': {'APP_ENV': 'stable', 'MACOS_MANAGED_HELPER': True},
    'certificate_sha1': 'BBA7F8529FD271B9848EC03A2CE3F4780F585556',
    'apple_team': '', 'managed_gui_loads_verified': False,
    'dart_managed_default': False, 'core_and_rust_hooks_enabled': True,
    'network_sandbox': 'deny network*', 'xcode_code_signing_allowed': False,
    'runtime_acceptance': False,
    'installation': 'deliberately fail-closed pending actual GUI load qualification',
}, indent=2) + '\n')
PY
if [[ -d "$APP" ]]; then
  mv "$APP" "$EVIDENCE/prior-generated-Flash.app"
fi
if [[ -d .dart_tool/setup_build_cache ]]; then
  mv .dart_tool/setup_build_cache "$EVIDENCE/prior-setup-build-cache"
fi
printf '%s\n' 'COMMAND: flutter build macos --release --no-pub --dart-define-from-file=env.json --dart-define=MACOS_MANAGED_HELPER=true --build-number=2026111301'
/usr/bin/sandbox-exec -p '(version 1) (allow default) (deny network*)' \
  flutter build macos --release --no-pub --dart-define-from-file=env.json \
  --dart-define=MACOS_MANAGED_HELPER=true --build-number=2026111301
[[ "$(plutil -extract CFBundleShortVersionString raw "$APP/Contents/Info.plist")" = 0.9.7 ]]
[[ "$(plutil -extract CFBundleVersion raw "$APP/Contents/Info.plist")" = "$BUILD" ]]
[[ "$(plutil -extract CFBundleIdentifier raw "$APP/Contents/Info.plist")" = com.layoute.flash ]]
for relative in Contents/MacOS/Flash Contents/MacOS/FlClashCore Contents/Library/HelperTools/FlashHelper Contents/Library/HelperTools/FlashMaintenance; do
  [[ -f "$APP/$relative" ]]
  [[ "$(lipo -archs "$APP/$relative")" = arm64 ]]
done
go version -m "$APP/Contents/MacOS/FlClashCore" > "$EVIDENCE/core-buildinfo.txt"
python3 macos/packaging/stage_managed_payload.py "$APP" "$DEST"
python3 macos/packaging/stage_managed_payload.py --verify "$DEST"
python3 - "$DEST" "$EVIDENCE" <<'PY'
import hashlib
import json
from pathlib import Path
import subprocess
import sys
app, evidence = map(Path, sys.argv[1:])
files = []
macho = {bytes.fromhex(value) for value in ('feedface', 'cefaedfe', 'feedfacf', 'cffaedfe', 'cafebabe', 'bebafeca', 'cafebabf', 'bfbafeca')}
for path in sorted(app.rglob('*')):
    if path.is_symlink():
        files.append({'path': str(path.relative_to(app)), 'symlink': path.readlink().as_posix()})
    elif path.is_file():
        data = path.read_bytes()
        item = {'path': str(path.relative_to(app)), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
        if data[:4] in macho:
            item['architectures'] = subprocess.check_output(['/usr/bin/lipo', '-archs', str(path)], text=True).strip().split()
        files.append(item)
(evidence / 'candidate-file-manifest.json').write_text(json.dumps(files, indent=2) + '\n')
print('Staged unsigned managed candidate; static load-boundary evidence only; no production executable run.')
PY
[[ ! -f .dart_tool/setup_build_cache/hook.log ]] || cp .dart_tool/setup_build_cache/hook.log "$EVIDENCE/setup-hook.log"
git rev-parse HEAD > "$EVIDENCE/source-head-after.txt"
git status --short > "$EVIDENCE/source-status-after.txt"
shasum -a 256 "$DEST/Contents/MacOS/Flash" "$DEST/Contents/MacOS/FlClashCore" \
  "$DEST/Contents/Library/HelperTools/FlashHelper" "$DEST/Contents/Library/HelperTools/FlashMaintenance" \
  "$EVIDENCE/candidate-file-manifest.json" | tee "$EVIDENCE/sha256.txt"
printf 'STAGED_CANDIDATE=%s\n' "$DEST"
