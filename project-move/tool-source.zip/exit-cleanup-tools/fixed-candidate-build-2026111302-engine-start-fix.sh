#!/bin/bash
set -euo pipefail
umask 022
ROOT=/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup
cd "$ROOT"
export PATH="$ROOT/.airbuild/tools/fixed-candidate-xcrun-bin:$HOME/.cargo/bin:$HOME/fvm/versions/3.47.4/bin:/opt/homebrew/bin:$PATH"
export GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local CARGO_NET_OFFLINE=true
export FLUTTER_SUPPRESS_ANALYTICS=true DART_SUPPRESS_ANALYTICS=true COCOAPODS_DISABLE_STATS=true
export FLUTTER_MACOS_ARM64_ONLY=true FLUTTER_XCODE_CODE_SIGNING_ALLOWED=NO
BUILD=2026111302
EXPECTED_HEAD=f3916e4f0db354086d73080471687aba3fcd442c
EVIDENCE="$ROOT/.airbuild/buildcandidate/fixed-identity-$BUILD-engine-start-fix"
DEST="$ROOT/.airbuild/artifacts/fixed-identity-$BUILD/Flash.app"
APP="$ROOT/build/macos/Build/Products/Release/Flash.app"
[[ "$(git rev-parse HEAD)" = "$EXPECTED_HEAD" ]]
[[ -z "$(git status --porcelain)" ]]
[[ "$(shasum -a 256 pubspec.yaml | cut -d' ' -f1)" = e86dae285cb0ab0bcb3e0f10c62474cb72d98d46b5939574ff80de2fa1d35384 ]]
[[ "$(shasum -a 256 .airbuild/tools/fixed-candidate-xcrun-bin/xcrun | cut -d' ' -f1)" = 923d477e8a1e58a8c24889082c9ac8aeef28d9035093c03147b7e79fe0c92586 ]]
[[ "$(shasum -a 256 macos/packaging/stage_managed_payload.py | cut -d' ' -f1)" = 006b6d11b10d0875654fab009e7b6a231ebfb83f12cbb0a8c77ec0c463d65829 ]]
[[ ! -e "$EVIDENCE" && ! -e "$DEST" ]]
mkdir -p "$EVIDENCE"
touch "$EVIDENCE/build.started"
exec > >(tee "$EVIDENCE/build.log") 2>&1
trap 'result=$?; [[ ! -f .dart_tool/setup_build_cache/hook.log ]] || cp .dart_tool/setup_build_cache/hook.log "$EVIDENCE/setup-hook.log"; printf "build_and_stage_exit=%s\ncompleted_utc=%s\n" "$result" "$(date -u +%FT%TZ)" > "$EVIDENCE/build-result.txt"; exit "$result"' EXIT
printf 'started_utc=%s\n' "$(date -u +%FT%TZ)"
export XCODE_XCCONFIG_FILE="$EVIDENCE/candidate.xcconfig"
printf '%s\n' 'FC_MANAGED_CANDIDATE_ENABLED = 1' 'GCC_PREPROCESSOR_DEFINITIONS = $(inherited) FC_MANAGED_CANDIDATE_ENABLED=$(FC_MANAGED_CANDIDATE_ENABLED)' > "$XCODE_XCCONFIG_FILE"
git rev-parse HEAD > "$EVIDENCE/source-head.txt"
git status --short > "$EVIDENCE/source-status-before.txt"
git submodule status --recursive > "$EVIDENCE/submodules-before.txt"
{
  flutter --version
  go version
  cargo --version
  rustc --version
  rustup toolchain list
  xcodebuild -version
  xcrun clang --version
  printf 'flutter_path=%s\ngo_path=%s\ncargo_path=%s\nxcrun_path=%s\n' "$(command -v flutter)" "$(command -v go)" "$(command -v cargo)" "$(command -v xcrun)"
} > "$EVIDENCE/toolchains.txt"
python3 - "$EVIDENCE" <<'BEFORE'
import hashlib
import json
from pathlib import Path
import subprocess
import sys
e = Path(sys.argv[1])
identity = Path('macos/Shared/HelperIdentity.h').read_text()
assert '#define FC_PINNED_CERTIFICATE_SHA1 "BBA7F8529FD271B9848EC03A2CE3F4780F585556"' in identity
assert '#define FC_PRODUCTION_TEAM_ID ""' in identity
assert '#define FC_MANAGED_CANDIDATE_ENABLED 0' in identity
assert 'FC_MANAGED_GUI_LOADS_VERIFIED' not in identity
spec = Path('pubspec.yaml').read_text()
assert 'version: 0.9.7+2026111301' in spec
assert spec.count('build_assets: true') == 2 and 'build_assets: false' not in spec
assert "bool.fromEnvironment('MACOS_MANAGED_HELPER')" in Path('lib/core/desktop/macos_helper_client.dart').read_text()
assert json.loads(Path('env.json').read_text()) == {'APP_ENV': 'stable'}
files = subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0')
inputs = {}
for name in files:
    if not name:
        continue
    p = Path(name)
    if p.is_symlink():
        inputs[name] = {'symlink': str(p.readlink())}
    elif p.is_file():
        inputs[name] = {'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
    elif p.is_dir():
        inputs[name] = {'gitlink_head': subprocess.check_output(['git', '-C', name, 'rev-parse', 'HEAD'], text=True).strip(), 'status': subprocess.check_output(['git', '-C', name, 'status', '--porcelain'], text=True)}
(e / 'tracked-input-hashes-before.json').write_text(json.dumps(inputs, sort_keys=True, indent=2) + '\n')
old = Path('.airbuild/artifacts/fixed-identity-2026111301')
previous = {}
for p in sorted(old.rglob('*')):
    if p.is_symlink():
        previous[str(p.relative_to(old))] = {'symlink': str(p.readlink())}
    elif p.is_file():
        previous[str(p.relative_to(old))] = {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'mode': p.stat().st_mode & 0o7777}
(e / 'prior-01-artifact-inventory-before.json').write_text(json.dumps(previous, sort_keys=True, indent=2) + '\n')
metadata = {
    'version': '0.9.7', 'build_number': '2026111302',
    'defines': {'APP_ENV': 'stable', 'MACOS_MANAGED_HELPER': True, 'FC_MANAGED_CANDIDATE_ENABLED': 1, 'FC_PINNED_CERTIFICATE_SHA1': 'BBA7F8529FD271B9848EC03A2CE3F4780F585556'},
    'certificate_sha1': 'BBA7F8529FD271B9848EC03A2CE3F4780F585556', 'apple_team': '',
    'source_head': 'f3916e4f0db354086d73080471687aba3fcd442c',
    'diagnostic_protocol_source_commit': '20376708b5a5f9919a5c68ac51197a129f8d2857',
    'diagnostic_engine_start_fix_commit': 'f3916e4f0db354086d73080471687aba3fcd442c',
    'tracked_pubspec_build_number': '2026111301', 'build_number_source': 'explicit CLI override',
    'managed_candidate_enabled': True, 'source_candidate_default': 0, 'dart_managed_default': False,
    'core_and_rust_hooks_enabled': True, 'network_sandbox': 'deny network*',
    'xcode_code_signing_allowed': False, 'actualGUIloads': False, 'runtime_acceptance': False,
    'packaging_accepted': False, 'production_components_executed': False,
    'candidate_capability': 'enabled, unqualified, nondistributed; exact signed artifact qualification remains external',
    'swiftpm_per_invocation_override': 'IDEPackageSupportDisableManifestSandbox=YES',
    'swiftpm_cache_only_flags': ['-disableAutomaticPackageResolution', '-onlyUsePackageVersionsFromResolvedFile', '-skipPackageUpdates'],
}
(e / 'build-contract.json').write_text(json.dumps(metadata, indent=2) + '\n')
BEFORE
if [[ -d "$APP" ]]; then mv "$APP" "$EVIDENCE/prior-generated-Flash.app"; fi
if [[ -d .dart_tool/setup_build_cache ]]; then mv .dart_tool/setup_build_cache "$EVIDENCE/prior-setup-build-cache"; fi
printf '%s\n' 'COMMAND: flutter -v build macos --release --no-pub --dart-define-from-file=env.json --dart-define=MACOS_MANAGED_HELPER=true --build-number=2026111302'
/usr/bin/sandbox-exec -p '(version 1) (allow default) (deny network*)' \
  flutter -v build macos --release --no-pub --dart-define-from-file=env.json \
  --dart-define=MACOS_MANAGED_HELPER=true --build-number=2026111302
printf 'flutter_compile_exit=0\n' > "$EVIDENCE/flutter-compile-result.txt"
[[ "$(plutil -extract CFBundleShortVersionString raw "$APP/Contents/Info.plist")" = 0.9.7 ]]
[[ "$(plutil -extract CFBundleVersion raw "$APP/Contents/Info.plist")" = "$BUILD" ]]
[[ "$(plutil -extract CFBundleIdentifier raw "$APP/Contents/Info.plist")" = com.layoute.flash ]]
go version -m "$APP/Contents/MacOS/FlClashCore" > "$EVIDENCE/core-buildinfo.txt"
/usr/bin/sandbox-exec -p '(version 1) (allow default) (deny network*)' \
  xcrun xcodebuild -showBuildSettings -json -workspace macos/Runner.xcworkspace -scheme Runner -configuration Release CODE_SIGNING_ALLOWED=NO > "$EVIDENCE/effective-xcode-settings.json"
python3 - "$EVIDENCE" <<'COMPILE_EVIDENCE'
import base64
import hashlib
import json
import os
from pathlib import Path
import plistlib
import subprocess
import sys
root = Path.cwd()
e = Path(sys.argv[1])
settings = json.loads((e / 'effective-xcode-settings.json').read_text())
r = next(item['buildSettings'] for item in settings if item['target'] == 'Runner')
assert r['FC_MANAGED_CANDIDATE_ENABLED'] == '1'
assert 'FC_MANAGED_CANDIDATE_ENABLED=1' in r['GCC_PREPROCESSOR_DEFINITIONS'].split()
assert r['CODE_SIGNING_ALLOWED'] == 'NO'
info = plistlib.loads((root / 'build/macos/Build/Products/Release/Flash.app/Contents/Info.plist').read_bytes())
defines = [base64.b64decode(value).decode() for value in info['FlashDartDefines'].split(',') if value]
assert defines.count('MACOS_MANAGED_HELPER=true') == 1
assert defines.count('FLUTTER_BUILD_NUMBER=2026111302') == 1
(e / 'sealed-dart-defines.json').write_text(json.dumps(defines, indent=2) + '\n')
responses = []
for path in Path('build/macos/Build/Intermediates.noindex/Runner.build/Release/Runner.build').rglob('*.resp'):
    text = path.read_text()
    if '-DFC_MANAGED_CANDIDATE_ENABLED=1' in text:
        responses.append({'path': str(path), 'contents': text})
assert responses, 'Runner compile response lacks candidate macro'
(e / 'runner-compile-responses.json').write_text(json.dumps(responses, indent=2) + '\n')
env = os.environ.copy()
keys = ('ARCHS', 'CONFIGURATION', 'CONTENTS_FOLDER_PATH', 'SRCROOT', 'DART_DEFINES', 'FC_MANAGED_CANDIDATE_ENABLED')
for key in keys:
    env[key] = r[key]
env['TARGET_BUILD_DIR'] = str(e / 'native-trace-relink')
command = ['/usr/bin/sandbox-exec', '-p', '(version 1) (allow default) (deny network*)', '/bin/bash', '-x', str(root / 'macos/packaging/stage_managed_helper.sh')]
(e / 'native-trace-command.json').write_text(json.dumps({'command': command, 'effective_runner_environment': {k: env[k] for k in keys + ('TARGET_BUILD_DIR',)}}, indent=2) + '\n')
with (e / 'native-clang-traces.txt').open('w') as output:
    subprocess.run(command, env=env, cwd=root / 'macos', stdout=output, stderr=subprocess.STDOUT, check=True, timeout=120)
comparison = {}
for name in ('FlashHelper', 'FlashMaintenance'):
    built = root / 'build/macos/Build/Products/Release/Flash.app/Contents/Library/HelperTools' / name
    relink = Path(env['TARGET_BUILD_DIR']) / env['CONTENTS_FOLDER_PATH'] / 'Library/HelperTools' / name
    hashes = {label: hashlib.sha256(path.read_bytes()).hexdigest() for label, path in [('flutter_build', built), ('traced_relink', relink)]}
    assert hashes['flutter_build'] == hashes['traced_relink'], (name, hashes)
    comparison[name] = hashes
log = (e / 'native-clang-traces.txt').read_text()
for name in ('Supervisor.m', 'Maintenance.m'):
    assert any('clang' in line and '-DFC_MANAGED_CANDIDATE_ENABLED=1' in line and name in line for line in log.splitlines()), name
(e / 'native-trace-binary-comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')
metadata = json.loads((e / 'build-contract.json').read_text())
metadata['compile_evidence'] = {name: hashlib.sha256((e / name).read_bytes()).hexdigest() for name in ('effective-xcode-settings.json', 'runner-compile-responses.json', 'native-clang-traces.txt', 'native-trace-binary-comparison.json', 'sealed-dart-defines.json')}
metadata['flutter_release_compile_succeeded'] = True
(e / 'build-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
(e / 'build-metadata.json').chmod(0o600)
COMPILE_EVIDENCE
[[ "$(git rev-parse HEAD)" = "$EXPECTED_HEAD" && -z "$(git status --porcelain)" ]]
[[ "$(shasum -a 256 macos/packaging/stage_managed_payload.py | cut -d' ' -f1)" = 006b6d11b10d0875654fab009e7b6a231ebfb83f12cbb0a8c77ec0c463d65829 ]]
/usr/bin/sandbox-exec -p '(version 1) (allow default) (deny network*)' python3 macos/packaging/stage_managed_payload.py "$APP" "$DEST"
python3 - "$DEST" "$EVIDENCE" <<'MODES'
import json
import os
from pathlib import Path
import stat
import sys
app, e = map(Path, sys.argv[1:])
magic = {bytes.fromhex(value) for value in ('feedface', 'cefaedfe', 'feedfacf', 'cffaedfe', 'cafebabe', 'bebafeca', 'cafebabf', 'bfbafeca')}
known_script = 'Contents/Resources/LaunchAtLogin_LaunchAtLogin.bundle/Contents/Resources/copy-helper-swiftpm.sh'
changes = []
for path in [app.parent, app] + sorted(app.rglob('*')):
    if path.is_symlink():
        continue
    mode = stat.S_IMODE(path.stat().st_mode)
    if path.is_dir():
        wanted = 0o755
    elif path.is_file():
        with path.open('rb') as stream:
            is_macho = stream.read(4) in magic
        if not is_macho and mode & 0o111 and str(path.relative_to(app)) != known_script:
            raise ValueError('Unexpected non-Mach-O executable resource: ' + str(path))
        wanted = 0o755 if is_macho else 0o644
    else:
        raise ValueError('Unexpected stage object: ' + str(path))
    if mode != wanted:
        path.chmod(wanted)
        changes.append({'path': str(path), 'before': oct(mode), 'after': oct(wanted)})
(e / 'project-only-mode-normalization.json').write_text(json.dumps(changes, indent=2) + '\n')
MODES
/usr/bin/sandbox-exec -p '(version 1) (allow default) (deny network*)' python3 macos/packaging/stage_managed_payload.py --verify "$DEST" | tee "$EVIDENCE/stage-audit.txt"
python3 - "$DEST" "$EVIDENCE" <<'FINAL'
import hashlib
import json
from pathlib import Path
import plistlib
import stat
import subprocess
import sys
app, e = map(Path, sys.argv[1:])
magic = {bytes.fromhex(value) for value in ('feedface', 'cefaedfe', 'feedfacf', 'cffaedfe', 'cafebabe', 'bebafeca', 'cafebabf', 'bfbafeca')}
entries = []
machos = []
for p in [app] + sorted(app.rglob('*')):
    relative = '.' if p == app else str(p.relative_to(app))
    item = {'path': relative}
    if p.is_symlink():
        item['symlink'] = str(p.readlink())
    elif p.is_file():
        data = p.read_bytes()
        item.update(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data), mode=oct(stat.S_IMODE(p.stat().st_mode)))
        if data[:4] in magic:
            item['architectures'] = subprocess.check_output(['/usr/bin/lipo', '-archs', str(p)], text=True).strip().split()
            assert item['architectures'] == ['arm64'], item
            assert item['mode'] == '0o755', item
            machos.append(item)
        else:
            assert item['mode'] == '0o644', item
    elif p.is_dir():
        item['directory'] = True
        item['mode'] = oct(stat.S_IMODE(p.stat().st_mode))
        assert item['mode'] == '0o755', item
    else:
        raise ValueError(str(p))
    entries.append(item)
assert len(machos) == 9, machos
(e / 'candidate-file-manifest.json').write_text(json.dumps(entries, sort_keys=True, indent=2) + '\n')
(e / 'macho-inventory.json').write_text(json.dumps(machos, sort_keys=True, indent=2) + '\n')
manifest = app / 'Contents/Frameworks/App.framework/Versions/A/Resources/flutter_assets/NativeAssetsManifest.json'
(e / 'staged-native-assets-manifest.json').write_bytes(manifest.read_bytes())
for relative in ('Contents/MacOS/Flash', 'Contents/Library/HelperTools/FlashHelper', 'Contents/Library/HelperTools/FlashMaintenance'):
    assert b'BBA7F8529FD271B9848EC03A2CE3F4780F585556' in (app / relative).read_bytes(), relative
info = plistlib.loads((app / 'Contents/Info.plist').read_bytes())
assert info['CFBundleShortVersionString'] == '0.9.7' and info['CFBundleVersion'] == '2026111302'
files = subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0')
inputs = {}
for name in files:
    if not name:
        continue
    p = Path(name)
    if p.is_symlink():
        inputs[name] = {'symlink': str(p.readlink())}
    elif p.is_file():
        inputs[name] = {'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
    elif p.is_dir():
        inputs[name] = {'gitlink_head': subprocess.check_output(['git', '-C', name, 'rev-parse', 'HEAD'], text=True).strip(), 'status': subprocess.check_output(['git', '-C', name, 'status', '--porcelain'], text=True)}
(e / 'tracked-input-hashes-after.json').write_text(json.dumps(inputs, sort_keys=True, indent=2) + '\n')
assert inputs == json.loads((e / 'tracked-input-hashes-before.json').read_text()), 'Tracked source input changed'
old = Path('.airbuild/artifacts/fixed-identity-2026111301')
previous = {}
for p in sorted(old.rglob('*')):
    if p.is_symlink():
        previous[str(p.relative_to(old))] = {'symlink': str(p.readlink())}
    elif p.is_file():
        previous[str(p.relative_to(old))] = {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'mode': p.stat().st_mode & 0o7777}
(e / 'prior-01-artifact-inventory-after.json').write_text(json.dumps(previous, sort_keys=True, indent=2) + '\n')
assert previous == json.loads((e / 'prior-01-artifact-inventory-before.json').read_text()), 'Prior 01 artifact changed'
metadata = json.loads((e / 'build-metadata.json').read_text())
metadata['static_stage_audit_passed'] = True
metadata['artifact_manifest_sha256'] = hashlib.sha256((e / 'candidate-file-manifest.json').read_bytes()).hexdigest()
metadata['macho_count'] = len(machos)
metadata['architectures'] = ['arm64']
metadata['tracked_source_unchanged'] = True
metadata['prior_01_artifact_preserved'] = True
(e / 'build-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
(e / 'build-metadata.json').chmod(0o600)
(e / 'stage-checkpoint.json').write_text(json.dumps({'status': 'static-build-and-stage-passed', 'source_head': metadata['source_head'], 'app': str(app), 'version': metadata['version'], 'build_number': metadata['build_number'], 'macho_count': 9, 'architectures': ['arm64'], 'actualGUIloads': False, 'runtime_acceptance': False, 'packaging_accepted': False, 'signing_performed': False, 'prior_01_artifact_preserved': True, 'tracked_source_unchanged': True}, indent=2) + '\n')
print('Staged 9-Mach-O arm64 unsigned managed candidate; static load audit only; no production execution.')
FINAL
[[ "$(git rev-parse HEAD)" = "$EXPECTED_HEAD" && -z "$(git status --porcelain)" ]]
git rev-parse HEAD > "$EVIDENCE/source-head-after.txt"
git status --short > "$EVIDENCE/source-status-after.txt"
git submodule status --recursive > "$EVIDENCE/submodules-after.txt"
shasum -a 256 "$DEST/Contents/MacOS/Flash" "$DEST/Contents/MacOS/FlClashCore" \
  "$DEST/Contents/Library/HelperTools/FlashHelper" "$DEST/Contents/Library/HelperTools/FlashMaintenance" \
  "$EVIDENCE/build-metadata.json" "$EVIDENCE/candidate-file-manifest.json" "$EVIDENCE/macho-inventory.json" \
  "$EVIDENCE/effective-xcode-settings.json" "$EVIDENCE/native-clang-traces.txt" | tee "$EVIDENCE/sha256.txt"
printf 'STAGED_CANDIDATE=%s\nBUILD_METADATA=%s\n' "$DEST" "$EVIDENCE/build-metadata.json"
