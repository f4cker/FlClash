import ast
import importlib.util
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

PATH = Path(__file__).with_name('split-service-compile-2026111303.py')
SPEC = importlib.util.spec_from_file_location('prepared_service_compile', PATH)
DRIVER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(DRIVER)
GATE_SPEC = importlib.util.spec_from_file_location('prepared_gate', DRIVER.ROOT / 'macos/packaging/verify_split_service.py')
GATE = importlib.util.module_from_spec(GATE_SPEC)
GATE_SPEC.loader.exec_module(GATE)


class PreparedServiceTests(unittest.TestCase):
    def test_ast_has_no_shell_or_keychain_execution(self):
        tree = ast.parse(PATH.read_text())
        calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)]
        self.assertFalse(any(isinstance(node.func, ast.Attribute) and node.func.attr == 'system' for node in calls))
        self.assertFalse(any(keyword.arg == 'shell' for node in calls for keyword in node.keywords))
        self.assertNotIn('unlock-keychain', PATH.read_text())

    def test_explicit_invalid_pin_blocks_before_inputs_or_commands(self):
        with patch.object(DRIVER, 'SIGNER_SHA256', 'invalid-test-pin'), \
                patch.object(DRIVER.subprocess, 'run', side_effect=AssertionError('must not execute')), \
                patch.object(DRIVER, 'regular', side_effect=AssertionError('must not read inputs')):
            with self.assertRaisesRegex(ValueError, 'Invalid signer pin'):
                DRIVER.compile_service('a' * 64, DRIVER.METADATA, DRIVER.DELTA, 'b' * 64)

    def test_only_exact_qualified_cdhash_one_literal_preprocessor_argv(self):
        args = GATE.compile_argv('helper', '/compiler', '/sdk', GATE.GUI_CDHASH, '/output')
        self.assertIn('-DFC_SPLIT_GUI_CDHASH="' + GATE.GUI_CDHASH + '"', args)
        self.assertIn('-DFC_MANAGED_CANDIDATE_ENABLED=1', args)
        self.assertIn('-mmacosx-version-min=14.0', args)
        self.assertEqual(args[args.index('-arch') + 1], 'arm64')
        self.assertIn(str(GATE.ROOT / 'macos/PrivilegedHelper/Spawn.c'), args)
        for invalid in ('a' * 40, 'A' * 40, GATE.GUI_CDHASH + ';touch /tmp/no', '$(false)'):
            with self.assertRaises(ValueError):
                GATE.compile_argv('helper', '/compiler', '/sdk', invalid, '/output')

    def test_maintenance_framework_and_stub_no_objc_runtime(self):
        args = GATE.compile_argv('maintenance', '/compiler', '/sdk', GATE.GUI_CDHASH, '/output')
        self.assertIn('ServiceManagement', args)
        stub = GATE.compile_argv('stub', '/compiler', '/sdk', GATE.GUI_CDHASH, '/output')
        self.assertNotIn('-framework', stub)
        self.assertNotIn('-fobjc-arc', stub)
        self.assertIn(str(GATE.ROOT / 'macos/PrivilegedHelper/ServiceStub.c'), stub)

    def test_mock_compiler_argv_is_network_denied_and_journaled(self):
        journal = []
        fake = subprocess.CompletedProcess([], 0, stdout=b'clang fixture\n', stderr=b'warning fixture\n')
        with patch.object(DRIVER.subprocess, 'run', return_value=fake) as run:
            self.assertEqual(DRIVER.run(['/compiler', '--version'], journal), 'clang fixture')
        self.assertEqual(run.call_args.args[0], DRIVER.SANDBOX + ['/compiler', '--version'])
        self.assertNotIn('shell', run.call_args.kwargs)
        self.assertEqual(journal[0]['stderr'], 'warning fixture\n')
        failure = subprocess.CalledProcessError(1, [], output=b'out', stderr=b'err')
        with patch.object(DRIVER.subprocess, 'run', side_effect=failure):
            with self.assertRaises(subprocess.CalledProcessError):
                DRIVER.run(['/compiler', 'source'], journal)
        self.assertEqual(journal[-1]['returncode'], 1)
        self.assertEqual(journal[-1]['stderr'], 'err')

    def test_delta_mismatch_blocks_before_import(self):
        with tempfile.TemporaryDirectory() as temporary:
            delta = Path(temporary).resolve() / 'delta.json'
            delta.write_text('{}')
            with patch.object(DRIVER, 'DELTA', delta):
                with self.assertRaisesRegex(ValueError, 'delta pin mismatch'):
                    DRIVER.load_gate(delta, '0' * 64)

    def test_restrictive_umask_precedes_output_creation(self):
        source = PATH.read_text()
        self.assertLess(source.index('os.umask(0o077)'), source.index('WORK.mkdir(mode=0o700)'))
        self.assertIn("raise ValueError('Unsafe existing service output ancestor')", source)
        self.assertIn('split-2026111303-retry01', source)
        self.assertIn('continuation-04/build-metadata.json', source)
        self.assertNotIn('TBD_PARENT_REVIEW_REQUIRED', source)


if __name__ == '__main__':
    unittest.main()
