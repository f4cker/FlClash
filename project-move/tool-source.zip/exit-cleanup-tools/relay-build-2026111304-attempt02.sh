#!/bin/bash
set -euo pipefail
umask 027
ROOT=/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup
cd "$ROOT"
export PATH="$ROOT/.airbuild/tools/fixed-candidate-xcrun-bin:$HOME/.cargo/bin:$HOME/fvm/versions/3.47.4/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local CARGO_NET_OFFLINE=true
export FLUTTER_SUPPRESS_ANALYTICS=true DART_SUPPRESS_ANALYTICS=true COCOAPODS_DISABLE_STATS=true
export FLUTTER_MACOS_ARM64_ONLY=true FLUTTER_XCODE_CODE_SIGNING_ALLOWED=NO
export PYTHONDONTWRITEBYTECODE=1
exec /usr/bin/sandbox-exec -p '(version 1) (allow default) (deny network*)' /usr/bin/python3 -I -S -B "/Users/layoute/SideWork/FlClash/.airbuild/move-essentials/build-tool-source/relay-2026111304-attempt02/build_driver.py" "$@"
