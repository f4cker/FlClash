#!/usr/bin/python3
"""Separate post-GUI compilation; parent must keep the signing keychain locked."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import types

ROOT = Path('/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup')
BASE = ROOT / '.airbuild/artifacts/split-2026111303-retry01'
GUI = BASE / 'gui/Flash.app'
SERVICE = BASE / 'service/Flash.app'
BUILD = ROOT / '.airbuild/buildcandidate/split-2026111303'
FREEZE = BUILD / 'input-freeze.json'
METADATA = BUILD / 'continuation-04/build-metadata.json'
DELTA = BUILD / 'service-continuation-01/tooling-delta-02.json'
WORK = BASE / 'service-compile'
SIGNER_SHA256 = '9023fbb047381d8b5a46802e6718eb449b49701557beb6b4e177da15e25f9a59'
ENV = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C'}
SANDBOX = ['/usr/bin/sandbox-exec', '-p', '(version 1) (allow default) (deny network*)']


def regular(path):
    if path.resolve(strict=True) != path:
        raise ValueError('Noncanonical input')
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(descriptor, 'rb') as stream:
        metadata = os.fstat(stream.fileno())
        if not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1:
            raise ValueError('Expected single-link regular file: ' + str(path))
        return stream.read()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load_gate(delta_path, delta_sha256):
    if delta_path != DELTA or not re.fullmatch('[0-9a-f]{64}', delta_sha256 or ''):
        raise ValueError('Exact reviewed downstream delta path/SHA256 required')
    data = regular(delta_path)
    if sha(data) != delta_sha256:
        raise ValueError('Downstream delta pin mismatch')
    delta = json.loads(data)
    path = ROOT / 'macos/packaging/verify_split_service.py'
    source = regular(path)
    if sha(source) != delta['files'][str(path.relative_to(ROOT))]['after']['sha256']:
        raise ValueError('Static service verifier pin mismatch')
    gate = types.ModuleType('_service_compile_gate')
    gate.__file__ = str(path)
    exec(compile(source, str(path), 'exec'), gate.__dict__)
    return gate


def run(argv, journal):
    command = SANDBOX + [str(value) for value in argv]
    entry = {'argv': command}
    journal.append(entry)
    try:
        result = subprocess.run(command, check=True, stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                cwd=ROOT, env=dict(ENV), timeout=300)
    except subprocess.CalledProcessError as error:
        entry.update(stdout=(error.stdout or b'').decode(errors='replace'),
                     stderr=(error.stderr or b'').decode(errors='replace'), returncode=error.returncode)
        raise
    entry.update(stdout=result.stdout.decode(errors='replace'),
                 stderr=result.stderr.decode(errors='replace'), returncode=result.returncode)
    return result.stdout.decode().strip()


def compile_service(gui_report_sha256, build_metadata, tooling_delta, tooling_sha256):
    if not re.fullmatch('[0-9a-f]{64}', SIGNER_SHA256):
        raise ValueError('Invalid signer pin: execution disabled')
    if not re.fullmatch('[0-9a-f]{64}', gui_report_sha256 or ''):
        raise ValueError('Exact GUI signing receipt SHA256 required')
    if build_metadata != METADATA or os.getuid() == 0:
        raise ValueError('Only fixed new-build metadata and non-root caller allowed')
    os.umask(0o077)
    for directory in (BASE, SERVICE.parent):
        if directory.exists():
            info = directory.lstat()
            if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o7022:
                raise ValueError('Unsafe existing service output ancestor')
    if WORK.exists() or WORK.is_symlink() or SERVICE.exists() or SERVICE.is_symlink():
        raise ValueError('Never overwrite an earlier service compilation/stage')
    gate = load_gate(tooling_delta, tooling_sha256)
    delta, frozen, approved = gate.tooling_state(tooling_delta, tooling_sha256)
    if SIGNER_SHA256 != gate.SIGNER_SHA256 or gui_report_sha256 != gate.GUI_REPORT_SHA256:
        raise ValueError('Only final signer and exact qualified GUI receipt accepted')
    sources = gate.source_snapshot(approved)
    gui_evidence = gate.verify_gui(GUI, METADATA, gate.EVIDENCE)
    signer = gate.module('sign_split_payload', SIGNER_SHA256)
    fixed, constraint = signer.dependencies()
    verifier = fixed.trusted_verifier()
    receipt = signer.gui_receipt(GUI, gui_report_sha256, fixed, constraint, verifier)
    entries = fixed.inventory(GUI, verifier)
    if fixed.tree_digest(entries) != gate.GUI_TREE or receipt['library_constraint']['cdhash'] != gate.GUI_CDHASH:
        raise ValueError('GUI tree/CDHash changed after qualification')
    stage = gate.module('stage_split_payload', approved['macos/packaging/stage_split_payload.py']['sha256'])
    WORK.mkdir(mode=0o700)
    journal = []
    result = {'schema': 'flash-split-service-compile-v1', 'completed': False,
              'driver_sha256': sha(regular(Path(__file__))), 'signer_sha256': SIGNER_SHA256,
              'tooling_delta_sha256': tooling_sha256,
              'gui_report_sha256': gui_report_sha256, 'gui_cdhash': gate.GUI_CDHASH,
              'qualification_sha256': gate.EVIDENCE_SHA256,
              'gui_signed_tree_sha256': receipt['after']['tree_sha256'],
              'gui_signed_core_sha256': entries[gate.CORE]['sha256'],
              'build_metadata_sha256': gate.METADATA_SHA256, 'source_freeze_sha256': gate.FREEZE_SHA256,
              'source_inputs': sources, 'commands': journal, 'outputs': {},
              'native_qualification': False, 'installation_accepted': False}
    output_receipt = WORK / 'servicecompile-receipt.json'
    try:
        compiler = Path(run(['/usr/bin/xcrun', '--find', 'clang'], journal)).resolve(strict=True)
        sdk = Path(run(['/usr/bin/xcrun', '--show-sdk-path'], journal)).resolve(strict=True)
        result['toolchain'] = {'compiler': str(compiler), 'compiler_record': gate.record(compiler),
                               'sdk': str(sdk), 'clang_version': run([compiler, '--version'], journal),
                               'xcode_version': run(['/usr/bin/xcodebuild', '-version'], journal)}
        for role in gate.SOURCES:
            output = WORK / role
            argv = gate.compile_argv(role, compiler, sdk, gate.GUI_CDHASH, output)
            run(argv, journal)
            result['outputs'][role] = {'path': str(output), **gate.record(output), 'clang_argv': argv}
        if gate.record(compiler) != result['toolchain']['compiler_record']:
            raise ValueError('Compiler changed')
        gate.tooling_state(tooling_delta, tooling_sha256)
        if gate.source_snapshot(approved) != sources:
            raise ValueError('Frozen compile inputs changed')
        signer.gui_receipt(GUI, gui_report_sha256, fixed, constraint, verifier)
        stage.stage_service(GUI, WORK / 'stub', WORK / 'helper', WORK / 'maintenance', SERVICE)
        result['staged_unsigned_entries'] = fixed.inventory(SERVICE, verifier)
        for role, binary in gate.BINARIES.items():
            if result['staged_unsigned_entries'][binary]['sha256'] != result['outputs'][role]['sha256']:
                raise ValueError('Staged unsigned binary differs from compiler output')
        if result['staged_unsigned_entries'][gate.CORE]['sha256'] != result['gui_signed_core_sha256']:
            raise ValueError('Staged Core differs from exact GUI signed bytes')
        gate.tooling_state(tooling_delta, tooling_sha256)
        if gate.source_snapshot(approved) != sources or gate.verify_gui(GUI, METADATA, gate.EVIDENCE) != gui_evidence:
            raise ValueError('Frozen inputs or qualified GUI changed during service staging')
        result['completed'] = True
    except BaseException as error:
        result['failure'] = type(error).__name__
        raise
    finally:
        with output_receipt.open('x') as stream:
            json.dump(result, stream, sort_keys=True, indent=2)
            stream.write('\n')
        output_receipt.chmod(0o600)
    return output_receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--prepare-not-execute', action='store_true')
    mode.add_argument('--execute-after-gui-verification-and-keychain-lock', action='store_true')
    parser.add_argument('--gui-report-sha256')
    parser.add_argument('--build-metadata', type=Path)
    parser.add_argument('--tooling-delta', type=Path)
    parser.add_argument('--tooling-delta-sha256')
    args = parser.parse_args()
    if args.prepare_not_execute:
        print(json.dumps({'prepared_only': True, 'signer_sha256': SIGNER_SHA256,
                          'metadata': str(METADATA), 'gui': str(GUI), 'service': str(SERVICE),
                          'explicit_reviewed_tooling_delta_required': True}))
        return
    if not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode):
        raise ValueError('Require /usr/bin/python3 -I -S -B')
    print(compile_service(args.gui_report_sha256, args.build_metadata, args.tooling_delta, args.tooling_delta_sha256))


if __name__ == '__main__':
    main()
