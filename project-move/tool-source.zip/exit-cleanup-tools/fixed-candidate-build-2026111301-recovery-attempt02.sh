#!/bin/bash
set -euo pipefail
ROOT=/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup
cd "$ROOT"
export PATH="$ROOT/.airbuild/tools/fixed-candidate-xcrun-bin:$HOME/.cargo/bin:$HOME/fvm/versions/3.47.4/bin:/opt/homebrew/bin:$PATH"
export GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local CARGO_NET_OFFLINE=true
export FLUTTER_SUPPRESS_ANALYTICS=true DART_SUPPRESS_ANALYTICS=true COCOAPODS_DISABLE_STATS=true
export FLUTTER_MACOS_ARM64_ONLY=true FLUTTER_XCODE_CODE_SIGNING_ALLOWED=NO
BUILD=2026111301
EVIDENCE="$ROOT/.airbuild/buildcandidate/fixed-identity-$BUILD-recovery-attempt02"
DEST="$ROOT/.airbuild/artifacts/fixed-identity-$BUILD/Flash.app"
APP="$ROOT/build/macos/Build/Products/Release/Flash.app"
[[ "$(git rev-parse HEAD)" = f0b339429ffa94c64d55bc81b62f08c343790fc9 ]]
[[ "$(shasum -a 256 pubspec.yaml | cut -d' ' -f1)" = e86dae285cb0ab0bcb3e0f10c62474cb72d98d46b5939574ff80de2fa1d35384 ]]
[[ "$(shasum -a 256 .airbuild/tools/fixed-candidate-xcrun-bin/xcrun | cut -d' ' -f1)" = 923d477e8a1e58a8c24889082c9ac8aeef28d9035093c03147b7e79fe0c92586 ]]
mkdir -p "$EVIDENCE"
[[ ! -e "$DEST" && ! -e "$EVIDENCE/build.started" ]]
touch "$EVIDENCE/build.started"
export XCODE_XCCONFIG_FILE="$EVIDENCE/candidate.xcconfig"
printf '%s\n' 'FC_MANAGED_CANDIDATE_ENABLED = 1' 'GCC_PREPROCESSOR_DEFINITIONS = $(inherited) FC_MANAGED_CANDIDATE_ENABLED=$(FC_MANAGED_CANDIDATE_ENABLED)' > "$XCODE_XCCONFIG_FILE"
export BASH_ENV="$EVIDENCE/native-command-trace.sh"
printf '%s\n' 'case "$0" in */packaging/stage_managed_helper.sh) PS4="+ managed-native-trace "; set -x ;; esac' > "$BASH_ENV"
exec > >(tee "$EVIDENCE/build.log") 2>&1
trap 'result=$?; [[ ! -f .dart_tool/setup_build_cache/hook.log ]] || cp .dart_tool/setup_build_cache/hook.log "$EVIDENCE/setup-hook.log"; printf "build_exit=%s\ncompleted_utc=%s\n" "$result" "$(date -u +%FT%TZ)" > "$EVIDENCE/build-result.txt"; exit "$result"' EXIT
printf 'started_utc=%s\n' "$(date -u +%FT%TZ)"
git rev-parse HEAD > "$EVIDENCE/source-head.txt"
git status --short > "$EVIDENCE/source-status-before.txt"
git diff HEAD --binary > "$EVIDENCE/source-diff-before.patch"
git submodule status --recursive > "$EVIDENCE/submodules.txt"
SNAPSHOT_PHASE=before
python3 - "$EVIDENCE" "$SNAPSHOT_PHASE" <<'SNAPSHOT'
import hashlib
import json
from pathlib import Path
import subprocess
import sys
e, phase = Path(sys.argv[1]), sys.argv[2]
files = subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0')
fixed_packaging = {'macos/packaging/stage_managed_helper.sh', 'macos/packaging/stage_managed_payload.py', 'macos/packaging/candidate_policy.md'}
inputs = {}
for name in files:
    if not name or not (name.startswith(('lib/', 'macos/', 'plugins/', 'core/', 'assets/', 'arb/')) or name in ('pubspec.yaml', 'pubspec.lock', 'env.json', 'build_config.yaml', 'build.yaml')):
        continue
    if name.startswith('macos/packaging/') and name not in fixed_packaging:
        continue
    p = Path(name)
    if p.is_file():
        inputs[name] = hashlib.sha256(p.read_bytes()).hexdigest()
    elif p.is_symlink():
        inputs[name] = 'symlink:' + str(p.readlink())
(e / ('app-input-hashes-' + phase + '.json')).write_text(json.dumps(inputs, sort_keys=True, indent=2) + '\n')
if phase == 'after':
    assert inputs == json.loads((e / 'app-input-hashes-before.json').read_text()), 'Application build source inputs changed during compile'
SNAPSHOT

{
  flutter --version
  go version
  cargo --version
  rustc --version
  rustup toolchain list
  xcodebuild -version
  xcrun clang --version
  printf 'flutter_path=%s\ngo_path=%s\ncargo_path=%s\n' "$(command -v flutter)" "$(command -v go)" "$(command -v cargo)"
} > "$EVIDENCE/toolchains.txt"
python3 - "$EVIDENCE" <<'PY'
import json
from pathlib import Path
import sys
root = Path.cwd()
identity = (root / 'macos/Shared/HelperIdentity.h').read_text()
assert '#define FC_PINNED_CERTIFICATE_SHA1 "BBA7F8529FD271B9848EC03A2CE3F4780F585556"' in identity
assert '#define FC_PRODUCTION_TEAM_ID ""' in identity
assert '#define FC_MANAGED_CANDIDATE_ENABLED 0' in identity
assert 'FC_MANAGED_GUI_LOADS_VERIFIED' not in identity
spec = (root / 'pubspec.yaml').read_text()
assert 'version: 0.9.7+2026111301' in spec
assert spec.count('build_assets: true') == 2
assert 'build_assets: false' not in spec
assert "bool.fromEnvironment('MACOS_MANAGED_HELPER')" in (root / 'lib/core/desktop/macos_helper_client.dart').read_text()
assert json.loads((root / 'env.json').read_text()) == {'APP_ENV': 'stable'}
(Path(sys.argv[1]) / 'build-contract.json').write_text(json.dumps({
    'version': '0.9.7', 'build_number': '2026111301',
    'defines': {'APP_ENV': 'stable', 'MACOS_MANAGED_HELPER': True, 'FC_MANAGED_CANDIDATE_ENABLED': 1, 'FC_PINNED_CERTIFICATE_SHA1': 'BBA7F8529FD271B9848EC03A2CE3F4780F585556'},
    'certificate_sha1': 'BBA7F8529FD271B9848EC03A2CE3F4780F585556',
    'apple_team': '', 'managed_candidate_enabled': True, 'actualGUIloads': False, 'packaging_accepted': False,
    'dart_managed_default': False, 'core_and_rust_hooks_enabled': True,
    'network_sandbox': 'deny network*', 'xcode_code_signing_allowed': False,
    'runtime_acceptance': False,
    'diagnostic_source_commit': '69b4807a73662b942ce1a5bc1849ed6333b8b4cc',
    'swiftpm_per_invocation_override': 'IDEPackageSupportDisableManifestSandbox=YES',
    'swiftpm_cache_only_flags': ['-disableAutomaticPackageResolution', '-onlyUsePackageVersionsFromResolvedFile', '-skipPackageUpdates'],
    'candidate_capability': 'enabled, unqualified, nondistributed; external exact-artifact runtime proof required',
}, indent=2) + '\n')
PY
if [[ -d "$APP" ]]; then
  mv "$APP" "$EVIDENCE/prior-generated-Flash.app"
fi
if [[ -d .dart_tool/setup_build_cache ]]; then
  mv .dart_tool/setup_build_cache "$EVIDENCE/prior-setup-build-cache"
fi
printf '%s\n' 'COMMAND: flutter -v build macos --release --no-pub --dart-define-from-file=env.json --dart-define=MACOS_MANAGED_HELPER=true --build-number=2026111301'
/usr/bin/sandbox-exec -p '(version 1) (allow default) (deny network*)' \
  flutter -v build macos --release --no-pub --dart-define-from-file=env.json \
  --dart-define=MACOS_MANAGED_HELPER=true --build-number=2026111301
[[ "$(plutil -extract CFBundleShortVersionString raw "$APP/Contents/Info.plist")" = 0.9.7 ]]
[[ "$(plutil -extract CFBundleVersion raw "$APP/Contents/Info.plist")" = "$BUILD" ]]
[[ "$(plutil -extract CFBundleIdentifier raw "$APP/Contents/Info.plist")" = com.layoute.flash ]]
for relative in Contents/MacOS/Flash Contents/MacOS/FlClashCore Contents/Library/HelperTools/FlashHelper Contents/Library/HelperTools/FlashMaintenance; do
  [[ -f "$APP/$relative" ]]
  [[ "$(lipo -archs "$APP/$relative")" = arm64 ]]
done
go version -m "$APP/Contents/MacOS/FlClashCore" > "$EVIDENCE/core-buildinfo.txt"
/usr/bin/sandbox-exec -p '(version 1) (allow default) (deny network*)' xcrun xcodebuild -showBuildSettings -json -workspace macos/Runner.xcworkspace -scheme Runner -configuration Release CODE_SIGNING_ALLOWED=NO > "$EVIDENCE/effective-xcode-settings.json"
python3 - "$EVIDENCE" <<'VERIFY'
import base64
import json
import plistlib
from pathlib import Path
import subprocess
import sys
e = Path(sys.argv[1])
settings = json.loads((e / 'effective-xcode-settings.json').read_text())
runner = next(item['buildSettings'] for item in settings if item['target'] == 'Runner')
assert runner['FC_MANAGED_CANDIDATE_ENABLED'] == '1'
assert 'FC_MANAGED_CANDIDATE_ENABLED=1' in runner['GCC_PREPROCESSOR_DEFINITIONS'].split()
assert runner['CODE_SIGNING_ALLOWED'] == 'NO'
info = plistlib.loads(Path('build/macos/Build/Products/Release/Flash.app/Contents/Info.plist').read_bytes())
defines = [base64.b64decode(value).decode() for value in info['FlashDartDefines'].split(',') if value]
assert defines.count('MACOS_MANAGED_HELPER=true') == 1
(e / 'sealed-dart-defines.json').write_text(json.dumps(defines, indent=2) + '\n')
log = (e / 'build.log').read_text()
for name in ('Supervisor.m', 'Maintenance.m'):
    assert any('managed-native-trace' in line and 'clang' in line and '-DFC_MANAGED_CANDIDATE_ENABLED=1' in line and name in line for line in log.splitlines()), name
responses = []
for path in Path('build/macos/Build/Intermediates.noindex/Runner.build/Release/Runner.build').rglob('*.resp'):
    text = path.read_text()
    if '-DFC_MANAGED_CANDIDATE_ENABLED=1' in text:
        responses.append({'path': str(path), 'contents': text})
assert responses, 'Runner actual compile response with candidate macro missing'
(e / 'runner-compile-responses.json').write_text(json.dumps(responses, indent=2) + '\n')
(e / 'native-clang-traces.txt').write_text('\n'.join(line for line in log.splitlines() if 'managed-native-trace' in line and 'clang' in line) + '\n')
(e / 'build-metadata.json').write_bytes((e / 'build-contract.json').read_bytes())
VERIFY
SNAPSHOT_PHASE=after
python3 - "$EVIDENCE" "$SNAPSHOT_PHASE" <<'SNAPSHOT'
import hashlib
import json
from pathlib import Path
import subprocess
import sys
e, phase = Path(sys.argv[1]), sys.argv[2]
files = subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0')
fixed_packaging = {'macos/packaging/stage_managed_helper.sh', 'macos/packaging/stage_managed_payload.py', 'macos/packaging/candidate_policy.md'}
inputs = {}
for name in files:
    if not name or not (name.startswith(('lib/', 'macos/', 'plugins/', 'core/', 'assets/', 'arb/')) or name in ('pubspec.yaml', 'pubspec.lock', 'env.json', 'build_config.yaml', 'build.yaml')):
        continue
    if name.startswith('macos/packaging/') and name not in fixed_packaging:
        continue
    p = Path(name)
    if p.is_file():
        inputs[name] = hashlib.sha256(p.read_bytes()).hexdigest()
    elif p.is_symlink():
        inputs[name] = 'symlink:' + str(p.readlink())
(e / ('app-input-hashes-' + phase + '.json')).write_text(json.dumps(inputs, sort_keys=True, indent=2) + '\n')
if phase == 'after':
    assert inputs == json.loads((e / 'app-input-hashes-before.json').read_text()), 'Application build source inputs changed during compile'
SNAPSHOT
python3 macos/packaging/stage_managed_payload.py "$APP" "$DEST"
python3 macos/packaging/stage_managed_payload.py --verify "$DEST"
python3 - "$DEST" "$EVIDENCE" <<'PY'
import hashlib
import json
from pathlib import Path
import subprocess
import sys
app, evidence = map(Path, sys.argv[1:])
files = []
macho = {bytes.fromhex(value) for value in ('feedface', 'cefaedfe', 'feedfacf', 'cffaedfe', 'cafebabe', 'bebafeca', 'cafebabf', 'bfbafeca')}
for path in sorted(app.rglob('*')):
    if path.is_symlink():
        files.append({'path': str(path.relative_to(app)), 'symlink': path.readlink().as_posix()})
    elif path.is_file():
        data = path.read_bytes()
        item = {'path': str(path.relative_to(app)), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
        if data[:4] in macho:
            item['architectures'] = subprocess.check_output(['/usr/bin/lipo', '-archs', str(path)], text=True).strip().split()
        files.append(item)
(evidence / 'candidate-file-manifest.json').write_text(json.dumps(files, indent=2) + '\n')
print('Staged unsigned managed candidate; static load-boundary evidence only; no production executable run.')
PY
[[ ! -f .dart_tool/setup_build_cache/hook.log ]] || cp .dart_tool/setup_build_cache/hook.log "$EVIDENCE/setup-hook.log"
: # Source compile inputs are compared by their independently recorded hashes below.
git rev-parse HEAD > "$EVIDENCE/source-head-after.txt"
git status --short > "$EVIDENCE/source-status-after.txt"
shasum -a 256 "$DEST/Contents/MacOS/Flash" "$DEST/Contents/MacOS/FlClashCore" \
  "$DEST/Contents/Library/HelperTools/FlashHelper" "$DEST/Contents/Library/HelperTools/FlashMaintenance" \
  "$EVIDENCE/candidate-file-manifest.json" | tee "$EVIDENCE/sha256.txt"
printf 'STAGED_CANDIDATE=%s\n' "$DEST"
