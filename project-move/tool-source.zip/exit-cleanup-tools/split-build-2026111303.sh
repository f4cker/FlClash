#!/bin/bash
set -euo pipefail
umask 022
ROOT=/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup
cd "$ROOT"
export PATH="$ROOT/.airbuild/tools/fixed-candidate-xcrun-bin:$HOME/.cargo/bin:$HOME/fvm/versions/3.47.4/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local CARGO_NET_OFFLINE=true
export FLUTTER_SUPPRESS_ANALYTICS=true DART_SUPPRESS_ANALYTICS=true COCOAPODS_DISABLE_STATS=true
export FLUTTER_MACOS_ARM64_ONLY=true FLUTTER_XCODE_CODE_SIGNING_ALLOWED=NO
export PYTHONDONTWRITEBYTECODE=1
exec /usr/bin/python3 -I -S -B "$ROOT/.airbuild/buildcandidate/split-2026111303/build_driver.py" "$@"
