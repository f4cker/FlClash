import hashlib
import importlib.util
import json
import os
from pathlib import Path
import plistlib
import stat
import subprocess
import sys
import traceback

ROOT = Path('/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup')
E = ROOT / '.airbuild/buildcandidate/fixed-identity-2026111301-rpath-recovery-attempt03'
OUT = E / 'rpath-recovery'
PRIOR = ROOT / '.airbuild/buildcandidate/fixed-identity-2026111301-recovery-attempt02'
SOURCE = ROOT / 'build/macos/Build/Products/Release/Flash.app'
DEST = ROOT / '.airbuild/artifacts/fixed-identity-2026111301/Flash.app'
PRESERVED = E / 'failed-stage-before-app-rpath-fix'
STAGER = ROOT / 'macos/packaging/stage_managed_payload.py'
EXPECTED = '006b6d11b10d0875654fab009e7b6a231ebfb83f12cbb0a8c77ec0c463d65829'


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def save(name, data):
    path = OUT / name
    with path.open('x') as target:
        json.dump(data, target, indent=2)
        target.write('\n')


def inventory(app):
    result = {}
    for directory, names, files in os.walk(app, followlinks=False):
        for name in sorted(names + files):
            path = Path(directory) / name
            info = path.lstat()
            item = {'mode': oct(stat.S_IMODE(info.st_mode))}
            if stat.S_ISLNK(info.st_mode):
                item.update(type='symlink', target=os.readlink(path))
            elif stat.S_ISREG(info.st_mode):
                item.update(type='file', bytes=info.st_size, sha256=sha(path))
            elif stat.S_ISDIR(info.st_mode):
                item.update(type='directory')
            else:
                raise ValueError(f'Unsupported artifact entry: {path}')
            result[str(path.relative_to(app))] = item
    return result


def run(arguments, log_name):
    with (OUT / log_name).open('x') as log:
        log.write('COMMAND: ' + json.dumps(arguments) + '\n')
        log.flush()
        result = subprocess.run(arguments, stdout=log, stderr=subprocess.STDOUT,
                                timeout=180, check=False)
    if result.returncode:
        raise RuntimeError(f'{log_name} failed with exit {result.returncode}; stop at concrete error')


summary = {
    'status': 'started', 'source': str(SOURCE), 'destination': str(DEST),
    'preserved_failed_stage': str(PRESERVED), 'stager_sha256': EXPECTED,
    'normalization_commit': '2a8b20d2', 'compile_source_commit': 'f0b339429ffa94c64d55bc81b62f08c343790fc9',
    'actualGUIloads': False, 'runtime_acceptance': False, 'packaging_accepted': False,
    'production_components_executed': False, 'signing_performed': False,
}
before = None
try:
    assert STAGER.is_file() and sha(STAGER) == EXPECTED
    assert SOURCE.is_dir() and not SOURCE.is_symlink()
    assert SOURCE.resolve() == SOURCE and DEST.resolve() == DEST
    assert DEST.is_dir() and not DEST.is_symlink()
    assert not os.path.lexists(PRESERVED)
    metadata = json.loads((PRIOR / 'build-metadata.json').read_text())
    assert metadata['defines']['FC_MANAGED_CANDIDATE_ENABLED'] == 1
    assert metadata['version'] == '0.9.7' and metadata['build_number'] == '2026111301'
    save('compile-contract.json', metadata)
    before = inventory(SOURCE)
    save('source-file-inventory-before.json', before)
    save('failed-stage-file-inventory.json', inventory(DEST))
    info = plistlib.loads((SOURCE / 'Contents/Info.plist').read_bytes())
    assert info['CFBundleShortVersionString'] == '0.9.7'
    assert info['CFBundleVersion'] == '2026111301'
    save('source-version.json', {key: info[key] for key in (
        'CFBundleIdentifier', 'CFBundleShortVersionString', 'CFBundleVersion')})
    os.rename(DEST, PRESERVED)
    assert PRESERVED.is_dir() and not os.path.lexists(DEST)
    summary['failed_stage_preserved'] = True
    run([sys.executable, str(STAGER), str(SOURCE), str(DEST)], 'stage.log')
    summary['stage_audit_passed'] = True
    run([sys.executable, str(STAGER), '--verify', str(DEST)], 'verify.log')
    summary['sealed_verify_passed'] = True
    staged = inventory(DEST)
    save('staged-file-inventory.json', staged)
    changed = sorted(path for path in set(before) | set(staged)
                     if before.get(path) != staged.get(path))
    save('source-to-stage-changes.json', changed)
    spec = importlib.util.spec_from_file_location('recovery_policy', STAGER)
    policy = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(policy)
    commands = {}
    for relative, entry in staged.items():
        if entry['type'] != 'file':
            continue
        binary = DEST / relative
        with binary.open('rb') as stream:
            macho = stream.read(4) in policy.MACH_MAGIC
        if macho:
            commands[relative] = policy.load_commands(binary)
    save('staged-all-macho-load-commands.json', commands)
    roles = ['Contents/MacOS/Flash', *policy.FIXED_EXECUTABLES, policy.APP_FRAMEWORK_BINARY]
    roles += [f'Contents/Frameworks/{name}.framework/{name}' for name in policy.ASSETS.values()]
    observations = {}
    for relative in roles:
        binary = policy.inside(DEST / relative, DEST)
        canonical = str(binary.relative_to(DEST))
        slices = commands[canonical]
        assert set(slices) == {'arm64'}
        observations[relative] = {'sha256': sha(binary), 'architectures': list(slices)}
    save('role-observations.json', observations)
    app_slices = commands[policy.APP_FRAMEWORK_BINARY]
    assert not any(value in paths for paths, _ in app_slices.values()
                   for value in policy.REDUNDANT_APP_RPATHS)
    assert (DEST / 'Contents/Info.plist').read_bytes() == (SOURCE / 'Contents/Info.plist').read_bytes()
    for relative in ['Contents/MacOS/Flash', *policy.FIXED_EXECUTABLES]:
        assert before[relative] == staged[relative]
    summary.update(status='restage-and-sealed-verify-passed', version='0.9.7',
                   build_number='2026111301', candidate_enabled=1,
                   architectures=['arm64'], source_default=0,
                   changed_entries=changed, inspected_macho_count=len(commands))
except BaseException as error:
    summary.update(status='stopped-at-concrete-error', error=str(error))
    with (OUT / 'error.log').open('x') as stream:
        traceback.print_exc(file=stream)
    raise
finally:
    if before is not None:
        after = inventory(SOURCE)
        save('source-file-inventory-after.json', after)
        summary['source_app_unchanged'] = before == after
        if before != after:
            summary['status'] = 'source-integrity-check-failed'
    save('recovery-checkpoint.json', summary)
    hashes = {path.name: sha(path) for path in sorted(OUT.iterdir()) if path.is_file()}
    save('evidence-sha256.json', hashes)
    print(json.dumps(summary, indent=2))
