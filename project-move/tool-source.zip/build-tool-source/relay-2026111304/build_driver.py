import argparse
import base64
import contextlib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import plistlib
import re
import shutil
import stat
import struct
import subprocess
import sys
import time
import traceback
import types
from urllib.parse import unquote, urljoin, urlsplit

ROOT = Path('/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup')
E = ROOT / '.airbuild/buildcandidate/relay-2026111304'
SDK = Path('/Users/layoute/fvm/versions/3.47.4')
APP = ROOT / 'build/macos/Build/Products/Release/Flash.app'
DEST = ROOT / '.airbuild/artifacts/relay-2026111304/gui/Flash.app'
FREEZE = E / 'input-freeze.json'
CERT = 'BBA7F8529FD271B9848EC03A2CE3F4780F585556'
SANDBOX = ['/usr/bin/sandbox-exec', '-p', '(version 1) (allow default) (deny network*)']
OLD = '.airbuild/tools/fixed-candidate-build-2026111302-engine-start-fix.sh'
WRAPPER = '.airbuild/tools/fixed-candidate-xcrun-bin/xcrun'
ENGINE = 'engine/src/flutter/shell/platform/darwin/macos/framework/Source/FlutterEngine.mm'
FRAMEWORK = 'bin/cache/artifacts/engine/darwin-x64-release/FlutterMacOS.xcframework/macos-arm64_x86_64/FlutterMacOS.framework/Versions/A/FlutterMacOS'
PINS_SHA256 = '89069fa6546b72068f1f411f8fa3ad2fc6d509be876839d4492298ebdb3699c7'
PINS_PATH = E / 'preparation-pins.json'
AUTHORIZATION = 'relay-2026111304-gui-compile-and-stage'
WARNING_PREFIX = ('--- xcodebuild: WARNING: Using the first of multiple matching destinations:\n'
                  '{ platform:macOS, arch:arm64, id:00006050-001B70DA3C89401C, name:My Mac }\n'
                  '{ platform:macOS, arch:x86_64, id:00006050-001B70DA3C89401C, name:My Mac }\n'
                  '{ platform:macOS, name:Any Mac }\n')
MOVED_GENERATED = ('build/macos/Build', 'build/macos/Logs', 'build/native_assets',
                   'macos/Flutter/ephemeral', '.dart_tool/flutter_build', '.dart_tool/setup_build_cache',
                   '.dart_tool/hooks_runner/setup', 'libclash/macos')
COPIED_GENERATED = tuple('.dart_tool/hooks_runner/' + name
                         for name in ('rust_api', 'objective_c', 'sqlite3', 'shared'))
PACKAGE_SOURCE_DIRS = ('hook', 'src', 'native', 'macos', 'darwin', 'ios', 'assets',
                       'tool', 'third_party', 'shared', 'include', 'bin')
SDK_NATIVE_SCOPES = ('packages/flutter_tools/bin', 'packages/flutter_tools/lib',
                     'bin/cache/dart-sdk/include',
                     str(Path(FRAMEWORK).parent / 'Headers'),
                     str(Path(FRAMEWORK).parent / 'Modules'))
SDK_ID = {'frameworkVersion': '3.47.4', 'frameworkRevision': '9584c6713b324636289d067944a46fd6b49df14b',
          'engineRevision': '06a2e2a110089dff50fe635cffd2a61e1b24fbcd',
          'engineContentHash': '0e228ec8c8d2abc9fcf1d053e8a40665bb859ec7', 'dartSdkVersion': '3.13.3'}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def arm64_bytes(path):
    data = Path(path).read_bytes()
    if data[:4] == bytes.fromhex('cafebabe'):
        slices = []
        for index in range(struct.unpack_from('>I', data, 4)[0]):
            cpu, subtype, offset, size, alignment = struct.unpack_from('>IIIII', data, 8 + 20 * index)
            if cpu == 0x100000c:
                slices.append(data[offset:offset + size])
        assert len(slices) == 1
        return slices[0]
    assert data[:4] == bytes.fromhex('cffaedfe') and struct.unpack_from('<I', data, 4)[0] == 0x100000c
    return data


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, sort_keys=True, indent=2) + '\n')
    path.chmod(0o600)


def git(*args, cwd=ROOT):
    return subprocess.check_output(['/usr/bin/git', *args], cwd=cwd).decode()


def entry(path):
    s = path.lstat()
    result = {'mode': stat.S_IMODE(s.st_mode)}
    if path.is_symlink():
        result['symlink'] = os.readlink(path)
    elif path.is_file():
        assert s.st_nlink == 1, 'Hardlinked input: ' + str(path)
        result.update(sha256=sha(path), bytes=s.st_size)
    elif path.is_dir():
        result['directory'] = True
    else:
        raise ValueError('Special input: ' + str(path))
    return result


def tree(path):
    if not path.exists() and not path.is_symlink():
        return {'missing': True}
    result = {'.': entry(path)}
    if path.is_dir() and not path.is_symlink():
        for directory, names, files in os.walk(path, followlinks=False):
            for name in sorted(names + files):
                p = Path(directory) / name
                result[str(p.relative_to(path))] = entry(p)
    return result


def source_inputs(directory=ROOT, prefix=''):
    result = {}
    names = set(git('ls-files', '-z', '--cached', '--others', '--exclude-standard', cwd=directory).split('\0')) - {''}
    for name in sorted(names):
        path = directory / name
        key = prefix + name
        if not path.exists() and not path.is_symlink():
            result[key] = {'missing': True}
        elif path.is_dir() and not path.is_symlink():
            result[key] = {'gitlink_head': git('rev-parse', 'HEAD', cwd=path).strip(),
                           'status': git('status', '--porcelain', cwd=path)}
            result.update(source_inputs(path, key + '/'))
        else:
            result[key] = entry(path)
    return result


def file_uri(value, base, strict=True):
    parsed = urlsplit(urljoin(base, value))
    assert parsed.scheme == 'file' and parsed.netloc in ('', 'localhost'), 'Nonlocal package URI'
    assert not parsed.query and not parsed.fragment, 'Unexpected URI query/fragment'
    return Path(unquote(parsed.path)).resolve(strict=strict)


def bound_tree(path):
    result = {'entries': tree(path), 'resolved_links': {}}
    for name, item in result['entries'].items():
        if isinstance(item, dict) and 'symlink' in item:
            resolved = (path if name == '.' else path / name).resolve(strict=True)
            result['resolved_links'][str(resolved)] = tree(resolved)
    return result


def external_package_inputs(config=ROOT / '.dart_tool/package_config.json', root=ROOT):
    packages = json.loads(config.read_text())['packages']
    result = {}
    for package in packages:
        directory = file_uri(package['rootUri'], config.resolve().as_uri())
        if directory.is_relative_to(root):
            continue
        library = file_uri(package.get('packageUri', 'lib/'), directory.as_uri() + '/', strict=False)
        assert library.is_relative_to(directory), 'Escaping packageUri'
        scopes = {str(library.relative_to(directory)), *PACKAGE_SOURCE_DIRS}
        scopes.update(p.name for p in directory.iterdir() if p.is_file() and
                      p.suffix in ('.yaml', '.yml', '.json', '.dart', '.sh', '.rb', '.podspec'))
        result[package['name']] = {'root': str(directory), 'package_uri': package.get('packageUri', 'lib/'),
            'source_scopes': {name: bound_tree(directory / name) for name in sorted(scopes)
                              if name == str(library.relative_to(directory)) or
                              (directory / name).exists() or (directory / name).is_symlink()}}
    return result


def sdk_native_inputs():
    return {name: bound_tree(SDK / name) for name in SDK_NATIVE_SCOPES}


def retained_native_inputs(root=ROOT):
    root = root.resolve(strict=True)
    result = {}
    for name in ('rust_api', 'objective_c', 'sqlite3'):
        candidates = []
        for control in sorted((root / '.dart_tool/hooks_runner' / name).glob('*/input.json')):
            request = json.loads(control.read_text())
            config = request['config']
            target = config['extensions']['code_assets']
            if (config.get('linking_enabled') is True and target.get('target_os') == 'macos'
                    and target.get('target_architecture') == 'arm64'):
                candidates.append((control, request))
        assert len(candidates) == 1, 'Expected one cached arm64 macOS link configuration: ' + name
        control, request = candidates[0]
        output = control.with_name('output.json')
        response = json.loads(output.read_text())
        assert response.get('status') == 'success'
        assets = response.get('assets', [])
        assert len(assets) == 1 and assets[0]['type'] == 'code_assets/code'
        encoding = assets[0]['encoding']
        assert encoding['link_mode']['type'] == 'dynamic_loading_bundle'
        asset = Path(encoding['file']).resolve(strict=True)
        assert asset.is_relative_to(root / '.dart_tool/hooks_runner/shared' / name)
        assert asset.is_file() and not asset.is_symlink()
        result[name] = {'input_path': str(control.relative_to(root)),
            'output_path': str(output.relative_to(root)), 'configuration': request['config'],
            'package_root': str(Path(request['package_root']).resolve(strict=True)),
            'asset_id': encoding['id'], 'asset_path': str(asset.relative_to(root)), 'asset': entry(asset),
            'source_dependencies': {str(Path(p).resolve(strict=True)): entry(Path(p).resolve(strict=True))
                                    for p in response.get('dependencies', [])}}
    return result


def generated_observation(root=ROOT):
    return {name: tree(root / name) for name in MOVED_GENERATED + COPIED_GENERATED}


def immutable_frozen(frozen):
    return {k: v for k, v in frozen.items() if k not in ('protected', 'generated_before')}


def archive_generated(expected, root=ROOT, output=E):
    assert generated_observation(root) == expected, 'Generated inputs changed after freeze'
    archive = output / 'prior-generated'
    archive.mkdir()
    paths, inventories = {}, {}
    for name in MOVED_GENERATED + COPIED_GENERATED:
        source = root / name
        if not source.exists():
            continue
        target = archive / name.replace('/', '__')
        if name in MOVED_GENERATED:
            source.rename(target)
        else:
            shutil.copytree(source, target, symlinks=True)
        assert tree(target) == expected[name], 'Archive changed prior generated bytes: ' + name
        paths[name] = str(target)
        inventories[name] = expected[name]
    save(output / 'preserved-generated-paths.json', paths)
    save(output / 'preserved-generated-inventories.json', inventories)
    save(output / 'generated-output-policy.json', {'moved_then_regenerated': list(MOVED_GENERATED),
        'copied_before_reuse_or_regeneration': list(COPIED_GENERATED),
        'immutable_retained_selection_and_dylib_bytes': True,
        'hook_control_metadata_and_other_generated_outputs_may_change': True})
    return paths, inventories


def macho_sections(path):
    data = arm64_bytes(path)
    result, offset = {}, 32
    for _ in range(struct.unpack_from('<I', data, 16)[0]):
        command, size = struct.unpack_from('<II', data, offset)
        assert size >= 8 and offset + size <= len(data), 'Malformed Mach-O command'
        if command == 0x19:
            count = struct.unpack_from('<I', data, offset + 64)[0]
            assert 72 + count * 80 <= size
            for index in range(count):
                section = offset + 72 + index * 80
                name, segment, address, length, start = struct.unpack_from('<16s16sQQI', data, section)
                flags = struct.unpack_from('<I', data, section + 64)[0]
                key = segment.rstrip(b'\0').decode() + '/' + name.rstrip(b'\0').decode()
                assert key not in result
                zero_fill = flags & 0xff in (1, 0xc, 0x12)
                assert zero_fill or start + length <= len(data)
                result[key] = {'size': length, 'flags': flags,
                    'sha256': None if zero_fill else hashlib.sha256(data[start:start + length]).hexdigest()}
        offset += size
    assert '__TEXT/__text' in result, 'Missing native machine-code section'
    return result


def verify_retained_frameworks(retained, app=APP, root=ROOT):
    proof = {}
    for name, item in retained.items():
        binary = app / f'Contents/Frameworks/{name}.framework/Versions/A/{name}'
        asset = root / item['asset_path']
        assert entry(asset) == item['asset'], 'Retained native asset changed: ' + name
        sections = macho_sections(asset)
        assert sections == macho_sections(binary), 'Retained native asset/bundle section mismatch: ' + name
        proof[name] = {'origin': 'retained-prebuilt-native-dependency-not-fresh',
            'input_asset_path': item['asset_path'], 'input_asset': item['asset'],
            'compiled_bundle_binary': entry(binary), 'identical_arm64_sections': sections,
            'framework_transformations': 'Flutter install-name rewrite and optional signature/container changes; all Mach-O section bytes identical'}
    return proof


def pins():
    assert sha(PINS_PATH) == PINS_SHA256, 'Preparation pins changed'
    return json.loads(PINS_PATH.read_text())


def sdk_observation():
    reviewed = pins()['sdk']
    version_path = SDK / 'bin/cache/flutter.version.json'
    try:
        version = json.loads(version_path.read_text())
    except (OSError, ValueError) as error:
        version = {'capture_error': type(error).__name__}
    return {'version': version, 'files': {name: entry(SDK / name)
            if (SDK / name).exists() or (SDK / name).is_symlink() else {'missing': True}
            for name in reviewed['files']}}


def sdk_inputs():
    result = sdk_observation()
    version = result['version']
    assert all(version[k] == v for k, v in SDK_ID.items()), version
    assert git('rev-parse', 'HEAD', cwd=SDK).strip() == SDK_ID['frameworkRevision']
    assert sha(SDK / ENGINE) == 'e771c63af5a3278fb69d1eead8bcbec2f6e7eeb186ab8cca47ad5c0a01eab0cc'
    assert result == pins()['sdk'], 'SDK differs from exact old03 engine/toolchain'
    return result


def tool_entry(path):
    path = Path(path)
    if path not in (Path('/usr/bin/xcodebuild'), Path('/usr/bin/xcrun')):
        return entry(path)
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_uid == 0 and not info.st_mode & 0o022, 'Unsafe protected OS tool'
    assert path.resolve(strict=True) == path, 'OS tool must be canonical'
    return {'mode': stat.S_IMODE(info.st_mode), 'sha256': sha(path), 'bytes': info.st_size,
            'st_nlink': info.st_nlink}


def tooling_inputs():
    assert sha(ROOT / WRAPPER) == '923d477e8a1e58a8c24889082c9ac8aeef28d9035093c03147b7e79fe0c92586'
    assert sha(ROOT / OLD) == 'fc18879f713dd9a5d6b6c1bde9db24bc85d17e870a86a35b32e835496e0eb224'
    names = [WRAPPER, OLD, '.airbuild/tools/relay-build-2026111304.sh',
             '.airbuild/buildcandidate/relay-2026111304/build_driver.py',
             '.airbuild/buildcandidate/relay-2026111304/preparation-pins.json',
             '.airbuild/buildcandidate/relay-2026111304/test_build_driver.py',
             '.dart_tool/package_config.json', '.dart_tool/package_graph.json', '.flutter-plugins-dependencies']
    result = {name: entry(ROOT / name) for name in names}
    for name in ('flutter', 'go', 'cargo', 'rustc', 'rustup', 'xcrun', 'xcodebuild'):
        path = Path(shutil.which(name)).resolve(strict=True)
        result['executable:' + name] = {'path': str(path), **tool_entry(path)}
    return result


def preservation():
    roots = []
    for name in ('artifacts', 'buildcandidate', 'tools'):
        roots.extend(p for p in sorted((ROOT / '.airbuild' / name).iterdir())
                     if p not in (E, DEST.parent.parent, ROOT / '.airbuild/tools/relay-build-2026111304.sh'))
    roots.append(ROOT / '.airbuild/evidence')
    return {str(p.relative_to(ROOT)): tree(p) for p in roots}


def state(head):
    assert git('rev-parse', 'HEAD').strip() == head, 'HEAD changed'
    assert re.fullmatch('[0-9a-f]{40}', head)
    assert subprocess.run(['/usr/bin/git', 'merge-base', '--is-ancestor',
                           '9e7f602304ed1c849ac67675ee428fdf07832810', head], cwd=ROOT).returncode == 0
    reviewed = pins()
    for name, digest in reviewed['historical'].items():
        assert sha(ROOT / name) == digest, 'Frozen old03 evidence changed: ' + name
    for name, digest in reviewed['packaging'].items():
        assert sha(ROOT / 'macos/packaging' / (name + '.py')) == digest, 'Frozen packaging changed: ' + name
    for name, digest in reviewed['native_startup'].items():
        assert sha(ROOT / name) == digest, 'Native startup differs from old03: ' + name
    core = ROOT / 'core/Clash.Meta'
    gitlink = git('rev-parse', 'HEAD:core/Clash.Meta').strip()
    assert git('rev-parse', 'HEAD', cwd=core).strip() == gitlink, 'Submodule HEAD differs from current gitlink'
    assert git('status', '--porcelain', cwd=core) == '', 'Core submodule must be clean'
    identity = (ROOT / 'macos/Shared/HelperIdentity.h').read_text()
    for value in (f'#define FC_PINNED_CERTIFICATE_SHA1 "{CERT}"', '#define FC_PRODUCTION_TEAM_ID ""',
                  '#define FC_MANAGED_CANDIDATE_ENABLED 0', '#define FC_SPLIT_GUI_CDHASH ""'):
        assert value in identity, value
    spec = (ROOT / 'pubspec.yaml').read_text()
    assert 'version: 0.9.7+' in spec and spec.count('build_assets: true') == 2
    assert 'build_assets: false' not in spec
    assert json.loads((ROOT / 'env.json').read_text()) == {'APP_ENV': 'stable'}
    assert 'bool.fromEnvironment(\'MACOS_MANAGED_HELPER\')' in (ROOT / 'lib/core/desktop/macos_helper_client.dart').read_text()
    return {'source_head': head, 'source_status': git('status', '--porcelain'),
            'source_inputs': source_inputs(), 'core_submodule_head': gitlink,
            'sdk': sdk_inputs(), 'tooling': tooling_inputs(),
            'external_package_inputs': external_package_inputs(), 'sdk_native_inputs': sdk_native_inputs(),
            'retained_native_inputs': retained_native_inputs()}


def run(command, output, env=None):
    command = [str(x) for x in command]
    assert Path(command[0]).name in ('python3', 'flutter', 'go', 'cargo', 'rustc', 'rustup', 'xcodebuild', 'xcrun', 'otool'), 'Unapproved tool'
    with (E / 'commands.jsonl').open('a') as journal:
        journal.write(json.dumps({'argv': SANDBOX + command, 'output': output,
                                  'started_ns': time.time_ns()}) + '\n')
    print('COMMAND:', ' '.join(command), flush=True)
    with (E / output).open('wb') as stream:
        subprocess.run(SANDBOX + command, cwd=ROOT, env=env, stdout=stream,
                       stderr=subprocess.STDOUT, check=True)


def module(name):
    assert name in ('stage_split_payload', 'stage_managed_payload'), 'No signer/qualifier imports'
    assert sha(ROOT / 'macos/packaging' / (name + '.py')) == pins()['packaging'][name]
    spec = importlib.util.spec_from_file_location('_build_' + name, ROOT / 'macos/packaging' / (name + '.py'))
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    if name == 'stage_split_payload':
        result.load_local = module
    else:
        result.subprocess = types.SimpleNamespace(run=static_run, check_output=static_output)
    return result


def static_argv(command):
    argv = [str(value) for value in command]
    assert argv[0] in ('/usr/bin/otool', '/usr/bin/lipo', '/usr/bin/install_name_tool'), 'Unapproved stage tool'
    assert Path(argv[-1]).is_relative_to(DEST), 'Static tool target outside new stage'
    with (E / 'static-stage-commands.jsonl').open('a') as journal:
        journal.write(json.dumps({'argv': SANDBOX + argv, 'started_ns': time.time_ns()}) + '\n')
    return SANDBOX + argv


def static_run(command, **kwargs):
    return subprocess.run(static_argv(command), timeout=30, **kwargs)


def static_output(command, **kwargs):
    return subprocess.check_output(static_argv(command), timeout=30, **kwargs)


def parse_xcode_settings(raw):
    if raw.startswith(WARNING_PREFIX):
        clean = raw[len(WARNING_PREFIX):]
        warning = WARNING_PREFIX
    else:
        clean, warning = raw, ''
    settings = json.loads(clean)
    assert isinstance(settings, list) and settings, 'Expected nonempty Xcode settings list'
    assert sum(item.get('target') == 'Runner' for item in settings) == 1
    return clean, warning


def collect_xcode_settings(env):
    run(['xcrun', 'xcodebuild', '-showBuildSettings', '-json', '-workspace', 'macos/Runner.xcworkspace',
         '-scheme', 'Runner', '-configuration', 'Release', 'CODE_SIGNING_ALLOWED=NO'],
        'effective-xcode-settings.raw.txt', env)
    raw = (E / 'effective-xcode-settings.raw.txt').read_text()
    clean, warning = parse_xcode_settings(raw)
    (E / 'effective-xcode-settings.json').write_text(clean)
    (E / 'effective-xcode-settings.stderr.txt').write_text(warning)


def compile_evidence(head, frozen):
    settings = json.loads((E / 'effective-xcode-settings.json').read_text())
    r = next(item['buildSettings'] for item in settings if item['target'] == 'Runner')
    assert r['FC_MANAGED_CANDIDATE_ENABLED'] == '1'
    assert 'FC_MANAGED_CANDIDATE_ENABLED=1' in r['GCC_PREPROCESSOR_DEFINITIONS'].split()
    assert r['CODE_SIGNING_ALLOWED'] == 'NO' and r['ARCHS'] == 'arm64'
    assert 'FC_SPLIT_GUI_CDHASH' not in r['GCC_PREPROCESSOR_DEFINITIONS']
    info = plistlib.loads((APP / 'Contents/Info.plist').read_bytes())
    assert info['CFBundleShortVersionString'] == '0.9.7' and info['CFBundleVersion'] == '2026111304'
    assert info['CFBundleIdentifier'] == 'com.layoute.flash'
    assert not any(k in info for k in ('NSMainNibFile', 'NSMainStoryboardFile', 'NSPrincipalClass'))
    defines = [base64.b64decode(v, validate=True).decode() for v in info['FlashDartDefines'].split(',') if v]
    assert defines.count('MACOS_MANAGED_HELPER=true') == 1
    assert defines.count('FLUTTER_BUILD_NUMBER=2026111304') == 1
    save(E / 'sealed-dart-defines.json', defines)
    intermediates = ROOT / 'build/macos/Build/Intermediates.noindex/Runner.build/Release/Runner.build'
    responses = {str(p.relative_to(ROOT)): {'sha256': sha(p), 'contents': p.read_text()}
                 for p in intermediates.rglob('*.resp')}
    assert any('-DFC_MANAGED_CANDIDATE_ENABLED=1' in r['contents'] for r in responses.values())
    assert all('FC_SPLIT_GUI_CDHASH' not in r['contents'] for r in responses.values())
    save(E / 'runner-compile-responses.json', responses)
    objects = list(intermediates.rglob('FlashFlutterEngine.o'))
    assert len(objects) == 1, objects
    run(['/usr/bin/otool', '-tvV', objects[0]], 'FlashFlutterEngine-object-disassembly.txt')
    run(['/usr/bin/otool', '-ov', objects[0]], 'FlashFlutterEngine-object-objc.txt')
    assert 'loadAOTData:' in (E / 'FlashFlutterEngine-object-objc.txt').read_text()
    save(E / 'compiled-bootstrap-object.json', {str(p): entry(p) for p in objects})
    startup_objects = {}
    for name in ('FlashFlutterEngine', 'AppDelegate', 'MainFlutterWindow'):
        paths = list(intermediates.rglob(name + '.o'))
        assert len(paths) == 1, 'Missing fresh native bootstrap object: ' + name
        startup_objects[str(paths[0].relative_to(ROOT))] = entry(paths[0])
    save(E / 'native-bootstrap-objects.json', startup_objects)
    log = (E / 'flutter-build.log').read_text()
    assert '** BUILD SUCCEEDED **' in log and log.rstrip().endswith('exiting with code 0')
    assert 'gen_snapshot_arm64' in log and '--snapshot_kind=app-aot-macho-dylib' in log
    for native in ('FlashFlutterEngine.m', 'MainFlutterWindow.swift', 'AppDelegate.swift'):
        assert native in log, 'Missing fresh native compile evidence: ' + native
    save(E / 'actual-aot-compile-commands.json', [line for line in log.splitlines()
                                               if 'gen_snapshot_arm64' in line or 'frontend_server' in line])
    hook = ROOT / '.dart_tool/setup_build_cache/hook.log'
    shutil.copyfile(hook, E / 'setup-hook.log')
    assert 'exec: go build ' in hook.read_text() and 'Building Go core: darwin/arm64' in hook.read_text()
    assert sha(ROOT / 'libclash/macos/FlClashCore') == sha(APP / 'Contents/MacOS/FlClashCore')
    aot = list((ROOT / '.dart_tool/flutter_build').glob('*/arm64/App.framework/App'))
    assert len(aot) == 1 and arm64_bytes(aot[0]) == arm64_bytes(APP / 'Contents/Frameworks/App.framework/Versions/A/App')
    save(E / 'fresh-output-provenance.json', {'core': entry(ROOT / 'libclash/macos/FlClashCore'),
        'aot': {'source_path': str(aot[0]), **entry(aot[0])},
        'intermediate_helper_tools': 'Xcode legacy phase outputs discarded by stage_gui; NOT split service pins'})
    run(['go', 'version', '-m', APP / 'Contents/MacOS/FlClashCore'], 'core-buildinfo.txt')
    buildinfo = (E / 'core-buildinfo.txt').read_text()
    for required in ('path\tcore/cmd/core', '=>\t./Clash.Meta\t(devel)', 'GOOS=darwin', 'GOARCH=arm64', 'CGO_ENABLED=0', 'vcs.revision=' + head):
        assert required in buildinfo, 'Core buildinfo binding missing: ' + required
    core_inputs = {k: v for k, v in frozen['source_inputs'].items() if k.startswith('core/')}
    save(E / 'core-source-byte-binding.json', {'core_source_inputs': core_inputs,
        'submodule_head': frozen['core_submodule_head'], 'source_head': head,
        'fresh_go_build_command': True, 'libclash_core': entry(ROOT / 'libclash/macos/FlClashCore'),
        'compiled_bundle_core': entry(APP / 'Contents/MacOS/FlClashCore'),
        'go_buildinfo_sha256': sha(E / 'core-buildinfo.txt')})
    save(E / 'intermediate-helper-tools.json', {
        'discarded_at_gui_staging': True, 'split_service_pins': False,
        'source_inputs': {k: v for k, v in frozen['source_inputs'].items()
                          if k.startswith(('macos/PrivilegedHelper/', 'macos/Maintenance/', 'macos/Shared/'))},
        'fresh_build_library': tree(APP / 'Contents/Library')})
    sdk_binary = SDK / FRAMEWORK
    built_binary = APP / 'Contents/Frameworks/FlutterMacOS.framework/Versions/A/FlutterMacOS'
    assert arm64_bytes(sdk_binary) == arm64_bytes(built_binary)
    save(E / 'sdk-framework-binary-proof.json', {
        'sdk_container': entry(sdk_binary), 'build_container': entry(built_binary),
        'identical_arm64_slice_sha256': hashlib.sha256(arm64_bytes(sdk_binary)).hexdigest()})
    for name in ('Logs',):
        path = ROOT / 'build/macos' / name
        if path.exists():
            shutil.copytree(path, E / ('xcode-' + name), symlinks=True)
    return info


def build(head, freeze_sha):
    assert sha(FREEZE) == freeze_sha, 'Freeze receipt changed'
    frozen = json.loads(FREEZE.read_text())
    assert state(head) == immutable_frozen(frozen), 'Inputs changed after parent freeze'
    assert generated_observation() == frozen['generated_before'], 'Generated inputs changed after freeze'
    assert not DEST.parent.parent.exists() and not (E / 'build.started').exists(), 'Single attempt only; no overlay/fallback'
    (E / 'build.started').touch(exist_ok=False)
    before = preservation()
    assert before == frozen['protected'], 'Protected old outputs changed since freeze'
    save(E / 'preservation-before.json', before)
    save(E / 'source-inputs-before.json', frozen['source_inputs'])
    save(E / 'sdk-inputs-before.json', frozen['sdk'])
    for field, prefix in (('external_package_inputs', 'external-package-inputs'),
                          ('sdk_native_inputs', 'sdk-native-inputs'),
                          ('retained_native_inputs', 'retained-native-inputs')):
        save(E / (prefix + '-before.json'), frozen[field])
    result = {'status': 'failed', 'runtime_acceptance': False, 'actualGUIloads': False,
              'packaging_accepted': False, 'private_key_signing_performed': False}
    try:
        env = os.environ.copy()
        env['XCODE_XCCONFIG_FILE'] = str(E / 'candidate.xcconfig')
        (E / 'candidate.xcconfig').write_text('FC_MANAGED_CANDIDATE_ENABLED = 1\nGCC_PREPROCESSOR_DEFINITIONS = $(inherited) FC_MANAGED_CANDIDATE_ENABLED=$(FC_MANAGED_CANDIDATE_ENABLED)\nCODE_SIGNING_ALLOWED = NO\n')
        env['FLUTTER_ENGINE_SOURCE'] = str(SDK / 'engine/src/flutter')
        run(['/usr/bin/python3', '-I', '-S', '-B', 'macos/RunnerTests/test_flutter_bootstrap.py'], 'bootstrap-sdk-contract-tests.log', env)
        for command, output in [([SDK / 'bin/flutter', '--version', '--machine'], 'flutter-version.json'),
                                (['go', 'version'], 'go-version.txt'), (['cargo', '--version'], 'cargo-version.txt'),
                                (['rustc', '--version'], 'rust-version.txt'), (['rustup', 'toolchain', 'list'], 'rust-toolchains.txt'),
                                (['xcodebuild', '-version'], 'xcode-version.txt'), (['xcrun', 'clang', '--version'], 'clang-version.txt')]:
            run(command, output, env)
        moved, preserved_inventories = archive_generated(frozen['generated_before'])
        assert not APP.exists() and not (ROOT / 'libclash/macos/FlClashCore').exists()
        run([SDK / 'bin/flutter', '-v', 'build', 'macos', '--release', '--no-pub',
             '--dart-define-from-file=env.json', '--dart-define=MACOS_MANAGED_HELPER=true',
             '--build-name=0.9.7', '--build-number=2026111304'], 'flutter-build.log', env)
        collect_xcode_settings(env)
        info = compile_evidence(head, frozen)
        save(E / 'retained-native-bundle-proof.json', verify_retained_frameworks(frozen['retained_native_inputs']))
        assert state(head) == immutable_frozen(frozen), 'Input changed during compile'
        fresh_tree = tree(APP)
        save(E / 'fresh-build-input-inventory.json', fresh_tree)
        split = module('stage_split_payload')
        with (E / 'stage-gui.log').open('x') as stream:
            with contextlib.redirect_stdout(stream):
                split.stage_gui(APP, DEST)
        assert tree(APP) == fresh_tree, 'Staging mutated fresh compile output'
        entries = split.verify_split_gui(DEST)
        targets = []
        magic = module('stage_managed_payload').MACH_MAGIC
        for relative, item in entries.items():
            p = DEST / relative
            if item.get('kind') == 'file' and p.read_bytes()[:4] in magic:
                architectures = static_output(['/usr/bin/lipo', '-archs', p], text=True).split()
                assert architectures == ['arm64']
                targets.append({'path': relative, 'architectures': architectures, **item})
        verify_stage_modes(entries, magic)
        assert len(targets) == 7 and not (DEST / 'Contents/Library').exists()
        assert sha(DEST / 'Contents/MacOS/FlClashCore') == sha(APP / 'Contents/MacOS/FlClashCore')
        save(E / 'candidate-file-manifest.json', entries)
        save(E / 'macho-inventory.json', targets)
        unsigned = tree(DEST)
        save(E / 'unsigned-stage-inventory.json', unsigned)
        pre_sign = receipt_inventory(DEST, unsigned, magic)
        save(E / 'unsigned-pre-sign-inventory.json', pre_sign)
        assert tree(DEST) == unsigned, 'Static verification mutated staged output'
        metadata = {'schema': 'flash-split-build-v1', 'build_configuration': 'Release',
            'version': '0.9.7', 'build_number': '2026111304', 'source_head': head,
            'source_freeze_sha256': freeze_sha, 'source_status': frozen['source_status'],
            'defines': {'APP_ENV': 'stable', 'MACOS_MANAGED_HELPER': True,
                        'FC_MANAGED_CANDIDATE_ENABLED': 1, 'FC_PINNED_CERTIFICATE_SHA1': CERT},
            'certificate_sha1': CERT, 'apple_team': '', 'startup_hardened': True,
            'startup_hardening_scope': 'static source/SDK-contract and compiled ObjC evidence only; no launch',
            'startup_source_hashes': {k: v for k, v in frozen['source_inputs'].items()
                                      if k.startswith('macos/Runner/') or k == 'macos/Runner.xcodeproj/project.pbxproj'},
            'sdk': frozen['sdk'], 'network_sandbox': 'deny network*', 'xcode_code_signing_allowed': False,
            'gui_cdhash_compile_default': '', 'split_service_staged': False,
            'helper_compile_with_gui_pin_pending': True, 'architectures': ['arm64'], 'macho_count': 7,
            'flutter_release_compile_succeeded': True, 'static_stage_audit_passed': True,
            'fresh_core_built': True, 'fresh_gui_aot_built': True, 'signing_performed': False,
            'runtime_acceptance': False, 'actualGUIloads': False, 'packaging_accepted': False,
            'production_components_executed': False,
            'retained_native_dependencies_fresh': False,
            'retained_native_dependency_names': ['objective_c', 'rust_api', 'sqlite3'],
            'external_package_bytes_bound': True, 'sdk_native_bytes_bound': True,
            'generated_outputs_archived_before_compile': True}
        assert state(head) == immutable_frozen(frozen) and preservation() == before
        assert all(tree(Path(moved[name])) == inventory for name, inventory in preserved_inventories.items()), 'Archived prior outputs changed'
        assert info['CFBundleVersion'] == metadata['build_number'] == '2026111304'
        metadata['parent_owned_signing_probe_pending'] = True
        metadata['frozen_old03_qualifier_invoked'] = False
        metadata['core_submodule_head'] = frozen['core_submodule_head']
        metadata['gui_stage_path'] = str(DEST)
        metadata['unsigned_tree_sha256'] = pre_sign['tree_sha256']
        result['status'] = 'static-build-and-gui-stage-passed'
    except BaseException:
        (E / 'failure-traceback.txt').write_text(traceback.format_exc())
        raise
    finally:
        try:
            after = state(head)
        except BaseException:
            (E / 'after-state-failure-traceback.txt').write_text(traceback.format_exc())
            after = {'source_inputs': source_inputs(), 'sdk': sdk_observation(), 'state_validation_failed': True}
        save(E / 'source-inputs-after.json', after['source_inputs'])
        save(E / 'sdk-inputs-after.json', after['sdk'])
        for field, prefix in (('external_package_inputs', 'external-package-inputs'),
                              ('sdk_native_inputs', 'sdk-native-inputs'),
                              ('retained_native_inputs', 'retained-native-inputs')):
            save(E / (prefix + '-after.json'), after.get(field, {'state_validation_failed': True}))
            result[field + '_unchanged'] = after.get(field) == frozen[field]
        preserved_after = preservation()
        save(E / 'preservation-after.json', preserved_after)
        result['source_unchanged'] = after == immutable_frozen(frozen)
        result['sdk_unchanged'] = after['sdk'] == frozen['sdk']
        result['all_prior_artifacts_evidence_tools_preserved'] = before == preserved_after
        if 'preserved_inventories' in locals():
            result['archived_generated_outputs_preserved'] = all(
                tree(Path(moved[name])) == inventory for name, inventory in preserved_inventories.items())
        else:
            result['archived_generated_outputs_preserved'] = True
        if not (result['source_unchanged'] and result['sdk_unchanged']
                and result['all_prior_artifacts_evidence_tools_preserved']
                and result['archived_generated_outputs_preserved']):
            result['status'] = 'failed'
        save(E / 'build-result.json', result)
        assert after == immutable_frozen(frozen), 'Build changed frozen inputs'
        assert before == preserved_after, 'Protected artifact/guard changed'
        assert result['archived_generated_outputs_preserved'], 'Archived generated outputs changed'
    metadata['compile_evidence'] = evidence_mapping()
    proof_names = ('input-freeze.json', 'sdk-inputs-before.json', 'sdk-inputs-after.json',
                   'source-inputs-before.json', 'source-inputs-after.json', 'build-result.json',
                   'fresh-build-input-inventory.json', 'candidate-file-manifest.json', 'macho-inventory.json',
                   'unsigned-stage-inventory.json', 'unsigned-pre-sign-inventory.json',
                   'core-source-byte-binding.json', 'native-bootstrap-objects.json',
                   'sdk-framework-binary-proof.json', 'preservation-before.json', 'preservation-after.json')
    metadata['fresh_build_provenance'] = {
        'schema': 'flash-relay-fresh-build-proof-v1', 'compile_count': 1,
        'rebuild_continuation': False, 'evidence_root': str(E),
        'driver_sha256': sha(Path(__file__)), 'preparation_pins_sha256': PINS_SHA256,
        'files': {name: {'path': name, 'sha256': sha(E / name)} for name in proof_names},
        'compile_evidence': metadata['compile_evidence']}
    save(E / 'build-metadata.json', metadata)
    print('STAGED_GUI=' + str(DEST))
    print('BUILD_METADATA=' + str(E / 'build-metadata.json'))


def evidence_mapping():
    return {str(p.relative_to(E)): sha(p) for p in sorted(E.rglob('*'))
            if p.is_file() and 'prior-generated' not in p.relative_to(E).parts
            and p.name != 'build-metadata.json'}


def receipt_inventory(app, entries, magic):
    result = {}
    for name, item in entries.items():
        if name == '.':
            continue
        record = {'mode': oct(item['mode'])}
        if 'symlink' in item:
            record.update(kind='symlink', target=item['symlink'])
        elif 'directory' in item:
            record['kind'] = 'directory'
        else:
            with (app / name).open('rb') as stream:
                macho = stream.read(4) in magic
            record.update(kind='file', macho=macho, sha256=item['sha256'], size=item['bytes'])
        result[name] = record
    canonical = json.dumps(result, sort_keys=True, separators=(',', ':')).encode()
    return {'tree_sha256': hashlib.sha256(canonical).hexdigest(), 'entries': result}


def verify_stage_modes(entries, magic, app=DEST):
    for name, item in entries.items():
        if item['kind'] == 'file':
            with (app / name).open('rb') as stream:
                macho = stream.read(4) in magic
            assert item['mode'] == (0o755 if macho else 0o644), 'Unexpected staged file mode: ' + name
        elif item['kind'] == 'directory':
            assert item['mode'] == 0o755, 'Unexpected staged directory mode: ' + name


def main():
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('mode', choices=('freeze', 'build'))
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--freeze-sha256')
    parser.add_argument('--parent-go', required=True)
    args = parser.parse_args()
    assert args.parent_go == AUTHORIZATION, 'Explicit parent GO required for freeze AND build'
    assert sys.flags.optimize == 0, 'Assertions must not be disabled'
    os.chdir(ROOT)
    os.umask(0o027)
    if args.mode == 'freeze':
        assert not FREEZE.exists(), 'Freeze is append-only; review inputs before freezing'
        assert not (E / 'build.started').exists() and not DEST.parent.parent.exists()
        frozen = state(args.expected_head)
        frozen['protected'] = preservation()
        frozen['generated_before'] = generated_observation()
        assert state(args.expected_head) == immutable_frozen(frozen)
        save(FREEZE, frozen)
        print('FREEZE_SHA256=' + sha(FREEZE))
    else:
        assert args.parent_go == 'relay-2026111304-gui-compile-and-stage', 'Explicit parent build authorization required'
        assert re.fullmatch('[0-9a-f]{64}', args.freeze_sha256 or '')
        build(args.expected_head, args.freeze_sha256)


if __name__ == '__main__':
    main()
