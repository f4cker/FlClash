case "$0" in */packaging/stage_managed_helper.sh) PS4="+ managed-native-trace "; set -x ;; esac
