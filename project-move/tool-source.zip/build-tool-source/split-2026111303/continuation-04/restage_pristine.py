"""One-shot pristine GUI restage; no compile, signing, runtime, or current qualifier."""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import plistlib
import shutil
import stat
import subprocess
import traceback

ROOT = Path('/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup')
BASE = ROOT / '.airbuild/buildcandidate/split-2026111303'
OLD = BASE / 'continuation-03'
OUT = BASE / 'continuation-04'
FRESH = ROOT / 'build/macos/Build/Products/Release/Flash.app'
PRIOR_GUI = ROOT / '.airbuild/artifacts/split-2026111303/gui'
RECEIPT = PRIOR_GUI / 'Flash.gui-signing-static.json'
DEST = ROOT / '.airbuild/artifacts/split-2026111303-retry01/gui/Flash.app'
FREEZE_SHA = 'd756cb259a694520d7571dcda37866bc3f6fe9d54df520565f131701a8c66a87'
METADATA_SHA = 'd829dafa7d793ee910f2e0aa3368e27b09af48a4696991a5f36ceca03a21c32e'
RECEIPT_SHA = '6fa87c6505f891674f1cab06bbf79e3d3c25f9f4bb3378924bf1db6662d751a0'
TOOLS = {
    'stage_split_payload': 'e7ac7091762dd12301540f34e58b06f66c27b8e1153c3c1caf77fb1d6be1d06f',
    'stage_managed_payload': '006b6d11b10d0875654fab009e7b6a231ebfb83f12cbb0a8c77ec0c463d65829',
}
APP = 'Contents/Frameworks/App.framework/Versions/A/App'
FLUTTER = 'Contents/Frameworks/FlutterMacOS.framework/Versions/A/FlutterMacOS'
SQLITE = 'Contents/Frameworks/sqlite3.framework/Versions/A/sqlite3'
RESOURCE = 'Contents/Resources/LaunchAtLogin_LaunchAtLogin.bundle/Contents/Resources/copy-helper-swiftpm.sh'


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def save(name, value):
    with (OUT / name).open('x') as stream:
        stream.write(json.dumps(value, sort_keys=True, indent=2) + '\n')


def entry(path):
    s = path.lstat()
    result = {'mode': stat.S_IMODE(s.st_mode)}
    if stat.S_ISLNK(s.st_mode):
        result['symlink'] = os.readlink(path)
    elif stat.S_ISREG(s.st_mode):
        require(s.st_nlink == 1, 'Hardlinked input: ' + str(path))
        result.update(sha256=sha(path), bytes=s.st_size)
    elif stat.S_ISDIR(s.st_mode):
        result['directory'] = True
    else:
        raise ValueError('Special input: ' + str(path))
    return result


def tree(root):
    require(root.is_dir() and not root.is_symlink(), 'Expected real tree: ' + str(root))
    result = {'.': entry(root)}
    for directory, names, files in os.walk(root, followlinks=False):
        for name in sorted(names + files):
            path = Path(directory) / name
            result[str(path.relative_to(root))] = entry(path)
    return result


def delta(before, after):
    return {name: {'before': before.get(name), 'after': after.get(name)}
            for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)}


def pinned_module(name, frozen):
    path = ROOT / 'macos/packaging' / (name + '.py')
    require(sha(path) == TOOLS[name] == frozen['source_inputs'][str(path.relative_to(ROOT))]['sha256'],
            'Staging module changed: ' + name)
    mode = path.stat()
    require(not path.is_symlink() and mode.st_nlink == 1 and mode.st_uid == os.getuid()
            and not mode.st_mode & 0o022, 'Unsafe executable tooling: ' + name)
    spec = importlib.util.spec_from_file_location('_pristine_' + name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def receipt_inventory(app, entries, magic):
    result = {}
    for name, item in entries.items():
        if name == '.':
            continue
        record = {'mode': oct(item['mode'])}
        if 'symlink' in item:
            record.update(kind='symlink', target=item['symlink'])
        elif 'directory' in item:
            record['kind'] = 'directory'
        else:
            with (app / name).open('rb') as stream:
                macho = stream.read(4) in magic
            record.update(kind='file', macho=macho, sha256=item['sha256'], size=item['bytes'])
        result[name] = record
    return result


def main():
    os.umask(0o077)
    require(not DEST.parent.parent.exists(), 'Retry artifact root already exists')
    require(sha(OLD / 'build-metadata.json') == METADATA_SHA, 'Original metadata changed')
    require(sha(BASE / 'input-freeze.json') == FREEZE_SHA, 'Original freeze changed')
    require(sha(RECEIPT) == RECEIPT_SHA, 'Failed signing receipt changed')
    original = load(OLD / 'build-metadata.json')
    frozen = load(BASE / 'input-freeze.json')
    for base, key in ((BASE, 'compile_evidence'), (OLD, 'stage_evidence')):
        for name, expected in original[key].items():
            require(sha(base / name) == expected, 'Original evidence changed: ' + name)
    fresh_expected = load(BASE / 'continuation-01/fresh-build-input-inventory.json')
    require(tree(FRESH) == fresh_expected, 'Preserved fresh build is not pristine')
    protected = {'original_gui_and_failed_receipt': tree(PRIOR_GUI),
                 'original_top_level_evidence': {p.name: entry(p) for p in BASE.iterdir() if p.is_file()},
                 'prior_continuations': {f'continuation-{i:02d}': tree(BASE / f'continuation-{i:02d}')
                                         for i in range(1, 4)}}
    split = pinned_module('stage_split_payload', frozen)
    verifier = pinned_module('stage_managed_payload', frozen)
    verifier.FIXED_EXECUTABLES = (split.CORE,)
    def frozen_local(name):
        require(name == 'stage_managed_payload', 'Unapproved runtime import')
        return verifier
    split.load_local = frozen_local
    expected_tree = load(OLD / 'stage-inventory-after-audit.json')
    expected_manifest = load(OLD / 'candidate-file-manifest.json')
    expected_macho = load(OLD / 'macho-inventory.json')
    binaries = {item['path'] for item in expected_macho}
    receipt_before = load(RECEIPT)['before']
    save('preservation-before.json', protected)
    save('original-pre-sign-inventory.json', receipt_before)
    save('fresh-build-input-inventory.json', fresh_expected)
    (OUT / 'continuation.started').touch(exist_ok=False)
    mutations = [
        ['/usr/bin/install_name_tool', '-delete_rpath', '/usr/local/lib/.', str(DEST / FLUTTER)],
        ['/usr/bin/install_name_tool', '-delete_rpath', '@executable_path/Frameworks',
         '-delete_rpath', '@loader_path/Frameworks', str(DEST / APP)],
    ]
    executed_mutations = []
    native_run = subprocess.run
    outcome = {'status': 'failed', 'rebuild_performed': False, 'signing_performed': False,
               'production_components_executed': False, 'actualGUIloads': False,
               'runtime_acceptance': False, 'packaging_accepted': False}
    with (OUT / 'static-audit-commands.jsonl').open('x') as commands:
        def bounded_static_run(args, **kwargs):
            argv = [str(arg) for arg in args]
            read_commands = [prefix + [str(DEST / name)] for name in binaries for prefix in (
                ['/usr/bin/otool', '-arch', 'all', '-l'], ['/usr/bin/lipo', '-archs'])]
            require(not kwargs.get('shell') and argv in read_commands + mutations, 'Unapproved command: ' + repr(argv))
            if argv in mutations:
                require(argv not in executed_mutations, 'Duplicate binary normalization')
                executed_mutations.append(argv)
            commands.write(json.dumps({'argv': argv}) + '\n')
            commands.flush()
            kwargs['timeout'] = 30
            return native_run(argv, **kwargs)
        subprocess.run = bounded_static_run
        try:
            split.inventory(FRESH)
            split.new_destination(DEST, [FRESH])
            shutil.copytree(FRESH, DEST, symlinks=True)
            require(tree(DEST) == fresh_expected, 'Fresh copy differs before normalization')
            for name in ('Contents/Library', 'Contents/_CodeSignature'):
                path = DEST / name
                if path.exists():
                    require(path.is_dir() and not path.is_symlink(), 'Unexpected removable staging path')
                    shutil.rmtree(path)
            for directory, _, files in os.walk(DEST, followlinks=False):
                Path(directory).chmod(0o755)
                for name in files:
                    path = Path(directory) / name
                    if not path.is_symlink():
                        path.chmod(0o755 if path.stat().st_mode & 0o111 else 0o644)
            before = tree(DEST)
            require(before == load(BASE / 'continuation-02/stage-inventory-before.json'),
                    'Original initial staging state not reproduced')
            save('stage-inventory-before.json', before)
            for name in (APP, SQLITE):
                require(before[name]['mode'] == 0o644, 'Unexpected initial executable mode')
                (DEST / name).chmod(0o755)
            initial_modes = tree(DEST)
            require(initial_modes == load(BASE / 'continuation-02/stage-inventory-after-modes.json'),
                    'Initial mode-normalized state not reproduced')
            save('initial-mode-only-delta.json', delta(before, initial_modes))
            split.check_layout(DEST, 'gui')
            verifier.audit(DEST, mutate=True)
            require(sorted(executed_mutations) == sorted(mutations), 'Exact two normalizations required')
            mutated = tree(DEST)
            expected_mutated = load(BASE / 'continuation-02/stage-inventory-after-audit.json')
            for name in (APP, FLUTTER):
                require(mutated[name]['mode'] in (0o700, 0o750, 0o755), 'Unexpected install_name_tool output mode')
                expected_mutated[name]['mode'] = mutated[name]['mode']
            require(mutated == expected_mutated, 'Mutable audit differed from historical normalized bytes')
            save('audit-normalization-delta.json', delta(initial_modes, mutated))
            for name in (APP, FLUTTER):
                (DEST / name).chmod(0o755)
            require(mutated[RESOURCE]['mode'] == 0o755, 'Unexpected known resource mode')
            (DEST / RESOURCE).chmod(0o644)
            normalized = tree(DEST)
            save('final-mode-only-delta.json', delta(mutated, normalized))
            require(normalized == expected_tree, 'Final unsigned tree differs from original')
            manifest = split.verify_split_gui(DEST)
            final_tree = tree(DEST)
            require(final_tree == normalized and manifest == expected_manifest, 'Read-only verification changed inventory')
            save('stage-inventory-after-audit.json', final_tree)
            save('candidate-file-manifest.json', manifest)
            actual_macho = []
            for target in expected_macho:
                name = target['path']
                archs = subprocess.check_output(['/usr/bin/lipo', '-archs', str(DEST / name)], text=True).split()
                actual_macho.append({'path': name, 'architectures': archs, **manifest[name]})
            require(actual_macho == expected_macho and len(actual_macho) == 7, 'Seven binary hash/mode/architecture mismatch')
            save('macho-inventory.json', actual_macho)
            pre_sign = receipt_inventory(DEST, final_tree, verifier.MACH_MAGIC)
            require(pre_sign == receipt_before['entries'], 'Failed receipt pre-sign entries do not match retry')
            canonical = json.dumps(pre_sign, sort_keys=True, separators=(',', ':')).encode()
            require(hashlib.sha256(canonical).hexdigest() == receipt_before['tree_sha256'], 'Pre-sign receipt tree digest mismatch')
            save('retry-pre-sign-inventory.json', {'entries': pre_sign, 'tree_sha256': receipt_before['tree_sha256']})
            info = plistlib.loads((DEST / 'Contents/Info.plist').read_bytes())
            require(info['CFBundleShortVersionString'] == '0.9.7' and info['CFBundleVersion'] == '2026111303'
                    and info['CFBundleIdentifier'] == 'com.layoute.flash', 'Bundle identity changed')
            outcome['status'] = 'pristine-unsigned-restage-passed'
        except BaseException:
            with (OUT / 'failure-traceback.txt').open('x') as stream:
                stream.write(traceback.format_exc())
            raise
        finally:
            subprocess.run = native_run
            preserved_after = {'original_gui_and_failed_receipt': tree(PRIOR_GUI),
                               'original_top_level_evidence': {p.name: entry(p) for p in BASE.iterdir() if p.is_file()},
                               'prior_continuations': {f'continuation-{i:02d}': tree(BASE / f'continuation-{i:02d}')
                                                       for i in range(1, 4)}}
            save('preservation-after.json', preserved_after)
            outcome.update(original_artifact_receipt_and_provenance_unchanged=protected == preserved_after,
                           fresh_build_input_unchanged=tree(FRESH) == fresh_expected,
                           staging_modules_unchanged=all(sha(ROOT / 'macos/packaging' / (n + '.py')) == h for n, h in TOOLS.items()))
            save('continuation-result.json', outcome)
            require(all(outcome[k] for k in ('original_artifact_receipt_and_provenance_unchanged',
                    'fresh_build_input_unchanged', 'staging_modules_unchanged')), 'Preservation check failed')
    save('continuation-provenance.json', {
        'schema': 'flash-split-pristine-restage-v1', 'source_sha256': sha(Path(__file__)),
        'source_freeze_sha256': FREEZE_SHA, 'original_metadata_sha256': METADATA_SHA,
        'original_metadata_path': str(OLD / 'build-metadata.json'),
        'fresh_build_input': str(FRESH), 'fresh_build_input_inventory_sha256': sha(BASE / 'continuation-01/fresh-build-input-inventory.json'),
        'failed_signing_receipt': str(RECEIPT), 'failed_signing_receipt_sha256': RECEIPT_SHA,
        'original_pre_sign_tree_sha256': receipt_before['tree_sha256'], 'destination': str(DEST),
        'staging_module_sha256': TOOLS, 'historical_normalizations_reproduced': True,
        'exact_unsigned_tree_manifest_and_seven_macho_match': True,
        'source_validation_scope': 'original compiled-input freeze and preserved fresh output; current signer/constraint/qualifier delta proof deferred pending final reviewed pins',
        'original_evidence_unchanged': True, 'original_partially_signed_gui_unchanged': True,
        'rebuild_performed': False, 'signing_performed': False, 'production_components_executed': False,
        'authorization': 'User2903 new pristine retry01 stage from preserved build; original artifact and provenance retained',
        'normalization_scope': 'original split copy/remove-helper/signature/normal modes; App+sqlite3 initial mode fixes; exact two rpath edits and NativeAssetsManifest rewrite; App+FlutterMacOS final modes and one known resource mode',
    })
    metadata = copy.deepcopy(original)
    metadata['compile_evidence'].update({'continuation-03/' + name: value for name, value in original['stage_evidence'].items()})
    metadata['compile_evidence']['continuation-03/build-metadata.json'] = METADATA_SHA
    metadata['stage_evidence'] = {p.name: sha(p) for p in OUT.iterdir() if p.is_file()}
    metadata['evidence_continuations'].append({
        'path': str(OUT / 'continuation-provenance.json'), 'sha256': sha(OUT / 'continuation-provenance.json'),
        'result': 'pristine preserved fresh build restaged; exact original unsigned tree, manifest and seven Mach-O hashes/modes reproduced'})
    metadata['pristine_restage'] = {
        'schema': 'flash-split-pristine-restage-v1', 'gui': str(DEST),
        'original_build_metadata': str(OLD / 'build-metadata.json'), 'original_build_metadata_sha256': METADATA_SHA,
        'inventory_prefix': 'continuation-04/', 'unsigned_pre_sign_tree_sha256': receipt_before['tree_sha256'],
        'exact_original_unsigned_inventory': True, 'final_signing_tooling_delta_proof_pending': True,
    }
    save('build-metadata.json', metadata)
    print('GUI=' + str(DEST))
    print('METADATA=' + str(OUT / 'build-metadata.json'))
    print('METADATA_SHA256=' + sha(OUT / 'build-metadata.json'))
    for name in ('continuation-provenance.json', 'stage-inventory-after-audit.json', 'candidate-file-manifest.json', 'macho-inventory.json'):
        print(name + '=' + sha(OUT / name))


if __name__ == '__main__':
    main()
