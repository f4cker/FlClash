import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess

ROOT = Path('/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup')
BASE = ROOT / '.airbuild/buildcandidate/split-2026111303'
OUT = BASE / 'signing-continuation-02'
FINAL = BASE / 'continuation-04'
APP = ROOT / '.airbuild/artifacts/split-2026111303-retry01/gui/Flash.app'
SDK = Path('/Users/layoute/fvm/versions/3.47.4')
GUARD = ROOT / '.airbuild/evidence/mac-authorization/signing-provision/split-2026111303-retry01/gui'
FREEZE_SHA = 'd756cb259a694520d7571dcda37866bc3f6fe9d54df520565f131701a8c66a87'
METADATA_SHA = '0327f163c9707bcfe43c6feee6b657a572535c05d4b94fa4da2b701a4bcd4fd9'
MANIFEST_SHA = '34da3de829f57fa2ce372c2e15e49c7c6d47c8fccebf875b6d18dd36d4a47fcd'
ALLOWED = tuple('macos/packaging/' + name for name in (
    'sign_split_payload.py', 'qualify_split_loads.py',
    'Tests/test_split_signing.py', 'Tests/test_split_qualification.py',
    'library_constraint.py', 'Tests/test_library_constraint.py'))
GUARD_NAMES = ('guard.m', 'pipe_signing_session_password.py', 'signing-session-guard')
RATIONALE = 'Post-build signing/constraint/qualification tooling and regression tests only; no compiler input or unsigned GUI byte changes permitted.'

PRIOR_PREFLIGHT = BASE / 'signing-continuation-01'
PRIOR_APP = ROOT / '.airbuild/artifacts/split-2026111303/gui/Flash.app'
PRIOR_RECEIPT = PRIOR_APP.parent / 'Flash.gui-signing-static.json'
PRIOR_RECEIPT_SHA = '6fa87c6505f891674f1cab06bbf79e3d3c25f9f4bb3378924bf1db6662d751a0'
PRIOR_PREFLIGHT_PINS = {'GUI_SIGNING_ATTEMPTED': {'mode': 384, 'bytes': 87, 'sha256': '4b2d378a884d7be28092a45d8dc8ad6a0bd6f9e9f69046798b6d57c1f7738e29'}, 'approval-template.json': {'mode': 384, 'bytes': 1402, 'sha256': '0695034fda433e2826346bb3d3827a7549af2a47def5d7d1ebe4e07b8e642cec'}, 'approved-pins.json': {'mode': 384, 'bytes': 1999, 'sha256': '95840dc6efe1bda7cba4d735ba3a4e0cd22496d06b7cf80886f89b5038c47233'}, 'guard-preservation-observation.json': {'mode': 384, 'bytes': 4406, 'sha256': 'a858ce13f80241864ed3f5b71de95e92e540db373008a676fd83e86751279f97'}, 'preflight.py': {'mode': 384, 'bytes': 13568, 'sha256': '227f0e48dbdc3311b975d8905562ee640bc989f62bd75095f89b53868b8ea174'}, 'prepared.json': {'mode': 384, 'bytes': 3125, 'sha256': '1eeb851d586d22ffafde2d4d041267ef2324c018ca422a77885fbb402bc5fa22'}, 'pure-mock-tests.log': {'mode': 384, 'bytes': 112, 'sha256': 'b986091cdd4d7aeb1185de9a51d74065913d71702d10fa5dada3e4c584a2ddd7'}, 'test_preflight.py': {'mode': 384, 'bytes': 5204, 'sha256': '5a182bcfbcde5fef7864e10ac80e0eb704c2aeaa13c1b0df28e175d4bafbad0a'}, 'tooling-delta.json': {'mode': 384, 'bytes': 6535, 'sha256': '7bf314a8b6a221ad94513c4508e4afd3e75ff4e6885bac8360444866761d2f5c'}}


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(descriptor, 'rb') as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode), 'Expected regular data: ' + str(path))
        data = stream.read()
        after = os.fstat(stream.fileno())
        named = path.lstat()
    fields = ('st_dev', 'st_ino', 'st_size', 'st_mode', 'st_uid', 'st_gid', 'st_nlink', 'st_mtime_ns', 'st_ctime_ns')
    require(all(getattr(before, key) == getattr(after, key) == getattr(named, key) for key in fields), 'Input changed while reading: ' + str(path))
    return data


def entry(path):
    mode = stat.S_IMODE(path.lstat().st_mode)
    if path.is_symlink():
        return {'mode': mode, 'symlink': os.readlink(path)}
    require(path.is_file(), 'Expected regular file: ' + str(path))
    data = read(path)
    return {'mode': mode, 'bytes': len(data), 'sha256': digest(data)}


def pinned_json(path, expected):
    require(re.fullmatch('[0-9a-f]{64}', expected or '') is not None, 'Missing final hash pin')
    data = read(path)
    require(digest(data) == expected, 'Pinned input changed: ' + str(path))
    return json.loads(data)


def save(name, value):
    path = OUT / name
    data = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, 'wb') as stream:
        stream.write(data)
    return digest(data)


def git(*args, cwd=ROOT):
    return subprocess.check_output(['/usr/bin/git', '--no-optional-locks', *args], cwd=cwd, text=True)


def source_inputs(directory=ROOT, prefix=''):
    result = {}
    names = set(git('ls-files', '-z', '--cached', '--others', '--exclude-standard', cwd=directory).split('\0')) - {''}
    for name in sorted(names):
        path, key = directory / name, prefix + name
        if not path.exists() and not path.is_symlink():
            result[key] = {'missing': True}
        elif path.is_dir() and not path.is_symlink():
            result[key] = {'gitlink_head': git('rev-parse', 'HEAD', cwd=path).strip(),
                           'status': git('status', '--porcelain', cwd=path)}
            result.update(source_inputs(path, key + '/'))
        else:
            result[key] = entry(path)
    return result


def source_delta(before, after, approved):
    require(set(approved) == set(ALLOWED), 'Exact six tooling pins required')
    require(set(before) == set(after), 'Source added or removed after build freeze')
    for name in before:
        if name not in ALLOWED:
            require(before[name] == after[name], 'Nonallowlisted source changed: ' + name)
    result = {}
    for name in ALLOWED:
        require(after[name] == approved[name], 'Reviewed tooling pin mismatch: ' + name)
        require(set(after[name]) == {'mode', 'bytes', 'sha256'}, 'Tooling must remain regular source')
        require(after[name]['mode'] == before[name]['mode'], 'Source permission change not authorized: ' + name)
        require(re.fullmatch('[0-9a-f]{64}', after[name]['sha256']) is not None, 'Placeholder source pin')
        result[name] = {'before': before[name], 'after': after[name], 'rationale': RATIONALE}
    return result


def inventory(app):
    require(app.is_dir() and not app.is_symlink(), 'Expected unchanged real GUI directory')
    result = {}
    for directory, names, files in os.walk(app, followlinks=False):
        for name in sorted(names + files):
            path = Path(directory) / name
            mode = path.lstat().st_mode
            item = {'mode': stat.S_IMODE(mode)}
            if stat.S_ISLNK(mode):
                require(path.resolve(strict=True).is_relative_to(app.resolve()), 'Escaping GUI link')
                item.update(kind='link', target=os.readlink(path))
            elif stat.S_ISREG(mode):
                require(path.stat().st_nlink == 1, 'Hardlinked GUI input')
                item.update(kind='file', sha256=digest(read(path)))
            elif stat.S_ISDIR(mode):
                item['kind'] = 'directory'
            else:
                raise ValueError('Special GUI node')
            result[str(path.relative_to(app))] = item
    return result


def match_inventory(actual, expected):
    require(actual == expected, 'Unsigned GUI differs from exact final unsigned manifest')


def evidence_path(base, relative):
    path = base / relative
    require(path.resolve(strict=True).is_relative_to(BASE.resolve()), 'Evidence escapes original build evidence')
    return path.resolve(strict=True)


def literal(source, name):
    values = [node.value.value for node in ast.parse(source).body
              if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets)
              and isinstance(node.value, ast.Constant)]
    require(len(values) == 1, 'Expected one literal pin: ' + name)
    return values[0]


def prior_attempt_preserved():
    require({p.name for p in PRIOR_PREFLIGHT.iterdir()} == set(PRIOR_PREFLIGHT_PINS),
            'Original preflight evidence set changed')
    require({name: entry(PRIOR_PREFLIGHT / name) for name in PRIOR_PREFLIGHT_PINS} == PRIOR_PREFLIGHT_PINS,
            'Original preflight/approval/delta changed')
    receipt = pinned_json(PRIOR_RECEIPT, PRIOR_RECEIPT_SHA)
    failed = receipt['failure_inventory']['entries']
    require(digest(json.dumps(failed, sort_keys=True, separators=(',', ':')).encode()) ==
            receipt['failure_inventory']['tree_sha256'], 'Original failure inventory digest mismatch')
    projected = {}
    for name, record in failed.items():
        item = {'mode': int(record['mode'], 8), 'kind': record['kind']}
        if record['kind'] == 'symlink':
            item.update(kind='link', target=record['target'])
        elif record['kind'] == 'file':
            item['sha256'] = record['sha256']
        projected[name] = item
    require(inventory(PRIOR_APP) == projected and stat.S_IMODE(PRIOR_APP.stat().st_mode) == 0o755,
            'Original partially signed GUI changed')
    return {'failed_signing_receipt_sha256': PRIOR_RECEIPT_SHA,
            'partial_signed_gui_tree_sha256': receipt['failure_inventory']['tree_sha256'],
            'original_preflight_pins': PRIOR_PREFLIGHT_PINS}


def inspect(approval):
    require(approval.get('schema') == 'flash-signing-tooling-approval-v1', 'Missing parent approval schema')
    frozen = pinned_json(BASE / 'input-freeze.json', FREEZE_SHA)
    metadata = pinned_json(FINAL / 'build-metadata.json', METADATA_SHA)
    expected_gui = pinned_json(FINAL / 'candidate-file-manifest.json', MANIFEST_SHA)
    prior = prior_attempt_preserved()
    require(metadata['pristine_restage']['gui'] == str(APP) and len(metadata['evidence_continuations']) == 4,
            'Expected exact fourth pristine-restage metadata')
    require(git('rev-parse', 'HEAD').strip() == frozen['source_head'], 'HEAD changed')
    current = source_inputs()
    changes = source_delta(frozen['source_inputs'], current, approval.get('source_pins', {}))
    for name, expected in frozen['sdk']['files'].items():
        require(entry(SDK / name) == expected, 'SDK input changed: ' + name)
    require(git('rev-parse', 'HEAD', cwd=SDK).strip() == frozen['sdk']['version']['frameworkRevision'], 'SDK HEAD changed')
    for name, expected in frozen['tooling'].items():
        if name.startswith('executable:'):
            path = Path(expected['path'])
            actual = {'path': str(path.resolve(strict=True)), **entry(path)}
        else:
            actual = entry(ROOT / name)
        require(actual == expected, 'Original build tooling changed: ' + name)
    for name, expected in metadata['compile_evidence'].items():
        require(digest(read(evidence_path(BASE, name))) == expected, 'Original compile evidence changed: ' + name)
    for name, expected in metadata['stage_evidence'].items():
        require(digest(read(evidence_path(FINAL, name))) == expected, 'Original stage evidence changed: ' + name)
    for receipt in metadata['evidence_continuations']:
        require(digest(read(evidence_path(BASE, receipt['path']))) == receipt['sha256'], 'Continuation provenance changed')
    actual_gui = inventory(APP)
    match_inventory(actual_gui, expected_gui)
    require(not (APP / 'Contents/Library').exists(), 'GUI unexpectedly contains service payload')
    guards = {name: entry(GUARD / name) for name in GUARD_NAMES}
    require(set(approval.get('guard_pins', {})) == set(GUARD_NAMES), 'All three final guard pins required')
    require(guards == approval['guard_pins'], 'Final guard source/launcher/binary differs from approved pins')
    signer = current['macos/packaging/sign_split_payload.py']['sha256']
    constraint = current['macos/packaging/library_constraint.py']['sha256']
    qualifier_source = read(ROOT / 'macos/packaging/qualify_split_loads.py').decode()
    require(literal(read(ROOT / 'macos/packaging/sign_split_payload.py').decode(), 'CONSTRAINT_SHA256') == constraint, 'Signer constraint pin stale')
    require(literal(qualifier_source, 'CONSTRAINT_SHA256') == constraint, 'Qualifier constraint pin stale')
    require(literal(qualifier_source, 'BUILD_METADATA_SHA256') == METADATA_SHA, 'Qualifier retry metadata pin stale')
    require(literal(read(ROOT / 'macos/packaging/qualify_split_loads.py').decode(), 'DRIVER_SHA256') == signer, 'Qualifier signer pin stale')
    guard_source = read(GUARD / 'guard.m').decode()
    require(f'static NSString *const reviewedDriverSHA256=@"{signer}";' in guard_source, 'Guard is not pinned to final signer')
    require(f'static NSString *const fixedApp=@"{APP}";' in guard_source, 'Guard retry GUI path stale')
    launcher = read(GUARD / 'pipe_signing_session_password.py').decode()
    require(literal(launcher, 'REVIEWED_DRIVER_SHA256') == signer, 'Launcher signer pin stale')
    require(literal(launcher, 'REVIEWED_MODULE_SHA256') == current['macos/packaging/library_constraint.py']['sha256'], 'Launcher constraint pin stale')
    receipts = approval.get('guard_preservation_receipts', {})
    require(set(receipts) == {'prepin', 'postpin'}, 'Both guard preservation receipts required')
    for label, receipt in receipts.items():
        expected_path = GUARD.parent / ('gui-' + label + '-2026111303-retry01/bytehash-manifest.json')
        require(receipt.get('path') == str(expected_path), 'Unexpected guard preservation receipt path')
        pinned_json(expected_path, receipt.get('sha256'))
    return {'source_head': frozen['source_head'], 'current_source_status': git('status', '--porcelain'),
            'source_freeze_sha256': FREEZE_SHA, 'original_build_metadata_sha256': METADATA_SHA,
            'unsigned_gui_manifest_sha256': MANIFEST_SHA, 'allowed_source_delta': changes,
            'current_full_source_manifest_sha256': digest(json.dumps(current, sort_keys=True).encode()),
            'nonallowlisted_source_unchanged': True, 'sdk_and_original_build_tooling_unchanged': True,
            'original_compile_stage_evidence_unchanged': True, 'exact_unsigned_gui_unchanged': True,
            'observed_preparation_guards': json.loads(read(OUT / 'prepared.json'))['observed_guards_not_final_pins'],
            'final_guard_pins': guards, 'guard_preservation_receipts': receipts,
            'gui_path': str(APP), 'metadata_path': str(FINAL / 'build-metadata.json'),
            'guard_path': str(GUARD), 'prior_attempt_preservation': prior,
            'preflight_script_sha256': digest(read(Path(__file__))),
            'signing_performed': False, 'actualGUIloads': False, 'runtime_acceptance': False,
            'packaging_accepted': False, 'signing_authorized_by_this_script': False}


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('mode', choices=('prepare', 'freeze', 'verify'))
    parser.add_argument('--approval', type=Path)
    parser.add_argument('--approval-sha256')
    parser.add_argument('--delta-sha256')
    parser.add_argument('--parent-go')
    args = parser.parse_args()
    if args.mode == 'prepare':
        frozen = pinned_json(BASE / 'input-freeze.json', FREEZE_SHA)
        prior = prior_attempt_preserved()
        save('prepared.json', {'prior_attempt_preservation': prior, 'status': 'PREPARED_ONLY_NOT_A_FINAL_PREFLIGHT', 'final_pins_pending': True,
            'script_sha256': digest(read(Path(__file__))),
            'allowed_source_observation': {name: {'before': frozen['source_inputs'][name],
                'observed_current_not_final': entry(ROOT / name), 'rationale': RATIONALE} for name in ALLOWED},
            'observed_guards_not_final_pins': {name: entry(GUARD / name) for name in GUARD_NAMES},
            'original_build_metadata_sha256': METADATA_SHA, 'source_freeze_sha256': FREEZE_SHA,
            'final_preflight_passed': False})
        save('approval-template.json', {'schema': 'flash-signing-tooling-approval-v1',
            'source_pins': {name: {'sha256': None, 'bytes': None, 'mode': None} for name in ALLOWED},
            'guard_pins': {name: {'sha256': None, 'bytes': None, 'mode': None} for name in GUARD_NAMES},
            'guard_preservation_receipts': {label: {'path': str(GUARD.parent / ('gui-' + label + '-2026111303-retry01/bytehash-manifest.json')), 'sha256': None} for label in ('prepin', 'postpin')}})
        print('PREPARED ONLY; final approval pins required; nothing signed or executed.')
        return
    if args.mode == 'freeze':
        require(args.parent_go == 'freeze-reviewed-signing-tooling', 'Parent final freeze GO required')
        require(args.approval is not None, 'Pinned parent approval file required')
        approval = pinned_json(args.approval, args.approval_sha256)
        state = inspect(approval)
        require(inspect(approval) == state, 'Inputs changed during static preflight')
        result = {'schema': 'flash-signing-tooling-delta-v1', 'scope': 'unsigned-GUI-static-preflight-only',
            'approval_path': str(args.approval.resolve()), 'approval_sha256': args.approval_sha256,
            'static_preflight_passed': True, 'state': state}
        print('DELTA_SHA256=' + save('tooling-delta.json', result))
    else:
        delta = pinned_json(OUT / 'tooling-delta.json', args.delta_sha256)
        approval = pinned_json(Path(delta['approval_path']), delta['approval_sha256'])
        require(inspect(approval) == delta['state'], 'Frozen signing-tooling preflight inputs changed')
        print('Exact unsigned GUI and reviewed tooling delta unchanged; no execution/signing authority implied.')


if __name__ == '__main__':
    main()
