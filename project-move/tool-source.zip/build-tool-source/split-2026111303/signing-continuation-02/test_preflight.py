import copy
import importlib.util
import json
from pathlib import Path
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('prepared_preflight', HERE / 'preflight.py')
P = importlib.util.module_from_spec(spec)
spec.loader.exec_module(P)


class PreflightPureTests(unittest.TestCase):
    def setUp(self):
        self.before = {name: {'mode': 0o640, 'bytes': 3, 'sha256': 'a' * 64} for name in P.ALLOWED}
        self.before['macos/Runner/AppDelegate.swift'] = {'mode': 0o644, 'bytes': 4, 'sha256': 'c' * 64}
        self.after = copy.deepcopy(self.before)
        self.after[P.ALLOWED[0]].update(bytes=5, sha256='b' * 64)
        self.approved = {name: self.after[name] for name in P.ALLOWED}

    def test_only_six_reviewed_tooling_files_may_differ(self):
        result = P.source_delta(self.before, self.after, self.approved)
        self.assertEqual(set(result), set(P.ALLOWED))
        self.assertEqual(result[P.ALLOWED[0]]['before'], self.before[P.ALLOWED[0]])

    def test_allowlist_is_exactly_the_six_reviewed_source_paths(self):
        expected = {'macos/packaging/' + name for name in (
            'sign_split_payload.py', 'qualify_split_loads.py', 'library_constraint.py',
            'Tests/test_split_signing.py', 'Tests/test_split_qualification.py',
            'Tests/test_library_constraint.py')}
        self.assertEqual(set(P.ALLOWED), expected)
        self.assertEqual(len(P.ALLOWED), 6)

    def test_decoder_and_test_deltas_are_allowed_only_at_reviewed_pins(self):
        for name in ('macos/packaging/library_constraint.py',
                     'macos/packaging/Tests/test_library_constraint.py'):
            self.after[name].update(bytes=9, sha256='f' * 64)
        result = P.source_delta(self.before, self.after, self.approved)
        self.assertEqual(result['macos/packaging/library_constraint.py']['after']['bytes'], 9)
        approved = copy.deepcopy(self.approved)
        del approved['macos/packaging/library_constraint.py']
        with self.assertRaisesRegex(ValueError, 'Exact six'):
            P.source_delta(self.before, self.after, approved)

    def test_original_stage_tool_is_not_in_retry_allowlist(self):
        name = 'macos/packaging/stage_split_payload.py'
        self.before[name] = {'mode': 0o640, 'bytes': 3, 'sha256': 'a' * 64}
        self.after[name] = {'mode': 0o640, 'bytes': 3, 'sha256': 'b' * 64}
        with self.assertRaisesRegex(ValueError, 'Nonallowlisted'):
            P.source_delta(self.before, self.after, self.approved)

    def test_nonallowlisted_bootstrap_change_rejected(self):
        self.after['macos/Runner/AppDelegate.swift']['sha256'] = 'd' * 64
        with self.assertRaisesRegex(ValueError, 'Nonallowlisted'):
            P.source_delta(self.before, self.after, self.approved)

    def test_new_untracked_source_rejected(self):
        self.after['macos/Runner/NewEngine.m'] = {'sha256': 'a' * 64}
        with self.assertRaisesRegex(ValueError, 'added or removed'):
            P.source_delta(self.before, self.after, self.approved)

    def test_deleted_source_rejected(self):
        del self.after['macos/Runner/AppDelegate.swift']
        with self.assertRaisesRegex(ValueError, 'added or removed'):
            P.source_delta(self.before, self.after, self.approved)

    def test_allowlisted_permission_change_rejected(self):
        self.after[P.ALLOWED[0]]['mode'] = 0o600
        with self.assertRaisesRegex(ValueError, 'permission change'):
            P.source_delta(self.before, self.after, self.approved)

    def test_stale_final_source_pin_rejected(self):
        approved = copy.deepcopy(self.approved)
        approved[P.ALLOWED[0]]['sha256'] = 'e' * 64
        with self.assertRaisesRegex(ValueError, 'pin mismatch'):
            P.source_delta(self.before, self.after, approved)

    def test_missing_final_pin_rejected(self):
        del self.approved[P.ALLOWED[0]]
        with self.assertRaisesRegex(ValueError, 'Exact six'):
            P.source_delta(self.before, self.after, self.approved)

    def test_placeholder_approval_fails_closed(self):
        approved = {name: {'sha256': None, 'bytes': None, 'mode': None} for name in P.ALLOWED}
        with self.assertRaisesRegex(ValueError, 'pin mismatch'):
            P.source_delta(self.before, self.after, approved)

    def test_original_metadata_bytes_hash_checked(self):
        raw = b'{"schema":"fixture"}'
        with patch.object(P, 'read', return_value=raw):
            self.assertEqual(P.pinned_json(Path('mock'), P.digest(raw)), json.loads(raw))
            with self.assertRaisesRegex(ValueError, 'Pinned input changed'):
                P.pinned_json(Path('mock'), 'f' * 64)

    def test_placeholder_digest_never_reads_path(self):
        with patch.object(P, 'read') as read:
            with self.assertRaisesRegex(ValueError, 'Missing final hash'):
                P.pinned_json(Path('mock'), None)
            read.assert_not_called()

    def test_launcher_pin_is_parsed_without_import_or_execution(self):
        text = "raise RuntimeError('must never execute')\nREVIEWED_DRIVER_SHA256 = '" + 'a' * 64 + "'\n"
        self.assertEqual(P.literal(text, 'REVIEWED_DRIVER_SHA256'), 'a' * 64)
        with self.assertRaises(ValueError):
            P.literal(text + "REVIEWED_DRIVER_SHA256 = 'other'\n", 'REVIEWED_DRIVER_SHA256')

    def test_unsigned_manifest_requires_exact_bytes_modes_links_and_file_set(self):
        expected = {'code': {'mode': 0o755, 'kind': 'file', 'sha256': 'a' * 64},
                    'link': {'mode': 0o755, 'kind': 'link', 'target': 'code'}}
        P.match_inventory(copy.deepcopy(expected), expected)
        for field, value in (('sha256', 'b' * 64), ('mode', 0o750)):
            changed = copy.deepcopy(expected)
            changed['code'][field] = value
            with self.assertRaisesRegex(ValueError, 'Unsigned GUI differs'):
                P.match_inventory(changed, expected)
        changed = copy.deepcopy(expected)
        changed['link']['target'] = 'outside'
        with self.assertRaises(ValueError):
            P.match_inventory(changed, expected)
        changed = copy.deepcopy(expected)
        changed['extra'] = {}
        with self.assertRaises(ValueError):
            P.match_inventory(changed, expected)

    def test_git_calls_only_readonly_git_with_optional_locks_disabled(self):
        with patch.object(P.subprocess, 'check_output', return_value='fixture') as run:
            self.assertEqual(P.git('rev-parse', 'HEAD'), 'fixture')
            self.assertEqual(run.call_args.args[0], ['/usr/bin/git', '--no-optional-locks', 'rev-parse', 'HEAD'])


if __name__ == '__main__':
    unittest.main()
