import argparse
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import plistlib
import re
import shutil
import stat
import struct
import subprocess
import sys
import time

ROOT = Path('/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup')
E = ROOT / '.airbuild/buildcandidate/split-2026111303'
SDK = Path('/Users/layoute/fvm/versions/3.47.4')
APP = ROOT / 'build/macos/Build/Products/Release/Flash.app'
DEST = ROOT / '.airbuild/artifacts/split-2026111303/gui/Flash.app'
FREEZE = E / 'input-freeze.json'
CERT = 'BBA7F8529FD271B9848EC03A2CE3F4780F585556'
SANDBOX = ['/usr/bin/sandbox-exec', '-p', '(version 1) (allow default) (deny network*)']
OLD = '.airbuild/tools/fixed-candidate-build-2026111302-engine-start-fix.sh'
WRAPPER = '.airbuild/tools/fixed-candidate-xcrun-bin/xcrun'
ENGINE = 'engine/src/flutter/shell/platform/darwin/macos/framework/Source/FlutterEngine.mm'
FRAMEWORK = 'bin/cache/artifacts/engine/darwin-x64-release/FlutterMacOS.xcframework/macos-arm64_x86_64/FlutterMacOS.framework/Versions/A/FlutterMacOS'
SDK_ID = {'frameworkVersion': '3.47.4', 'frameworkRevision': '9584c6713b324636289d067944a46fd6b49df14b',
          'engineRevision': '06a2e2a110089dff50fe635cffd2a61e1b24fbcd',
          'engineContentHash': '0e228ec8c8d2abc9fcf1d053e8a40665bb859ec7', 'dartSdkVersion': '3.13.3'}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def arm64_bytes(path):
    data = Path(path).read_bytes()
    if data[:4] == bytes.fromhex('cafebabe'):
        slices = []
        for index in range(struct.unpack_from('>I', data, 4)[0]):
            cpu, subtype, offset, size, alignment = struct.unpack_from('>IIIII', data, 8 + 20 * index)
            if cpu == 0x100000c:
                slices.append(data[offset:offset + size])
        assert len(slices) == 1
        return slices[0]
    assert data[:4] == bytes.fromhex('cffaedfe') and struct.unpack_from('<I', data, 4)[0] == 0x100000c
    return data


def save(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
    path.chmod(0o600)


def git(*args, cwd=ROOT):
    return subprocess.check_output(['/usr/bin/git', *args], cwd=cwd).decode()


def entry(path):
    s = path.lstat()
    result = {'mode': stat.S_IMODE(s.st_mode)}
    if path.is_symlink():
        result['symlink'] = os.readlink(path)
    elif path.is_file():
        result.update(sha256=sha(path), bytes=s.st_size)
    elif path.is_dir():
        result['directory'] = True
    else:
        raise ValueError('Special input: ' + str(path))
    return result


def tree(path):
    if not path.exists() and not path.is_symlink():
        return {'missing': True}
    result = {'.': entry(path)}
    if path.is_dir() and not path.is_symlink():
        for directory, names, files in os.walk(path, followlinks=False):
            for name in sorted(names + files):
                p = Path(directory) / name
                result[str(p.relative_to(path))] = entry(p)
    return result


def source_inputs(directory=ROOT, prefix=''):
    result = {}
    names = set(git('ls-files', '-z', '--cached', '--others', '--exclude-standard', cwd=directory).split('\0')) - {''}
    for name in sorted(names):
        path = directory / name
        key = prefix + name
        if not path.exists() and not path.is_symlink():
            result[key] = {'missing': True}
        elif path.is_dir() and not path.is_symlink():
            result[key] = {'gitlink_head': git('rev-parse', 'HEAD', cwd=path).strip(),
                           'status': git('status', '--porcelain', cwd=path)}
            result.update(source_inputs(path, key + '/'))
        else:
            result[key] = entry(path)
    return result


def sdk_inputs():
    version = json.loads((SDK / 'bin/cache/flutter.version.json').read_text())
    assert all(version[k] == v for k, v in SDK_ID.items()), version
    assert git('rev-parse', 'HEAD', cwd=SDK).strip() == SDK_ID['frameworkRevision']
    assert sha(SDK / ENGINE) == 'e771c63af5a3278fb69d1eead8bcbec2f6e7eeb186ab8cca47ad5c0a01eab0cc'
    names = [ENGINE, ENGINE.replace('FlutterEngine.mm', 'FlutterDartProject.mm'),
             ENGINE.replace('FlutterEngine.mm', 'FlutterViewController.mm'), FRAMEWORK,
             'bin/cache/flutter.version.json', 'bin/internal/engine.version', 'bin/flutter',
             'bin/cache/flutter_tools.snapshot', 'bin/cache/dart-sdk/bin/dart',
             'bin/cache/dart-sdk/bin/snapshots/frontend_server_aot.dart.snapshot',
             'bin/cache/artifacts/engine/darwin-x64-release/gen_snapshot_arm64']
    return {'version': version, 'files': {name: entry(SDK / name) for name in names}}


def tooling_inputs():
    assert sha(ROOT / WRAPPER) == '923d477e8a1e58a8c24889082c9ac8aeef28d9035093c03147b7e79fe0c92586'
    assert sha(ROOT / OLD) == 'fc18879f713dd9a5d6b6c1bde9db24bc85d17e870a86a35b32e835496e0eb224'
    names = [WRAPPER, OLD, '.airbuild/tools/split-build-2026111303.sh',
             '.airbuild/buildcandidate/split-2026111303/build_driver.py',
             '.dart_tool/package_config.json', '.dart_tool/package_graph.json', '.flutter-plugins-dependencies']
    result = {name: entry(ROOT / name) for name in names}
    for name in ('flutter', 'go', 'cargo', 'rustc', 'rustup', 'xcrun', 'xcodebuild'):
        path = Path(shutil.which(name)).resolve(strict=True)
        result['executable:' + name] = {'path': str(path), **entry(path)}
    return result


def preservation():
    roots = sorted((ROOT / '.airbuild/artifacts').glob('fixed-identity-202611130[12]*'))
    assert any(p.name == 'fixed-identity-2026111301' for p in roots)
    assert any(p.name == 'fixed-identity-2026111302' for p in roots)
    provision = ROOT / '.airbuild/evidence/mac-authorization/signing-provision'
    roots += sorted(provision.glob('signing-session-guard*'))
    roots += [provision / 'candidate-2026111302/signing-session-guard',
              provision / 'candidate-2026111302/signing-session-guard.m', ROOT / OLD]
    data = {str(p): tree(p) for p in roots}
    backup = Path('/Users/layoute/Library/Application Support/Flash Signing/Backups/FlashSigning.p12')
    s = backup.lstat()
    data['backup_metadata_only_no_bytes_or_keychain_access'] = {
        'path': str(backup), 'mode': s.st_mode, 'uid': s.st_uid, 'gid': s.st_gid,
        'size': s.st_size, 'inode': s.st_ino, 'device': s.st_dev, 'nlink': s.st_nlink,
        'mtime_ns': s.st_mtime_ns, 'ctime_ns': s.st_ctime_ns, 'flags': s.st_flags}
    return data


def state(head):
    assert git('rev-parse', 'HEAD').strip() == head, 'HEAD changed'
    assert re.fullmatch('[0-9a-f]{40}', head)
    assert subprocess.run(['/usr/bin/git', 'merge-base', '--is-ancestor',
                           '9e7f602304ed1c849ac67675ee428fdf07832810', head], cwd=ROOT).returncode == 0
    identity = (ROOT / 'macos/Shared/HelperIdentity.h').read_text()
    for value in (f'#define FC_PINNED_CERTIFICATE_SHA1 "{CERT}"', '#define FC_PRODUCTION_TEAM_ID ""',
                  '#define FC_MANAGED_CANDIDATE_ENABLED 0', '#define FC_SPLIT_GUI_CDHASH ""'):
        assert value in identity, value
    spec = (ROOT / 'pubspec.yaml').read_text()
    assert 'version: 0.9.7+' in spec and spec.count('build_assets: true') == 2
    assert 'build_assets: false' not in spec
    assert json.loads((ROOT / 'env.json').read_text()) == {'APP_ENV': 'stable'}
    assert 'bool.fromEnvironment(\'MACOS_MANAGED_HELPER\')' in (ROOT / 'lib/core/desktop/macos_helper_client.dart').read_text()
    return {'source_head': head, 'source_status': git('status', '--porcelain'),
            'source_inputs': source_inputs(), 'sdk': sdk_inputs(), 'tooling': tooling_inputs()}


def run(command, output, env=None):
    command = [str(x) for x in command]
    with (E / 'commands.jsonl').open('a') as journal:
        journal.write(json.dumps({'argv': SANDBOX + command, 'output': output,
                                  'started_ns': time.time_ns()}) + '\n')
    print('COMMAND:', ' '.join(command), flush=True)
    with (E / output).open('wb') as stream:
        subprocess.run(SANDBOX + command, cwd=ROOT, env=env, stdout=stream,
                       stderr=subprocess.STDOUT, check=True)


def module(name):
    spec = importlib.util.spec_from_file_location('_build_' + name, ROOT / 'macos/packaging' / (name + '.py'))
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def compile_evidence():
    settings = json.loads((E / 'effective-xcode-settings.json').read_text())
    r = next(item['buildSettings'] for item in settings if item['target'] == 'Runner')
    assert r['FC_MANAGED_CANDIDATE_ENABLED'] == '1'
    assert 'FC_MANAGED_CANDIDATE_ENABLED=1' in r['GCC_PREPROCESSOR_DEFINITIONS'].split()
    assert r['CODE_SIGNING_ALLOWED'] == 'NO' and r['ARCHS'] == 'arm64'
    assert 'FC_SPLIT_GUI_CDHASH' not in r['GCC_PREPROCESSOR_DEFINITIONS']
    info = plistlib.loads((APP / 'Contents/Info.plist').read_bytes())
    assert info['CFBundleShortVersionString'] == '0.9.7' and info['CFBundleVersion'] == '2026111303'
    assert info['CFBundleIdentifier'] == 'com.layoute.flash'
    assert not any(k in info for k in ('NSMainNibFile', 'NSMainStoryboardFile', 'NSPrincipalClass'))
    defines = [base64.b64decode(v, validate=True).decode() for v in info['FlashDartDefines'].split(',') if v]
    assert defines.count('MACOS_MANAGED_HELPER=true') == 1
    assert defines.count('FLUTTER_BUILD_NUMBER=2026111303') == 1
    save(E / 'sealed-dart-defines.json', defines)
    intermediates = ROOT / 'build/macos/Build/Intermediates.noindex/Runner.build/Release/Runner.build'
    responses = {str(p.relative_to(ROOT)): {'sha256': sha(p), 'contents': p.read_text()}
                 for p in intermediates.rglob('*.resp')}
    assert any('-DFC_MANAGED_CANDIDATE_ENABLED=1' in r['contents'] for r in responses.values())
    assert all('FC_SPLIT_GUI_CDHASH' not in r['contents'] for r in responses.values())
    save(E / 'runner-compile-responses.json', responses)
    objects = list(intermediates.rglob('FlashFlutterEngine.o'))
    assert len(objects) == 1, objects
    run(['/usr/bin/otool', '-tvV', objects[0]], 'FlashFlutterEngine-object-disassembly.txt')
    run(['/usr/bin/otool', '-ov', objects[0]], 'FlashFlutterEngine-object-objc.txt')
    assert 'loadAOTData:' in (E / 'FlashFlutterEngine-object-objc.txt').read_text()
    save(E / 'compiled-bootstrap-object.json', {str(p): entry(p) for p in objects})
    log = (E / 'flutter-build.log').read_text()
    assert 'gen_snapshot_arm64' in log and '--snapshot_kind=app-aot-macho-dylib' in log
    save(E / 'actual-aot-compile-commands.json', [line for line in log.splitlines()
                                               if 'gen_snapshot_arm64' in line or 'frontend_server' in line])
    hook = ROOT / '.dart_tool/setup_build_cache/hook.log'
    shutil.copyfile(hook, E / 'setup-hook.log')
    assert 'exec: go build ' in hook.read_text() and 'Building Go core: darwin/arm64' in hook.read_text()
    assert sha(ROOT / 'libclash/macos/FlClashCore') == sha(APP / 'Contents/MacOS/FlClashCore')
    aot = list((ROOT / '.dart_tool/flutter_build').glob('*/arm64/App.framework/App'))
    assert len(aot) == 1 and arm64_bytes(aot[0]) == arm64_bytes(APP / 'Contents/Frameworks/App.framework/Versions/A/App')
    save(E / 'fresh-output-provenance.json', {'core': entry(ROOT / 'libclash/macos/FlClashCore'),
        'aot': {'source_path': str(aot[0]), **entry(aot[0])},
        'intermediate_helper_tools': 'Xcode legacy phase outputs discarded by stage_gui; NOT split service pins'})
    run(['go', 'version', '-m', APP / 'Contents/MacOS/FlClashCore'], 'core-buildinfo.txt')
    sdk_binary = SDK / FRAMEWORK
    built_binary = APP / 'Contents/Frameworks/FlutterMacOS.framework/Versions/A/FlutterMacOS'
    assert arm64_bytes(sdk_binary) == arm64_bytes(built_binary)
    save(E / 'sdk-framework-binary-proof.json', {
        'sdk_container': entry(sdk_binary), 'build_container': entry(built_binary),
        'identical_arm64_slice_sha256': hashlib.sha256(arm64_bytes(sdk_binary)).hexdigest()})
    for name in ('Logs',):
        path = ROOT / 'build/macos' / name
        if path.exists():
            shutil.copytree(path, E / ('xcode-' + name), symlinks=True)
    return info


def build(head, freeze_sha):
    assert sha(FREEZE) == freeze_sha, 'Freeze receipt changed'
    frozen = json.loads(FREEZE.read_text())
    assert state(head) == frozen, 'Inputs changed after parent freeze'
    assert not DEST.exists() and not (E / 'build.started').exists(), 'Single attempt only; no overlay/fallback'
    (E / 'build.started').write_text(str(time.time_ns()) + '\n')
    before = preservation()
    save(E / 'preservation-before.json', before)
    save(E / 'source-inputs-before.json', frozen['source_inputs'])
    result = {'status': 'failed', 'runtime_acceptance': False, 'actualGUIloads': False,
              'packaging_accepted': False, 'private_key_signing_performed': False}
    try:
        env = os.environ.copy()
        env['XCODE_XCCONFIG_FILE'] = str(E / 'candidate.xcconfig')
        (E / 'candidate.xcconfig').write_text('FC_MANAGED_CANDIDATE_ENABLED = 1\nGCC_PREPROCESSOR_DEFINITIONS = $(inherited) FC_MANAGED_CANDIDATE_ENABLED=$(FC_MANAGED_CANDIDATE_ENABLED)\nCODE_SIGNING_ALLOWED = NO\n')
        env['FLUTTER_ENGINE_SOURCE'] = str(SDK / 'engine/src/flutter')
        run(['/usr/bin/python3', '-I', '-S', '-B', 'macos/RunnerTests/test_flutter_bootstrap.py'], 'bootstrap-sdk-contract-tests.log', env)
        for command, output in [([SDK / 'bin/flutter', '--version', '--machine'], 'flutter-version.json'),
                                (['go', 'version'], 'go-version.txt'), (['cargo', '--version'], 'cargo-version.txt'),
                                (['rustc', '--version'], 'rust-version.txt'), (['rustup', 'toolchain', 'list'], 'rust-toolchains.txt'),
                                (['xcodebuild', '-version'], 'xcode-version.txt'), (['xcrun', 'clang', '--version'], 'clang-version.txt')]:
            run(command, output, env)
        preserved = E / 'prior-generated'
        preserved.mkdir()
        moved = {}
        for name in ('build/macos/Build', '.dart_tool/flutter_build', '.dart_tool/setup_build_cache',
                     '.dart_tool/hooks_runner/setup', 'libclash/macos'):
            source = ROOT / name
            if source.exists():
                target = preserved / name.replace('/', '__')
                source.rename(target)
                moved[name] = str(target)
        save(E / 'preserved-generated-paths.json', moved)
        assert not APP.exists() and not (ROOT / 'libclash/macos/FlClashCore').exists()
        run([SDK / 'bin/flutter', '-v', 'build', 'macos', '--release', '--no-pub',
             '--dart-define-from-file=env.json', '--dart-define=MACOS_MANAGED_HELPER=true',
             '--build-name=0.9.7', '--build-number=2026111303'], 'flutter-build.log', env)
        run(['xcrun', 'xcodebuild', '-showBuildSettings', '-json', '-workspace', 'macos/Runner.xcworkspace',
             '-scheme', 'Runner', '-configuration', 'Release', 'CODE_SIGNING_ALLOWED=NO'], 'effective-xcode-settings.json', env)
        info = compile_evidence()
        assert state(head) == frozen, 'Input changed during compile'
        run(['/usr/bin/python3', '-B', 'macos/packaging/stage_split_payload.py', 'gui',
             '--fresh-build-app', APP, '--output', DEST], 'stage-gui.log', env)
        split = module('stage_split_payload')
        entries = split.verify_split_gui(DEST)
        targets = []
        magic = module('stage_managed_payload').MACH_MAGIC
        for relative, item in entries.items():
            p = DEST / relative
            if item.get('kind') == 'file' and p.read_bytes()[:4] in magic:
                architectures = subprocess.check_output(['/usr/bin/lipo', '-archs', p], text=True).split()
                assert architectures == ['arm64']
                targets.append({'path': relative, 'architectures': architectures, **item})
        assert len(targets) == 7 and not (DEST / 'Contents/Library').exists()
        assert sha(DEST / 'Contents/MacOS/FlClashCore') == sha(APP / 'Contents/MacOS/FlClashCore')
        save(E / 'candidate-file-manifest.json', entries)
        save(E / 'macho-inventory.json', targets)
        metadata = {'schema': 'flash-split-build-v1', 'build_configuration': 'Release',
            'version': '0.9.7', 'build_number': '2026111303', 'source_head': head,
            'source_freeze_sha256': freeze_sha, 'source_status': frozen['source_status'],
            'defines': {'APP_ENV': 'stable', 'MACOS_MANAGED_HELPER': True,
                        'FC_MANAGED_CANDIDATE_ENABLED': 1, 'FC_PINNED_CERTIFICATE_SHA1': CERT},
            'certificate_sha1': CERT, 'apple_team': '', 'startup_hardened': True,
            'startup_hardening_scope': 'static source/SDK-contract and compiled ObjC evidence only; no launch',
            'startup_source_hashes': {k: v for k, v in frozen['source_inputs'].items()
                                      if k.startswith('macos/Runner/') or k == 'macos/Runner.xcodeproj/project.pbxproj'},
            'sdk': frozen['sdk'], 'network_sandbox': 'deny network*', 'xcode_code_signing_allowed': False,
            'gui_cdhash_compile_default': '', 'split_service_staged': False,
            'helper_compile_with_gui_pin_pending': True, 'architectures': ['arm64'], 'macho_count': 7,
            'flutter_release_compile_succeeded': True, 'static_stage_audit_passed': True,
            'fresh_core_built': True, 'fresh_gui_aot_built': True, 'signing_performed': False,
            'runtime_acceptance': False, 'actualGUIloads': False, 'packaging_accepted': False,
            'production_components_executed': False}
        metadata['compile_evidence'] = {p.name: sha(p) for p in E.iterdir()
            if p.is_file() and p.suffix in ('.json', '.txt', '.log', '.jsonl') and p.name != 'build-metadata.json'}
        assert state(head) == frozen and preservation() == before
        module('qualify_split_loads').validate_metadata(metadata, info, type('Pins', (), {'CERTIFICATE_SHA1': CERT}))
        save(E / 'build-metadata.json', metadata)
        result['status'] = 'static-build-and-gui-stage-passed'
    finally:
        after = state(head)
        save(E / 'source-inputs-after.json', after['source_inputs'])
        preserved_after = preservation()
        save(E / 'preservation-after.json', preserved_after)
        result['source_unchanged'] = after == frozen
        result['prior_01_02_guards_backup_preserved'] = before == preserved_after
        save(E / 'build-result.json', result)
        assert after == frozen, 'Build changed frozen inputs'
        assert before == preserved_after, 'Protected artifact/guard/backup changed'
    print('STAGED_GUI=' + str(DEST))
    print('BUILD_METADATA=' + str(E / 'build-metadata.json'))


def main():
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('mode', choices=('freeze', 'build'))
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--freeze-sha256')
    parser.add_argument('--parent-go')
    args = parser.parse_args()
    os.chdir(ROOT)
    if args.mode == 'freeze':
        assert not FREEZE.exists(), 'Freeze is append-only; review inputs before freezing'
        save(FREEZE, state(args.expected_head))
        print('FREEZE_SHA256=' + sha(FREEZE))
    else:
        assert args.parent_go == 'split-2026111303-gui-compile-and-stage', 'Explicit parent build authorization required'
        assert re.fullmatch('[0-9a-f]{64}', args.freeze_sha256 or '')
        build(args.expected_head, args.freeze_sha256)


if __name__ == '__main__':
    main()
