import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import plistlib
import stat
import subprocess
import traceback

ROOT = Path('/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup')
ORIGINAL = ROOT / '.airbuild/buildcandidate/split-2026111303'
PREVIOUS = ORIGINAL / 'continuation-01'
OUT = ORIGINAL / 'continuation-02'
HEAD = '9e7f602304ed1c849ac67675ee428fdf07832810'
FREEZE_SHA = 'd756cb259a694520d7571dcda37866bc3f6fe9d54df520565f131701a8c66a87'
DRIVER_SHA = '3d8bf3f8d955e6e04022dc3072eae63ad67a9dde4bd59eb7af327b4e21c96f17'
MODE_TARGETS = ('Contents/Frameworks/App.framework/Versions/A/App',
                'Contents/Frameworks/sqlite3.framework/Versions/A/sqlite3')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    path = OUT / name
    with path.open('x') as stream:
        stream.write(json.dumps(value, sort_keys=True, indent=2) + '\n')
    path.chmod(0o600)


def main():
    assert digest(ORIGINAL / 'build_driver.py') == DRIVER_SHA
    assert digest(PREVIOUS / 'continue_evidence.py') == 'ad4542ea891b6610fa854843499b8cd7839b622f80f791480aa829873dc0a904'
    spec = importlib.util.spec_from_file_location('frozen_builder', ORIGINAL / 'build_driver.py')
    d = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(d)
    assert d.sha(d.FREEZE) == FREEZE_SHA
    frozen = json.loads(d.FREEZE.read_text())
    assert d.state(HEAD) == frozen
    assert json.loads((PREVIOUS / 'continuation-result.json').read_text()) == {
        'actualGUIloads': False, 'fresh_build_input_unchanged': True, 'original_evidence_unchanged': True,
        'packaging_accepted': False, 'prior_01_02_guards_backup_preserved': True,
        'runtime_acceptance': False, 'signing_performed': False, 'source_unchanged': True, 'status': 'failed'}
    assert (PREVIOUS / 'stage-gui.log').read_text().strip() == 'Split staging failed closed: Split executable must have mode 0755'
    provenance = json.loads((PREVIOUS / 'continuation-provenance.json').read_text())
    assert provenance['freeze_sha256'] == FREEZE_SHA and provenance['compile_count'] == 1
    assert all(digest(ORIGINAL / name) == value for name, value in provenance['original_evidence_sha256'].items())
    assert '** BUILD SUCCEEDED **' in (ORIGINAL / 'flutter-build.log').read_text()
    fresh = d.tree(d.APP)
    assert fresh == json.loads((PREVIOUS / 'fresh-build-input-inventory.json').read_text())
    protected = d.preservation()
    assert protected == json.loads((ORIGINAL / 'preservation-before.json').read_text())
    immutable = {str(p.relative_to(ORIGINAL)): digest(p)
                 for p in [*ORIGINAL.iterdir(), *PREVIOUS.rglob('*')] if p.is_file()}
    (OUT / 'continuation.started').touch(exist_ok=False)
    split = d.module('stage_split_payload')
    verifier = split.load_local('stage_managed_payload')
    verifier.FIXED_EXECUTABLES = (split.CORE,)
    outcome = {'status': 'failed', 'actualGUIloads': False, 'runtime_acceptance': False,
               'packaging_accepted': False, 'signing_performed': False}
    before = d.tree(d.DEST)
    save('stage-inventory-before.json', before)
    save('continuation-provenance.json', {
        'schema': 'flash-split-stage-continuation-v1', 'source_sha256': digest(Path(__file__)),
        'original_driver_sha256': DRIVER_SHA, 'source_freeze_sha256': FREEZE_SHA,
        'original_and_continuation01_evidence_sha256': immutable,
        'original_build_result': json.loads((ORIGINAL / 'build-result.json').read_text()),
        'continuation01_result': json.loads((PREVIOUS / 'continuation-result.json').read_text()),
        'authorization': 'chmod only two staged binaries 0644->0755, then original frozen stage audit/mutation and metadata gates',
        'rebuild_performed': False, 'original_failures_overwritten': False})
    try:
        expected = copy.deepcopy(before)
        for name in MODE_TARGETS:
            path = d.DEST / name
            assert not path.is_symlink() and path.is_file()
            assert stat.S_IMODE(path.stat().st_mode) == 0o644
            expected[name]['mode'] = 0o755
        for name in MODE_TARGETS:
            (d.DEST / name).chmod(0o755)
        after_modes = d.tree(d.DEST)
        save('stage-inventory-after-modes.json', after_modes)
        assert after_modes == expected, 'Only exact two mode deltas authorized; every byte/link must remain identical'
        save('mode-only-delta.json', {name: {'before': before[name], 'after': after_modes[name]} for name in MODE_TARGETS})
        split.check_layout(d.DEST, 'gui')
        binaries = [d.DEST / name for name, item in after_modes.items()
                    if 'sha256' in item and (d.DEST / name).read_bytes()[:4] in verifier.MACH_MAGIC]
        loads_before = {str(p.relative_to(d.DEST)): verifier.load_commands(p) for p in binaries}
        save('load-commands-before-audit.json', loads_before)
        original_run = subprocess.run
        def recorded_run(*args, **kwargs):
            with (OUT / 'static-audit-commands.jsonl').open('a') as stream:
                stream.write(json.dumps({'argv': [str(x) for x in args[0]]}) + '\n')
            return original_run(*args, **kwargs)
        subprocess.run = recorded_run
        try:
            verifier.audit(d.DEST, mutate=True)
            split.check_layout(d.DEST, 'gui')
            entries = split.verify_split_gui(d.DEST)
        finally:
            subprocess.run = original_run
            after_audit = d.tree(d.DEST)
            save('stage-inventory-after-audit.json', after_audit)
            save('audit-normalization-delta.json', {name: {'before': after_modes.get(name), 'after': after_audit.get(name)}
                for name in sorted(set(after_modes) | set(after_audit)) if after_modes.get(name) != after_audit.get(name)})
        loads_after = {str(p.relative_to(d.DEST)): verifier.load_commands(p) for p in binaries}
        save('load-commands-after-audit.json', loads_after)
        targets = []
        for path in binaries:
            relative = str(path.relative_to(d.DEST))
            architectures = subprocess.check_output(['/usr/bin/lipo', '-archs', path], text=True).split()
            assert architectures == ['arm64']
            targets.append({'path': relative, 'architectures': architectures, **entries[relative]})
        assert len(targets) == 7 and not (d.DEST / 'Contents/Library').exists()
        assert d.sha(d.DEST / split.CORE) == d.sha(d.APP / split.CORE)
        save('candidate-file-manifest.json', entries)
        save('macho-inventory.json', targets)
        info = plistlib.loads((d.DEST / 'Contents/Info.plist').read_bytes())
        assert info['CFBundleShortVersionString'] == '0.9.7' and info['CFBundleVersion'] == '2026111303'
        metadata = {'schema': 'flash-split-build-v1', 'build_configuration': 'Release',
            'version': '0.9.7', 'build_number': '2026111303', 'source_head': HEAD,
            'source_freeze_sha256': FREEZE_SHA, 'source_status': frozen['source_status'],
            'defines': {'APP_ENV': 'stable', 'MACOS_MANAGED_HELPER': True,
                'FC_MANAGED_CANDIDATE_ENABLED': 1, 'FC_PINNED_CERTIFICATE_SHA1': d.CERT},
            'certificate_sha1': d.CERT, 'apple_team': '', 'startup_hardened': True,
            'startup_hardening_scope': 'static source/SDK-contract and compiled ObjC evidence only; no launch',
            'startup_source_hashes': {k: v for k, v in frozen['source_inputs'].items()
                if k.startswith('macos/Runner/') or k == 'macos/Runner.xcodeproj/project.pbxproj'},
            'sdk': frozen['sdk'], 'network_sandbox': 'deny network*', 'xcode_code_signing_allowed': False,
            'gui_cdhash_compile_default': '', 'split_service_staged': False,
            'helper_compile_with_gui_pin_pending': True, 'architectures': ['arm64'], 'macho_count': 7,
            'flutter_release_compile_succeeded': True, 'static_stage_audit_passed': True,
            'fresh_core_built': True, 'fresh_gui_aot_built': True, 'signing_performed': False,
            'runtime_acceptance': False, 'actualGUIloads': False, 'packaging_accepted': False,
            'production_components_executed': False,
            'original_build_driver_result': 'failed after successful compile: mixed stderr/stdout settings parser',
            'evidence_continuations': [
                {'path': str(PREVIOUS / 'continuation-provenance.json'), 'sha256': digest(PREVIOUS / 'continuation-provenance.json'),
                 'result': 'compile evidence passed; stage mode gate failed'},
                {'path': str(OUT / 'continuation-provenance.json'), 'sha256': digest(OUT / 'continuation-provenance.json'),
                 'result': 'exact two mode corrections and unchanged original audit gates passed'}],
            'rebuild_performed': False, 'original_failures_preserved': True}
        metadata['compile_evidence'] = immutable
        metadata['stage_evidence'] = {p.name: digest(p) for p in OUT.iterdir()
                                     if p.is_file() and p.suffix in ('.json', '.txt', '.jsonl')}
        assert d.state(HEAD) == frozen and d.preservation() == protected and d.tree(d.APP) == fresh
        assert all(digest(ORIGINAL / name) == value for name, value in immutable.items())
        d.module('qualify_split_loads').validate_metadata(metadata, info, type('Pins', (), {'CERTIFICATE_SHA1': d.CERT}))
        save('build-metadata.json', metadata)
        outcome['status'] = 'static-build-evidence-and-gui-stage-passed'
    except BaseException:
        (OUT / 'failure-traceback.txt').write_text(traceback.format_exc())
        raise
    finally:
        state = d.state(HEAD)
        save('source-inputs-after.json', state['source_inputs'])
        preserved = d.preservation()
        save('preservation-after.json', preserved)
        outcome.update(source_unchanged=state == frozen, prior_01_02_guards_backup_preserved=preserved == protected,
            original_evidence_unchanged=all(digest(ORIGINAL / name) == value for name, value in immutable.items()),
            fresh_build_input_unchanged=d.tree(d.APP) == fresh)
        save('continuation-result.json', outcome)
        assert all(outcome[k] for k in ('source_unchanged', 'prior_01_02_guards_backup_preserved',
            'original_evidence_unchanged', 'fresh_build_input_unchanged'))
    print('GUI=' + str(d.DEST))
    print('METADATA=' + str(OUT / 'build-metadata.json'))


if __name__ == '__main__':
    main()
