import hashlib
import importlib.util
import json
from pathlib import Path
import plistlib
import shutil
import subprocess
import traceback

ROOT = Path('/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup')
ORIGINAL = ROOT / '.airbuild/buildcandidate/split-2026111303'
OUT = ORIGINAL / 'continuation-01'
HEAD = '9e7f602304ed1c849ac67675ee428fdf07832810'
FREEZE_SHA = 'd756cb259a694520d7571dcda37866bc3f6fe9d54df520565f131701a8c66a87'
DRIVER_SHA = '3d8bf3f8d955e6e04022dc3072eae63ad67a9dde4bd59eb7af327b4e21c96f17'
PREFIX = ('--- xcodebuild: WARNING: Using the first of multiple matching destinations:\n'
          '{ platform:macOS, arch:arm64, id:00006050-001B70DA3C89401C, name:My Mac }\n'
          '{ platform:macOS, arch:x86_64, id:00006050-001B70DA3C89401C, name:My Mac }\n'
          '{ platform:macOS, name:Any Mac }\n')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, data):
    path = OUT / name
    with path.open('x') as stream:
        stream.write(json.dumps(data, indent=2, sort_keys=True) + '\n')
    path.chmod(0o600)


def main():
    original_driver = ORIGINAL / 'build_driver.py'
    assert digest(original_driver) == DRIVER_SHA
    spec = importlib.util.spec_from_file_location('frozen_split_builder', original_driver)
    d = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(d)
    assert d.sha(d.FREEZE) == FREEZE_SHA
    frozen = json.loads(d.FREEZE.read_text())
    assert d.state(HEAD) == frozen
    assert not d.DEST.exists() and d.APP.exists()
    assert not (OUT / 'continuation.started').exists(), 'Single evidence continuation only'
    (OUT / 'continuation.started').touch(exist_ok=False)
    immutable = {p.name: digest(p) for p in ORIGINAL.iterdir() if p.is_file()}
    fresh_tree = d.tree(d.APP)
    save('fresh-build-input-inventory.json', fresh_tree)
    failure = json.loads((ORIGINAL / 'build-result.json').read_text())
    assert failure == {'actualGUIloads': False, 'packaging_accepted': False,
        'prior_01_02_guards_backup_preserved': True, 'private_key_signing_performed': False,
        'runtime_acceptance': False, 'source_unchanged': True, 'status': 'failed'}
    checkpoint = json.loads((ORIGINAL / 'postcompile-parser-failure.json').read_text())
    assert checkpoint['flutter_compile_exit'] == 0 and checkpoint['freeze_sha256'] == FREEZE_SHA
    assert (ORIGINAL / 'source-inputs-before.json').read_bytes() == (ORIGINAL / 'source-inputs-after.json').read_bytes()
    log = (ORIGINAL / 'flutter-build.log').read_text()
    assert '** BUILD SUCCEEDED **' in log and log.rstrip().endswith('exiting with code 0')
    journal = [json.loads(line) for line in (ORIGINAL / 'commands.jsonl').read_text().splitlines()]
    builds = [record for record in journal if record['output'] == 'flutter-build.log']
    expected_build = d.SANDBOX + [str(d.SDK / 'bin/flutter'), '-v', 'build', 'macos', '--release', '--no-pub',
        '--dart-define-from-file=env.json', '--dart-define=MACOS_MANAGED_HELPER=true',
        '--build-name=0.9.7', '--build-number=2026111303']
    assert len(builds) == 1 and builds[0]['argv'] == expected_build
    raw = (ORIGINAL / 'effective-xcode-settings.json').read_text()
    assert raw.startswith(PREFIX), 'Only exact reviewed destination warning may be separated'
    clean = raw[len(PREFIX):]
    settings = json.loads(clean)
    assert isinstance(settings, list) and settings
    (OUT / 'effective-xcode-settings.json').write_text(clean)
    (OUT / 'effective-xcode-settings.stderr.txt').write_text(PREFIX)
    (OUT / 'flutter-build.log').symlink_to(ORIGINAL / 'flutter-build.log')
    before = d.preservation()
    assert before == json.loads((ORIGINAL / 'preservation-before.json').read_text())
    receipt = {'schema': 'flash-split-build-evidence-continuation-v1',
        'authorization_scope': 'same-fresh-compile static evidence and GUI staging only; no rebuild',
        'continuation_source_sha256': digest(Path(__file__)), 'original_driver_sha256': DRIVER_SHA,
        'freeze_sha256': FREEZE_SHA, 'original_evidence_sha256': immutable,
        'original_checkpoint': checkpoint, 'original_result': failure,
        'correction': 'Separate exactly pinned xcodebuild stderr warning prefix from unchanged original JSON stdout',
        'compile_count': 1, 'rebuild_performed': False, 'original_failure_overwritten': False}
    save('continuation-provenance.json', receipt)
    d.E = OUT
    outcome = {'status': 'failed', 'actualGUIloads': False, 'runtime_acceptance': False,
               'packaging_accepted': False, 'signing_performed': False}
    try:
        info = d.compile_evidence()
        assert d.state(HEAD) == frozen
        assert d.tree(d.APP) == fresh_tree
        d.run(['/usr/bin/python3', '-B', 'macos/packaging/stage_split_payload.py', 'gui',
               '--fresh-build-app', d.APP, '--output', d.DEST], 'stage-gui.log')
        split = d.module('stage_split_payload')
        entries = split.verify_split_gui(d.DEST)
        targets = []
        magic = d.module('stage_managed_payload').MACH_MAGIC
        for relative, item in entries.items():
            path = d.DEST / relative
            if item.get('kind') == 'file' and path.read_bytes()[:4] in magic:
                architectures = subprocess.check_output(['/usr/bin/lipo', '-archs', path], text=True).split()
                assert architectures == ['arm64']
                targets.append({'path': relative, 'architectures': architectures, **item})
        assert len(targets) == 7 and not (d.DEST / 'Contents/Library').exists()
        assert d.sha(d.DEST / 'Contents/MacOS/FlClashCore') == d.sha(d.APP / 'Contents/MacOS/FlClashCore')
        save('candidate-file-manifest.json', entries)
        save('macho-inventory.json', targets)
        metadata = {'schema': 'flash-split-build-v1', 'build_configuration': 'Release',
            'version': '0.9.7', 'build_number': '2026111303', 'source_head': HEAD,
            'source_freeze_sha256': FREEZE_SHA, 'source_status': frozen['source_status'],
            'defines': {'APP_ENV': 'stable', 'MACOS_MANAGED_HELPER': True,
                'FC_MANAGED_CANDIDATE_ENABLED': 1, 'FC_PINNED_CERTIFICATE_SHA1': d.CERT},
            'certificate_sha1': d.CERT, 'apple_team': '', 'startup_hardened': True,
            'startup_hardening_scope': 'static source/SDK-contract and compiled ObjC evidence only; no launch',
            'startup_source_hashes': {k: v for k, v in frozen['source_inputs'].items()
                if k.startswith('macos/Runner/') or k == 'macos/Runner.xcodeproj/project.pbxproj'},
            'sdk': frozen['sdk'], 'network_sandbox': 'deny network*', 'xcode_code_signing_allowed': False,
            'gui_cdhash_compile_default': '', 'split_service_staged': False,
            'helper_compile_with_gui_pin_pending': True, 'architectures': ['arm64'], 'macho_count': 7,
            'flutter_release_compile_succeeded': True, 'static_stage_audit_passed': True,
            'fresh_core_built': True, 'fresh_gui_aot_built': True, 'signing_performed': False,
            'runtime_acceptance': False, 'actualGUIloads': False, 'packaging_accepted': False,
            'production_components_executed': False,
            'original_build_driver_result': 'failed after successful compile: mixed stderr/stdout settings parser',
            'evidence_continuation': {'path': str(OUT / 'continuation-provenance.json'),
                'sha256': digest(OUT / 'continuation-provenance.json'),
                'source_sha256': digest(Path(__file__)), 'rebuild_performed': False}}
        metadata['compile_evidence'] = {str(p.relative_to(ORIGINAL)): digest(p)
            for p in [*(ORIGINAL / name for name in immutable), *OUT.iterdir()]
            if p.is_file() and p.suffix in ('.json', '.txt', '.log', '.jsonl')}
        assert d.state(HEAD) == frozen and d.preservation() == before
        assert d.tree(d.APP) == fresh_tree
        assert all(digest(ORIGINAL / name) == value for name, value in immutable.items())
        d.module('qualify_split_loads').validate_metadata(metadata, info, type('Pins', (), {'CERTIFICATE_SHA1': d.CERT}))
        save('build-metadata.json', metadata)
        outcome['status'] = 'static-build-evidence-and-gui-stage-passed'
    except BaseException:
        (OUT / 'failure-traceback.txt').write_text(traceback.format_exc())
        raise
    finally:
        after = d.state(HEAD)
        save('source-inputs-after.json', after['source_inputs'])
        preserved = d.preservation()
        save('preservation-after.json', preserved)
        outcome.update(source_unchanged=after == frozen,
                       prior_01_02_guards_backup_preserved=preserved == before,
                       original_evidence_unchanged=all(digest(ORIGINAL / name) == value for name, value in immutable.items()),
                       fresh_build_input_unchanged=d.tree(d.APP) == fresh_tree)
        save('continuation-result.json', outcome)
        assert all(outcome[k] for k in ('source_unchanged', 'prior_01_02_guards_backup_preserved',
                   'original_evidence_unchanged', 'fresh_build_input_unchanged'))
    print('GUI=' + str(d.DEST))
    print('METADATA=' + str(OUT / 'build-metadata.json'))


if __name__ == '__main__':
    main()
