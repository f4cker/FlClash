import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import struct
import sys
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('relay_build_driver', HERE / 'build_driver.py')
d = importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)


class PreparationTests(unittest.TestCase):
    def test_exact_warning_and_bare_json(self):
        raw = '[{"target":"Runner","buildSettings":{}}]\n'
        self.assertEqual(d.parse_xcode_settings(raw), (raw, ''))
        self.assertEqual(d.parse_xcode_settings(d.WARNING_PREFIX + raw), (raw, d.WARNING_PREFIX))

    def test_unknown_warning_or_trailing_content_fails_closed(self):
        raw = '[{"target":"Runner"}]\n'
        for value in ('other warning\n' + raw,
                      d.WARNING_PREFIX.replace('arm64', 'arm64e', 1) + raw,
                      d.WARNING_PREFIX + d.WARNING_PREFIX + raw,
                      raw + 'other warning', '[]', '[{"target":"NotRunner"}]',
                      '[{"target":"Runner"},{"target":"Runner"}]', '{}'):
            with self.subTest(value=value), self.assertRaises((ValueError, AssertionError)):
                d.parse_xcode_settings(value)

    def test_both_freeze_and_build_require_explicit_parent_go_before_state(self):
        for mode in ('freeze', 'build'):
            with mock.patch.object(sys, 'argv', ['build_driver.py', mode, '--expected-head', '0' * 40,
                                                '--parent-go', 'not-authorized']):
                with mock.patch.object(d, 'state', side_effect=RuntimeError('must not inspect state')) as state:
                    with self.assertRaisesRegex(AssertionError, 'Explicit parent GO'):
                        d.main()
                    state.assert_not_called()

    def test_missing_parent_go_fails_before_state(self):
        with mock.patch.object(sys, 'argv', ['build_driver.py', 'freeze', '--expected-head', '0' * 40]):
            with mock.patch.object(d, 'state') as state:
                with self.assertRaises(SystemExit):
                    d.main()
                state.assert_not_called()

    def test_credential_runtime_and_qualifier_modules_not_importable(self):
        for name in ('sign_split_payload', 'sign_fixed_payload', 'library_constraint', 'qualify_split_loads'):
            with self.subTest(name=name), self.assertRaisesRegex(AssertionError, 'No signer/qualifier'):
                d.module(name)

    def test_frozen_reference_pins_and_native_bytes(self):
        pins = d.pins()
        for name, digest in pins['historical'].items():
            self.assertEqual(d.sha(d.ROOT / name), digest, name)
        for name, digest in pins['native_startup'].items():
            self.assertEqual(d.sha(d.ROOT / name), digest, name)
        for name, digest in pins['packaging'].items():
            self.assertEqual(d.sha(d.ROOT / 'macos/packaging' / (name + '.py')), digest, name)

    def test_sdk_same_exact_old03_source_binary_and_toolchain(self):
        self.assertEqual(d.sdk_inputs(), d.pins()['sdk'])

    def test_pinned_stager_exact_modes_for_macho_and_resources(self):
        split = d.module('stage_split_payload')
        magic = d.module('stage_managed_payload').MACH_MAGIC
        with tempfile.TemporaryDirectory(prefix='relay-preparation-unit-') as tmp:
            root = Path(tmp)
            framework = root / 'Contents/Frameworks/App.framework/Versions/A'
            framework.mkdir(parents=True)
            binary = framework / 'App'
            binary.write_bytes(bytes.fromhex('cffaedfe') + b'fake-test-data-no-execution')
            binary.chmod(0o644)
            resource = root / 'Contents/Resources/copy-helper-swiftpm.sh'
            resource.parent.mkdir()
            resource.write_bytes(b'resource-test-data-no-execution')
            resource.chmod(0o755)
            manifest = root / 'Contents/Resources/NativeAssetsManifest.json'
            manifest.write_text('{}')
            manifest.chmod(0o600)
            (root / 'Contents/Resources/link').symlink_to('NativeAssetsManifest.json')
            split.normalize_modes(root)
            self.assertEqual(stat.S_IMODE(binary.stat().st_mode), 0o755)
            self.assertEqual(stat.S_IMODE(resource.stat().st_mode), 0o644)
            self.assertEqual(stat.S_IMODE(manifest.stat().st_mode), 0o644)
            entries = split.inventory(root)
            d.verify_stage_modes(entries, magic, app=root)
            first = d.tree(root)
            split.normalize_modes(root)
            self.assertEqual(d.tree(root), first)
            receipt = d.receipt_inventory(root, first, magic)
            self.assertEqual(receipt['entries']['Contents/Resources/copy-helper-swiftpm.sh'], {
                'kind': 'file', 'mode': '0o644', 'macho': False,
                'sha256': hashlib.sha256(resource.read_bytes()).hexdigest(),
                'size': resource.stat().st_size})
            self.assertEqual(receipt['entries']['Contents/Resources/link']['kind'], 'symlink')
            canonical = json.dumps(receipt['entries'], sort_keys=True, separators=(',', ':')).encode()
            self.assertEqual(receipt['tree_sha256'], hashlib.sha256(canonical).hexdigest())
            resource.chmod(0o755)
            with self.assertRaisesRegex(AssertionError, 'Unexpected staged file mode'):
                d.verify_stage_modes(split.inventory(root), magic, app=root)

    def test_stager_normalizes_before_and_after_mutable_audit(self):
        split = d.module('stage_split_payload')
        operations = []
        verifier = mock.Mock()
        verifier.audit.side_effect = lambda *args, **kwargs: operations.append(('audit', kwargs))
        with mock.patch.object(split, 'inventory'), mock.patch.object(split, 'new_destination'):
            with mock.patch.object(split.shutil, 'copytree'):
                with mock.patch.object(split, 'normalize_modes', side_effect=lambda *args: operations.append('modes')):
                    with mock.patch.object(split, 'check_layout', side_effect=lambda *args: operations.append('layout')):
                        with mock.patch.object(split, 'load_local', return_value=verifier):
                            split.stage_gui(Path('/nonexistent-test-input'), Path('/nonexistent-test-output'))
        self.assertEqual(operations, ['modes', 'layout', ('audit', {'mutate': True}), 'modes', 'layout'])

    def test_outputs_version_identity_and_offline_wrapper_are_new(self):
        self.assertEqual(d.DEST, d.ROOT / '.airbuild/artifacts/relay-2026111304/gui/Flash.app')
        self.assertEqual(d.CERT, 'BBA7F8529FD271B9848EC03A2CE3F4780F585556')
        shell = (d.ROOT / '.airbuild/tools/relay-build-2026111304-attempt02.sh').read_text()
        self.assertIn('(deny network*)', shell)
        self.assertIn('umask 027', shell)
        self.assertIn('GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local', shell)
        source = (HERE / 'build_driver.py').read_text()
        self.assertIn('--build-number=2026111304', source)
        self.assertIn('--no-pub', source)
        self.assertNotIn("module('qualify_split_loads')", source)
        self.assertNotIn("module('sign_split_payload')", source)

    def test_external_resolved_package_dart_hook_native_bytes_bound(self):
        with tempfile.TemporaryDirectory(prefix='relay-package-unit-') as tmp:
            base = Path(tmp)
            root, package = base / 'project', base / 'pub cache' / 'native_pkg'
            (root / '.dart_tool').mkdir(parents=True)
            for name in ('lib/a.dart', 'hook/build.dart', 'src/native.c', 'macos/plugin.m'):
                path = package / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text('initial')
            config = root / '.dart_tool/package_config.json'
            config.write_text(json.dumps({'packages': [{'name': 'native_pkg',
                'rootUri': package.as_uri(), 'packageUri': 'lib/'}]}))
            frozen = d.external_package_inputs(config, root)
            for name in ('lib/a.dart', 'hook/build.dart', 'src/native.c', 'macos/plugin.m'):
                path = package / name
                path.write_text('changed')
                self.assertNotEqual(frozen, d.external_package_inputs(config, root), name)
                path.write_text('initial')
            self.assertEqual(frozen, d.external_package_inputs(config, root))

    def test_platform_package_with_no_dart_library_records_missing_scope(self):
        with tempfile.TemporaryDirectory(prefix='relay-package-unit-') as tmp:
            root = Path(tmp).resolve()
            package = root / 'native_only'
            package.mkdir()
            config = root / 'package_config.json'
            config.write_text(json.dumps({'packages': [{'name': 'native_only',
                'rootUri': package.as_uri(), 'packageUri': 'lib/'}]}))
            result = d.external_package_inputs(config, root / 'project')
            self.assertEqual(result['native_only']['source_scopes']['lib']['entries'], {'missing': True})

    def test_only_exact_protected_os_tools_allow_hardlinks(self):
        info = mock.Mock(st_mode=stat.S_IFREG | 0o755, st_uid=0, st_nlink=2, st_size=17)
        for name in ('/usr/bin/xcodebuild', '/usr/bin/xcrun'):
            path = Path(name)
            with mock.patch.object(Path, 'lstat', return_value=info), mock.patch.object(Path, 'resolve', return_value=path):
                with mock.patch.object(d, 'sha', return_value='a' * 64):
                    self.assertEqual(d.tool_entry(path)['st_nlink'], 2)
                    info.st_mode = stat.S_IFREG | 0o775
                    with self.assertRaisesRegex(AssertionError, 'Unsafe protected OS tool'):
                        d.tool_entry(path)
                    info.st_mode = stat.S_IFREG | 0o755
                    info.st_uid = 501
                    with self.assertRaisesRegex(AssertionError, 'Unsafe protected OS tool'):
                        d.tool_entry(path)
                    info.st_uid = 0
        with tempfile.TemporaryDirectory(prefix='relay-hardlink-unit-') as tmp:
            first, second = Path(tmp) / 'xcodebuild', Path(tmp) / 'linked'
            first.write_bytes(b'nonexecuted-tool-fixture')
            second.hardlink_to(first) if hasattr(second, 'hardlink_to') else __import__('os').link(first, second)
            with self.assertRaisesRegex(AssertionError, 'Hardlinked input'):
                d.tool_entry(first)
            with self.assertRaisesRegex(AssertionError, 'Hardlinked input'):
                d.entry(first)

    def test_fresh_proof_files_remain_exact_original_qualifier_set(self):
        driver_ast = ast.parse((HERE / 'build_driver.py').read_text())
        names = next(ast.literal_eval(node.value) for node in ast.walk(driver_ast)
                     if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and
                        target.id == 'proof_names' for target in node.targets))
        adapter = d.ROOT / '.airbuild/tools/relay-qualify-2026111304.py'
        adapter_ast = ast.parse(adapter.read_text())
        expected = next(ast.literal_eval(node.value.args[0]) for node in ast.walk(adapter_ast)
                        if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and
                            target.id == 'PROOF_NAMES' for target in node.targets))
        self.assertEqual(len(names), 16)
        self.assertEqual(set(names), set(expected))

    def test_external_package_rejects_nonlocal_or_escaping_library_uri(self):
        with tempfile.TemporaryDirectory(prefix='relay-package-unit-') as tmp:
            base = Path(tmp)
            root = base / 'project'
            root.mkdir()
            package = base / 'package'
            package.mkdir()
            config = root / 'package_config.json'
            for uri, library in (('https://example.invalid/p', 'lib/'), (package.as_uri(), '../')):
                config.write_text(json.dumps({'packages': [{'name': 'p', 'rootUri': uri, 'packageUri': library}]}))
                with self.assertRaises(AssertionError):
                    d.external_package_inputs(config, root)

    def test_sdk_native_source_header_bytes_bound(self):
        with tempfile.TemporaryDirectory(prefix='relay-sdk-unit-') as tmp:
            root = Path(tmp)
            for scope in d.SDK_NATIVE_SCOPES:
                (root / scope).mkdir(parents=True)
                (root / scope / 'unit-input').write_text('initial')
            with mock.patch.object(d, 'SDK', root):
                frozen = d.sdk_native_inputs()
                for scope in d.SDK_NATIVE_SCOPES:
                    path = root / scope / 'unit-input'
                    path.write_text('changed')
                    self.assertNotEqual(frozen, d.sdk_native_inputs(), scope)
                    path.write_text('initial')

    def test_archives_all_prior_generated_outputs_before_overwrite(self):
        with tempfile.TemporaryDirectory(prefix='relay-archive-unit-') as tmp:
            root, output = Path(tmp) / 'project', Path(tmp) / 'evidence'
            output.mkdir()
            for name in d.MOVED_GENERATED + d.COPIED_GENERATED:
                path = root / name
                path.mkdir(parents=True)
                (path / 'prior-bytes').write_text(name)
            ephemeral = root / 'macos/Flutter/ephemeral/Flutter-Generated.xcconfig'
            ephemeral.write_text('old03-generated-seal')
            expected = d.generated_observation(root)
            paths, inventories = d.archive_generated(expected, root, output)
            self.assertEqual(set(paths), set(expected))
            for name in d.MOVED_GENERATED:
                self.assertFalse((root / name).exists())
            for name in d.COPIED_GENERATED:
                self.assertTrue((root / name).exists())
                (root / name / 'prior-bytes').write_text('regenerated-hook-control-or-cache')
            for name, original in inventories.items():
                self.assertEqual(d.tree(Path(paths[name])), original)
            self.assertEqual((Path(paths['macos/Flutter/ephemeral']) / ephemeral.name).read_text(),
                             'old03-generated-seal')
            self.assertNotEqual(d.generated_observation(root), expected)
            self.assertEqual(d.immutable_frozen({'source': 1, 'protected': 2, 'generated_before': 3}), {'source': 1})

    def test_ephemeral_swift_package_is_copied_and_remains_available_for_no_pub(self):
        name = 'macos/Flutter/ephemeral'
        self.assertNotIn(name, d.MOVED_GENERATED)
        self.assertIn(name, d.COPIED_GENERATED)
        with tempfile.TemporaryDirectory(prefix='relay-swiftpm-unit-') as tmp:
            root, output = Path(tmp) / 'project', Path(tmp) / 'evidence'
            package = root / name / 'Packages/FlutterGeneratedPluginSwiftPackage/Package.swift'
            package.parent.mkdir(parents=True)
            package.write_text('nonexecuted SwiftPM package fixture')
            output.mkdir()
            expected = d.generated_observation(root)
            paths, inventories = d.archive_generated(expected, root, output)
            self.assertTrue(package.is_file())
            self.assertEqual(d.tree(Path(paths[name])), inventories[name])
            self.assertEqual((Path(paths[name]) / package.relative_to(root / name)).read_bytes(), package.read_bytes())

    def test_generated_change_after_freeze_prevents_archive(self):
        with tempfile.TemporaryDirectory(prefix='relay-archive-unit-') as tmp:
            root = Path(tmp)
            expected = d.generated_observation(root)
            (root / 'build/native_assets').mkdir(parents=True)
            with self.assertRaisesRegex(AssertionError, 'Generated inputs changed'):
                d.archive_generated(expected, root, root)
            self.assertFalse((root / 'prior-generated').exists())

    def retained_fixture(self, root):
        for name in ('rust_api', 'objective_c', 'sqlite3'):
            selector = root / '.dart_tool/hooks_runner' / name / 'release'
            selector.mkdir(parents=True)
            asset = root / '.dart_tool/hooks_runner/shared' / name / 'native.dylib'
            asset.parent.mkdir(parents=True)
            asset.write_bytes(b'nonexecuted-native-fixture')
            request = {'config': {'linking_enabled': True, 'extensions': {'code_assets': {
                'target_os': 'macos', 'target_architecture': 'arm64'}}}, 'package_root': str(root)}
            (selector / 'input.json').write_text(json.dumps(request))
            response = {'status': 'success', 'dependencies': [], 'assets': [{'type': 'code_assets/code',
                'encoding': {'id': 'package:' + name, 'file': str(asset),
                             'link_mode': {'type': 'dynamic_loading_bundle'}}}]}
            (selector / 'output.json').write_text(json.dumps(response))

    def test_retained_selection_and_dylib_immutable_but_hook_metadata_mutable(self):
        with tempfile.TemporaryDirectory(prefix='relay-retained-unit-') as tmp:
            root = Path(tmp)
            self.retained_fixture(root)
            frozen = d.retained_native_inputs(root)
            control = root / frozen['rust_api']['output_path']
            response = json.loads(control.read_text())
            response['timestamp'] = 'hook-metadata-may-regenerate'
            control.write_text(json.dumps(response))
            self.assertEqual(frozen, d.retained_native_inputs(root))
            asset = root / frozen['rust_api']['asset_path']
            asset.write_bytes(b'changed-retained-input')
            self.assertNotEqual(frozen, d.retained_native_inputs(root))
            alternate = asset.with_name('alternate.dylib')
            alternate.write_bytes(b'nonexecuted-native-fixture')
            response['assets'][0]['encoding']['file'] = str(alternate)
            control.write_text(json.dumps(response))
            self.assertNotEqual(frozen, d.retained_native_inputs(root))

    def test_nonlinking_hook_control_is_not_release_asset_selector(self):
        with tempfile.TemporaryDirectory(prefix='relay-retained-unit-') as tmp:
            root = Path(tmp)
            self.retained_fixture(root)
            frozen = d.retained_native_inputs(root)
            control = root / '.dart_tool/hooks_runner/rust_api/nonlinking'
            control.mkdir()
            request = json.loads((root / frozen['rust_api']['input_path']).read_text())
            request['config']['linking_enabled'] = False
            (control / 'input.json').write_text(json.dumps(request))
            self.assertEqual(frozen, d.retained_native_inputs(root))
            request['config']['linking_enabled'] = True
            (control / 'input.json').write_text(json.dumps(request))
            with self.assertRaisesRegex(AssertionError, 'Expected one cached'):
                d.retained_native_inputs(root)

    def test_retained_macho_sections_prove_bytes_despite_install_name_changes(self):
        with tempfile.TemporaryDirectory(prefix='relay-macho-unit-') as tmp:
            root = Path(tmp)
            header = struct.pack('<8I', 0xfeedfacf, 0x100000c, 0, 6, 1, 152, 0, 0)
            segment = struct.pack('<II16sQQQQIIII', 0x19, 152, b'__TEXT', 0, 512, 0, 512, 7, 5, 1, 0)
            section = struct.pack('<16s16sQQIIIIIIII', b'__text', b'__TEXT', 256, 4, 256, 0, 0, 0, 0, 0, 0, 0)
            data = header + segment + section
            data += b'\0' * (256 - len(data)) + b'code'
            first, second = root / 'first', root / 'second'
            first.write_bytes(data)
            second.write_bytes(data + b'optional-signature-container')
            self.assertEqual(d.macho_sections(first), d.macho_sections(second))
            second.write_bytes(data[:-1] + b'X')
            self.assertNotEqual(d.macho_sections(first), d.macho_sections(second))

    def test_preparation_did_not_freeze_compile_or_stage(self):
        self.assertFalse(d.FREEZE.exists())
        self.assertFalse((d.E / 'build.started').exists())
        self.assertFalse(d.DEST.parent.parent.exists())


if __name__ == '__main__':
    unittest.main()
