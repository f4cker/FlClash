#!/usr/bin/python3
"""Static downstream gate. Never execute GUI, helper, Core, installers, or signing."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import stat
import sys
import tempfile
import types

ROOT = Path('/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup')
PACKAGING = ROOT / 'macos/packaging'
BASE = ROOT / '.airbuild/artifacts/relay-2026111304'
GUI = BASE / 'gui/Flash.app'
SERVICE = BASE / 'service/Flash.app'
WORK = BASE / 'service-compile'
BUILD = ROOT / '.airbuild/buildcandidate/relay-2026111304-attempt02'
METADATA = BUILD / 'build-metadata.json'
FREEZE = BUILD / 'input-freeze.json'
DELTA = BUILD / 'service-tooling-delta.json'
EVIDENCE = ROOT / '.airbuild/evidence/split-native-load-qualification/relay-2026111304-user2951.json'
SIGNER_SHA256 = '9023fbb047381d8b5a46802e6718eb449b49701557beb6b4e177da15e25f9a59'
QUALIFIER_SHA256 = 'TBD_PARENT_REVIEW_REQUIRED'
METADATA_SHA256 = 'TBD_PARENT_REVIEW_REQUIRED'
FREEZE_SHA256 = 'TBD_PARENT_REVIEW_REQUIRED'
EVIDENCE_SHA256 = 'TBD_PARENT_REVIEW_REQUIRED'
GUI_REPORT_SHA256 = 'TBD_PARENT_REVIEW_REQUIRED'
GUI_CDHASH = 'TBD_PARENT_REVIEW_REQUIRED'
GUI_TREE = 'TBD_PARENT_REVIEW_REQUIRED'
COMPILER_DRIVER = '.airbuild/tools/relay-service-compile-2026111304.py'
GATE_DRIVER = '.airbuild/tools/relay-service-verify-2026111304.py'
QUALIFIER_DRIVER = '.airbuild/tools/relay-qualify-2026111304.py'
PACKAGE_DRIVER = '.airbuild/tools/relay-packages-2026111304.sh'
PUBLISH_DRIVER = '.airbuild/tools/split-packages-03-publish.py'
ALLOWED_TOOLING = frozenset((COMPILER_DRIVER, GATE_DRIVER, QUALIFIER_DRIVER, PACKAGE_DRIVER, PUBLISH_DRIVER))
SOURCES = {
    'helper': ('macos/Shared/HelperTrust.m', 'macos/PrivilegedHelper/Supervisor.m', 'macos/PrivilegedHelper/Spawn.c'),
    'maintenance': ('macos/Shared/HelperTrust.m', 'macos/PrivilegedHelper/Maintenance.m'),
    'stub': ('macos/PrivilegedHelper/ServiceStub.c',),
}
BINARIES = {'helper': 'Contents/Library/HelperTools/FlashHelper',
            'maintenance': 'Contents/Library/HelperTools/FlashMaintenance', 'stub': 'Contents/MacOS/Flash'}
CORE = 'Contents/MacOS/FlClashCore'
SANDBOX = ['/usr/bin/sandbox-exec', '-p', '(version 1) (allow default) (deny network*)']


def read(path):
    if path.resolve(strict=True) != path:
        raise ValueError('Noncanonical source/evidence path')
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(descriptor, 'rb') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise ValueError('Expected single-link regular source/evidence')
        return stream.read()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def record(path):
    data = read(path)
    return {'sha256': digest(data), 'bytes': len(data), 'mode': stat.S_IMODE(path.stat().st_mode)}


def pinned_bytes(path, expected):
    if not re.fullmatch('[0-9a-f]{64}', expected or ''):
        raise ValueError('Explicit exact SHA256 pin required')
    data = read(path)
    if digest(data) != expected:
        raise ValueError('Pinned input changed: ' + str(path))
    return data


def pinned_json(path, expected):
    return json.loads(pinned_bytes(path, expected))


def module(name, expected):
    path = PACKAGING / (name + '.py')
    source = pinned_bytes(path, expected)
    loaded = types.ModuleType('_downstream_' + name)
    loaded.__file__ = str(path)
    exec(compile(source, str(path), 'exec'), loaded.__dict__)
    return loaded


def require_ready():
    for name in ('SIGNER_SHA256', 'QUALIFIER_SHA256', 'METADATA_SHA256', 'FREEZE_SHA256',
                 'EVIDENCE_SHA256', 'GUI_REPORT_SHA256', 'GUI_TREE'):
        if not re.fullmatch('[0-9a-f]{64}', globals()[name]):
            raise ValueError('Unreviewed relay pin: ' + name)
    if not re.fullmatch('[0-9a-f]{40}', GUI_CDHASH):
        raise ValueError('Unreviewed relay GUI CDHash')


def tooling_state(path, expected):
    require_ready()
    if path != DELTA:
        raise ValueError('Only the new relay downstream tooling delta is permitted')
    delta = pinned_json(path, expected)
    frozen = pinned_json(FREEZE, FREEZE_SHA256)
    if (delta.get('schema') != 'flash-relay-service-tooling-delta-v1' or
            delta.get('source_freeze_sha256') != FREEZE_SHA256 or
            set(delta.get('files', {})) != ALLOWED_TOOLING):
        raise ValueError('Unexpected relay downstream tooling delta')
    approved = dict(frozen['source_inputs'])
    for name, change in delta['files'].items():
        if change.get('before') != frozen['source_inputs'].get(name):
            raise ValueError('Relay before state differs from new source freeze')
        if record(ROOT / name) != change.get('after'):
            raise ValueError('Relay downstream tooling bytes changed')
        approved[name] = change['after']
    if (approved[QUALIFIER_DRIVER]['sha256'] != QUALIFIER_SHA256 or
            record(PACKAGING / 'sign_split_payload.py')['sha256'] != SIGNER_SHA256):
        raise ValueError('Relay qualifier or unchanged signer pin mismatch')
    return delta, frozen, approved


def source_snapshot(approved):
    pending = {name for group in SOURCES.values() for name in group}
    pending |= {'macos/Shared/HelperIdentity.h', 'macos/PrivilegedHelper/com.layoute.flash.helper.plist',
                'macos/packaging/stage_managed_helper.sh', 'macos/packaging/stage_split_payload.py',
                'macos/packaging/sign_split_payload.py', 'macos/packaging/sign_fixed_payload.py',
                'macos/packaging/stage_managed_payload.py', 'macos/packaging/library_constraint.py',
                'tool/macos/make_styled_dmg.sh', 'macos/packaging/dmg/background.png',
                'macos/packaging/dmg/background@2x.png',
                'macos/packaging/FixedGUI.entitlements', 'macos/packaging/normalize_package_info.py',
                'macos/packaging/pin_component_policy.py'}
    pending |= ALLOWED_TOOLING
    pending |= {str(path.relative_to(ROOT)) for path in (PACKAGING / 'installer').glob('*/*')}
    pending |= {str(path.relative_to(ROOT)) for path in
                (ROOT / 'macos/Runner/Assets.xcassets/AppIcon.appiconset').iterdir() if path.is_file()}
    result = {}
    while pending:
        name = pending.pop()
        if name in result:
            continue
        path = ROOT / name
        actual = record(path)
        if actual != approved.get(name):
            raise ValueError('Source differs from original freeze or bounded tooling delta: ' + name)
        result[name] = actual
        if path.suffix in ('.m', '.c', '.h'):
            for include in re.findall(r'^\s*#\s*(?:include|import)\s*"([^"\n]+)"', read(path).decode(), re.M):
                dependency = (path.parent / include).resolve(strict=True)
                if not dependency.is_relative_to(ROOT):
                    raise ValueError('Native include escapes frozen source root')
                pending.add(str(dependency.relative_to(ROOT)))
    return dict(sorted(result.items()))


def compile_argv(role, compiler, sdk, cdhash, output):
    if not re.fullmatch('[0-9a-f]{40}', cdhash or '') or cdhash != GUI_CDHASH:
        raise ValueError('Only exact qualified GUI CDHash accepted')
    args = [str(compiler), '-arch', 'arm64', '-mmacosx-version-min=14.0', '-isysroot', str(sdk)]
    if role != 'stub':
        args += ['-fobjc-arc', '-fblocks', '-DFC_MANAGED_CANDIDATE_ENABLED=1',
                 '-DFC_SPLIT_GUI_CDHASH="' + cdhash + '"', '-Wno-deprecated-declarations',
                 '-framework', 'Foundation', '-framework', 'Security']
        if role == 'maintenance':
            args += ['-framework', 'ServiceManagement']
    return args + [str(ROOT / source) for source in SOURCES[role]] + ['-o', str(output)]


def verify_gui(gui, metadata, evidence):
    require_ready()
    os.umask(0o077)
    if (gui, metadata, evidence) != (GUI, METADATA, EVIDENCE):
        raise ValueError('Only the exact new relay qualified GUI inputs are permitted')
    build = pinned_json(metadata, METADATA_SHA256)
    if (build.get('schema') != 'flash-split-build-v1' or build.get('version') != '0.9.7' or
            build.get('build_number') != '2026111304' or build.get('source_freeze_sha256') != FREEZE_SHA256):
        raise ValueError('Wrong relay build metadata/version/source freeze')
    pinned_bytes(evidence, EVIDENCE_SHA256)
    pinned_bytes(gui.parent / 'Flash.gui-signing-static.json', GUI_REPORT_SHA256)
    path = ROOT / QUALIFIER_DRIVER
    source = pinned_bytes(path, QUALIFIER_SHA256)
    qualifier = types.ModuleType('_relay_qualification_adapter')
    qualifier.__file__ = str(path)
    exec(compile(source, str(path), 'exec'), qualifier.__dict__)
    result = qualifier.verify(gui, metadata, evidence)
    if (result['before']['tree_sha256'] != GUI_TREE or
            result['before']['library_constraint']['cdhash'] != GUI_CDHASH):
        raise ValueError('Qualified GUI tree/CDHash changed')
    pinned_bytes(evidence, EVIDENCE_SHA256)
    return result


def validate_compile_receipt(compiled, signed, delta, delta_hash, sources, fixed):
    if (compiled.get('schema') != 'flash-split-service-compile-v1' or compiled.get('completed') is not True or
            compiled.get('driver_sha256') != delta['files'][COMPILER_DRIVER]['after']['sha256'] or
            compiled.get('signer_sha256') != SIGNER_SHA256 or
            compiled.get('tooling_delta_sha256') != delta_hash or
            compiled.get('gui_report_sha256') != GUI_REPORT_SHA256 or
            compiled.get('gui_cdhash') != GUI_CDHASH or compiled.get('gui_signed_tree_sha256') != GUI_TREE or
            compiled.get('qualification_sha256') != EVIDENCE_SHA256 or
            compiled.get('build_metadata_sha256') != METADATA_SHA256 or
            compiled.get('source_freeze_sha256') != FREEZE_SHA256 or compiled.get('source_inputs') != sources or
            compiled.get('native_qualification') is not False or compiled.get('installation_accepted') is not False or
            compiled.get('staged_unsigned_entries') != signed['before']['entries']):
        raise ValueError('Service compiler provenance does not bind exact unsigned signing inputs')
    if set(compiled['outputs']) != set(BINARIES):
        raise ValueError('Unexpected compiler outputs')
    for role, binary in BINARIES.items():
        output = compiled['outputs'][role]
        path = WORK / role
        expected_argv = compile_argv(role, compiled['toolchain']['compiler'], compiled['toolchain']['sdk'], GUI_CDHASH, path)
        if (output['path'] != str(path) or output['clang_argv'] != expected_argv or
                {key: output[key] for key in ('sha256', 'bytes', 'mode')} != record(path) or
                output['sha256'] != signed['before']['entries'][binary]['sha256'] or
                not any(command.get('argv') == SANDBOX + expected_argv and command.get('returncode') == 0
                        for command in compiled['commands'])):
            raise ValueError('Compiler output/argv differs from service unsigned bytes')
    core_hash = digest(fixed.read_regular(GUI / CORE))
    if any(value != core_hash for value in (compiled['gui_signed_core_sha256'],
            signed['before']['entries'][CORE]['sha256'], signed['after']['entries'][CORE]['sha256'])):
        raise ValueError('Service Core differs from qualified signed GUI Core')


def verify(gui, service, evidence, metadata, compile_receipt, compile_sha256,
           signing_receipt, signing_sha256, tooling_delta, tooling_sha256):
    require_ready()
    for value in (compile_sha256, signing_sha256, tooling_sha256):
        if not re.fullmatch('[0-9a-f]{64}', value or ''):
            raise ValueError('Explicit reviewed compile/signing/tooling SHA256 required')
    if service != SERVICE or compile_receipt != WORK / 'servicecompile-receipt.json' or signing_receipt != service.parent / 'Flash.service-signing-static.json':
        raise ValueError('Only fixed new service receipt paths are permitted')
    delta, _, approved = tooling_state(tooling_delta, tooling_sha256)
    sources = source_snapshot(approved)
    verify_gui(gui, metadata, evidence)
    signer = module('sign_split_payload', SIGNER_SHA256)
    fixed, constraint = signer.dependencies()
    verifier = fixed.trusted_verifier()
    stage = module('stage_split_payload', approved['macos/packaging/stage_split_payload.py']['sha256'])
    stage.check_layout(service, 'service')
    info = plistlib.loads(fixed.read_regular(service / 'Contents/Info.plist'))
    if (info.get('CFBundleShortVersionString') != '0.9.7' or info.get('CFBundleVersion') != '2026111304'):
        raise ValueError('Wrong relay service version')
    if info.get('LSMinimumSystemVersion') != '14.0':
        raise ValueError('Service requires the macOS 14 floor')
    signed = pinned_json(signing_receipt, signing_sha256)
    compiled = pinned_json(compile_receipt, compile_sha256)
    entries = fixed.inventory(service, verifier)
    gui_report = signer.gui_receipt(gui, GUI_REPORT_SHA256, fixed, constraint, verifier)
    if (signed.get('schema') != 1 or signed.get('phase') != 'service' or signed.get('app') != str(service) or
            signed.get('static_verification') is not True or signed.get('inputs') != gui_report['inputs'] or
            signed.get('pins') != gui_report['pins'] or signed.get('gui_receipt_sha256') != GUI_REPORT_SHA256 or
            signed.get('gui_cdhash') != GUI_CDHASH or
            any(signed.get(key) is not False for key in ('actualGUIloads', 'native_qualification', 'packaging_accepted', 'runtime_gate_changed')) or
            signed.get('after') != {'tree_sha256': fixed.tree_digest(entries), 'entries': entries} or
            signed.get('native_constraint_review') != signer.native_constraint_review(fixed) or
            signed['before']['tree_sha256'] != fixed.tree_digest(signed['before']['entries'])):
        raise ValueError('Service signing receipt differs from exact current artifact/policy')
    validate_compile_receipt(compiled, signed, delta, tooling_sha256, sources, fixed)
    targets = signer.signing_targets(service, entries, 'service', fixed)
    if len(targets) != 4:
        raise ValueError('Expected four service signature targets')
    signer.audit(service, 'service', fixed, verifier, targets)
    with tempfile.TemporaryDirectory(prefix='split-service-static-') as temporary:
        for index, target in enumerate(targets):
            work = Path(temporary) / str(index)
            work.mkdir(mode=0o700)
            constraint.inspect_slice(fixed.read_regular(service / target['binary']))
            target['verified_slices'] = fixed.verify_target(service, target, work)
            target['cdhash'] = constraint.cdhash(fixed.read_regular(service / target['binary'])).hex()
    if targets != signed['targets']:
        raise ValueError('Service target signatures differ from receipt')
    fixed.check_signing_delta(signed['before']['entries'], entries, [target for target in targets if target['role'] != 'core'])
    fixed.run_tool(['/usr/bin/codesign', '--verify', '--deep', '--strict', '--all-architectures', str(service)])
    if fixed.read_regular(service / CORE) != fixed.read_regular(gui / CORE) or fixed.inventory(service, verifier) != entries:
        raise ValueError('Service or signed Core changed during static verification')
    pinned_bytes(signing_receipt, signing_sha256)
    pinned_bytes(compile_receipt, compile_sha256)
    tooling_state(tooling_delta, tooling_sha256)
    if source_snapshot(approved) != sources:
        raise ValueError('Service compile inputs changed during static verification')
    verify_gui(gui, metadata, evidence)
    return {'gui_native_qualified': True, 'service_static_verified': True,
            'service_runtime_accepted': False, 'installer_accepted': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--prepare-not-execute', action='store_true')
    mode.add_argument('--verify', action='store_true')
    for flag in ('gui', 'service', 'evidence', 'build-metadata', 'service-compile-receipt',
                 'service-signing-receipt', 'tooling-delta'):
        parser.add_argument('--' + flag, type=Path)
    for flag in ('service-compile-sha256', 'service-signing-sha256', 'tooling-delta-sha256'):
        parser.add_argument('--' + flag)
    args = parser.parse_args()
    if args.prepare_not_execute:
        print(json.dumps({'prepared_only': True, 'gui': str(GUI), 'service': str(SERVICE),
                          'metadata': str(METADATA), 'freeze': str(FREEZE), 'evidence': str(EVIDENCE),
                          'tooling_delta': str(DELTA), 'qualification_adapter': str(ROOT / QUALIFIER_DRIVER),
                          'pins_ready': all(re.fullmatch('[0-9a-f]{64}', value) for value in
                                           (QUALIFIER_SHA256, METADATA_SHA256, FREEZE_SHA256,
                                            EVIDENCE_SHA256, GUI_REPORT_SHA256, GUI_TREE)) and
                                        bool(re.fullmatch('[0-9a-f]{40}', GUI_CDHASH))}))
        return
    if not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode):
        raise ValueError('Require /usr/bin/python3 -I -S -B')
    print(json.dumps(verify(args.gui, args.service, args.evidence, args.build_metadata,
                           args.service_compile_receipt, args.service_compile_sha256,
                           args.service_signing_receipt, args.service_signing_sha256,
                           args.tooling_delta, args.tooling_delta_sha256), sort_keys=True))


if __name__ == '__main__':
    main()
