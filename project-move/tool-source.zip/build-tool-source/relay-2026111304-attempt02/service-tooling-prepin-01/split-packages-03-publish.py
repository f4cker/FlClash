#!/usr/bin/env python3
"""One-off for 0.9.7+2026111303 packages-03: publish the signed service copy readable by the GUI user.

codesign ran under umask 077 and wrote Contents/_CodeSignature/CodeResources as 0600. Installed as
root, the non-root GUI cannot read it, so its static check of the helper reports signingRequired.
File modes are not part of the code signature: only that one mode changes, never any bytes.
The pinned packaging tooling is unchanged; this module only adds the bounded publish step.
"""
import importlib.util
from pathlib import Path
import stat
import sys

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location('stage_split_payload', ROOT / 'macos/packaging/stage_split_payload.py')
STAGE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(STAGE)
SEAL = 'Contents/_CodeSignature/CodeResources'
INCOMING = 'Library/Application Support/Flash/.incoming/Flash.app'


def verify_published(original, copied):
    expected = STAGE.check_layout(original, 'service')
    expected[SEAL] = dict(expected[SEAL], mode=0o644)
    entries = STAGE.check_layout(copied, 'service')
    if entries != expected:
        raise ValueError('Published service differs from signed input beyond the seal read mode')
    for relative, entry in entries.items():
        needed = 0o755 if entry['kind'] == 'directory' else 0o644
        if entry['mode'] & needed != needed or entry['mode'] & 0o7022:
            raise ValueError('Published service entry not readable by the GUI user: ' + relative)


def publish(original, copied):
    STAGE.verify_copy(original, copied, 'service')
    (copied / SEAL).chmod(0o644)
    verify_published(original, copied)


def verify_expanded(service, expanded, operation):
    normalizer = STAGE.load_local('normalize_package_info')
    data = (expanded / 'PackageInfo').read_bytes()
    if normalizer.normalize_info(data, operation) != data:
        raise ValueError('Expanded PackageInfo still has a hook timeout')
    scripts = expanded / 'Scripts'
    expected = {path.name: path.read_bytes() for path in (STAGE.PACKAGING / 'installer' / operation).iterdir()}
    expected['FlashMaintenance'] = (service / STAGE.MAINTENANCE).read_bytes()
    if {path.name for path in scripts.iterdir()} != set(expected):
        raise ValueError('Unexpected package scripts')
    for name, content in expected.items():
        path = scripts / name
        if path.is_symlink() or not path.is_file() or path.read_bytes() != content or stat.S_IMODE(path.stat().st_mode) != 0o755:
            raise ValueError('Package scripts must preserve reviewed bytes and mode 0755')
    payload = expanded / 'Payload'
    if operation in ('disable', 'remove'):
        if payload.exists():
            raise ValueError('Maintenance-only package must not have a payload')
        return
    app = payload / INCOMING
    verify_published(service, app)
    for directory, names, files in STAGE.os.walk(payload, followlinks=False):
        for name in names + files:
            path = Path(directory) / name
            if not path.is_relative_to(app) and path not in app.parents:
                raise ValueError('Unexpected package payload outside fixed service path')


def main():
    command, *args = sys.argv[1:]
    try:
        if command == 'publish' and len(args) == 2:
            publish(Path(args[0]), Path(args[1]))
        elif command == 'verify-expanded' and len(args) == 3:
            verify_expanded(Path(args[0]), Path(args[1]), args[2])
        else:
            raise ValueError('usage: publish ORIGINAL COPY | verify-expanded SERVICE EXPANDED OPERATION')
    except (ValueError, OSError, KeyError) as error:
        print('Publish step failed closed: ' + str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
