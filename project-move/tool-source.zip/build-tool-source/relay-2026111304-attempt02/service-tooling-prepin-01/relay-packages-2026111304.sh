#!/bin/bash
# No signing or installation. All receipt/tooling pins are supplied after parent review.
set -euo pipefail
umask 077
ROOT=/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup
if [[ $# == 1 && "$1" == --prepare-not-execute ]]; then
  printf '%s\n' 'PREPARED_ONLY: relay-2026111304/packages-01; new gate pins/receipt review required; no tools executed.'
  exit 0
fi
[[ $# == 7 && "$1" == --execute-after-parent-review && "$2" == --service-compile-sha256 &&
   "$4" == --service-signing-sha256 && "$6" == --tooling-delta-sha256 ]] || {
  echo 'usage: --prepare-not-execute | --execute-after-parent-review --service-compile-sha256 SHA256 --service-signing-sha256 SHA256 --tooling-delta-sha256 SHA256' >&2
  exit 64
}
compile_sha256="$3"
signing_sha256="$5"
tooling_sha256="$7"
for pin in "$compile_sha256" "$signing_sha256" "$tooling_sha256"; do
  [[ "$pin" =~ ^[0-9a-f]{64}$ ]] || { echo 'Exact reviewed SHA256 pins required' >&2; exit 65; }
done
export PATH=/usr/bin:/bin:/usr/sbin:/sbin LANG=C LC_ALL=C
cd "$ROOT"
A="$ROOT/.airbuild/artifacts/relay-2026111304"
B="$ROOT/.airbuild/buildcandidate/relay-2026111304-attempt02"
source_dir="$ROOT/macos/packaging"
gui="$A/gui/Flash.app"
service="$A/service/Flash.app"
output="$A/packages-01"
[[ ! -e "$output" && ! -L "$output" ]] || exit 78
python() { /usr/bin/env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C /usr/bin/python3 -I -S -B "$@"; }
split() { python "$source_dir/stage_split_payload.py" "$@"; }
publish() { python "$ROOT/.airbuild/tools/split-packages-03-publish.py" "$@"; }
raw_package() { python "$source_dir/normalize_package_info.py" "$@"; }
verify_evidence() {
  python - "$B/service-tooling-delta.json" "$tooling_sha256" \
    "$ROOT/.airbuild/tools/relay-service-verify-2026111304.py" \
    --verify --gui "$gui" --service "$service" \
    --evidence "$ROOT/.airbuild/evidence/split-native-load-qualification/relay-2026111304-user2951.json" \
    --build-metadata "$B/build-metadata.json" \
    --service-compile-receipt "$A/service-compile/servicecompile-receipt.json" \
    --service-compile-sha256 "$compile_sha256" \
    --service-signing-receipt "$A/service/Flash.service-signing-static.json" \
    --service-signing-sha256 "$signing_sha256" \
    --tooling-delta "$B/service-tooling-delta.json" --tooling-delta-sha256 "$tooling_sha256" <<'PYGATE'
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys


def regular(path):
    if path.resolve(strict=True) != path:
        raise ValueError('Noncanonical gate/delta path')
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(descriptor, 'rb') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise ValueError('Expected single-link regular gate/delta')
        return stream.read()


delta_path, delta_pin, gate_path = sys.argv[1:4]
data = regular(Path(delta_path))
if hashlib.sha256(data).hexdigest() != delta_pin:
    raise ValueError('Reviewed relay tooling delta pin mismatch')
delta = json.loads(data)
expected = delta['files']['.airbuild/tools/relay-service-verify-2026111304.py']['after']['sha256']
source = regular(Path(gate_path))
if not re.fullmatch('[0-9a-f]{64}', expected) or hashlib.sha256(source).hexdigest() != expected:
    raise ValueError('Reviewed relay static gate pin mismatch')
sys.argv = [gate_path] + sys.argv[4:]
exec(compile(source, gate_path, 'exec'), {'__name__': '__main__', '__file__': gate_path})
PYGATE
}
verify_evidence
/bin/mkdir -m 0700 "$output"
work="$output/payload"
/bin/mkdir -p "$work/Library/Application Support/Flash/.incoming"
/usr/bin/ditto "$service" "$work/Library/Application Support/Flash/.incoming/Flash.app"
publish publish "$service" "$work/Library/Application Support/Flash/.incoming/Flash.app"
components="$output/components.plist"
/usr/bin/pkgbuild --analyze --root "$work" "$components"
python "$source_dir/pin_component_policy.py" "$components"
for operation in install repair disable remove; do
  scripts="$output/$operation-scripts"
  /bin/mkdir "$scripts"
  /bin/cp "$source_dir/installer/$operation/"* "$scripts/"
  /bin/cp "$service/Contents/Library/HelperTools/FlashMaintenance" "$scripts/FlashMaintenance"
  /bin/chmod 0755 "$scripts/"*
  built="$output/$operation-built.pkg"
  package="$output/Flash-helper-$operation.pkg"
  if [[ "$operation" == install || "$operation" == repair ]]; then
    /usr/bin/pkgbuild --root "$work" --component-plist "$components" --ownership recommended --scripts "$scripts" \
      --identifier "com.layoute.flash.managed.$operation" --install-location / "$built"
  else
    /usr/bin/pkgbuild --nopayload --scripts "$scripts" --install-location / \
      --identifier "com.layoute.flash.managed.$operation" "$built"
  fi
  raw="$output/$operation-raw"
  snapshot="$output/$operation-raw-members.json"
  /bin/mkdir "$raw"
  /usr/bin/xar -xf "$built" -C "$raw"
  raw_package normalize "$raw" "$snapshot" "$operation"
  raw_package verify "$raw" "$snapshot" "$operation"
  (cd "$raw" && /usr/bin/xar -cf "$package" --compression=none *)
  final_raw="$output/$operation-final-raw"
  /bin/mkdir "$final_raw"
  /usr/bin/xar -xf "$package" -C "$final_raw"
  raw_package verify "$final_raw" "$snapshot" "$operation"
  expanded="$output/$operation-expanded"
  /usr/sbin/pkgutil --expand-full "$package" "$expanded"
  publish verify-expanded "$service" "$expanded" "$operation"
  if [[ "$operation" == install || "$operation" == repair ]]; then
    seal="$expanded/Payload/Library/Application Support/Flash/.incoming/Flash.app/Contents/_CodeSignature/CodeResources"
    /bin/ls -l "$seal"
    lsbom -p MUGf "$raw/Bom" | /usr/bin/grep "_CodeSignature/CodeResources$"
  fi
  verify_evidence
done
dmg_root="$output/dmg-root"
/bin/mkdir "$dmg_root"
/usr/bin/ditto "$gui" "$dmg_root/Flash.app"
split verify-copy --kind gui --original "$gui" --copy "$dmg_root/Flash.app"
verify_evidence
"$ROOT/tool/macos/make_styled_dmg.sh" "$dmg_root/Flash.app" "$output/Flash.dmg"
verify_evidence
for f in Flash.dmg Flash-helper-install.pkg Flash-helper-repair.pkg Flash-helper-disable.pkg Flash-helper-remove.pkg; do
  /usr/bin/shasum -a 256 "$output/$f"
done
echo 'RELAY_PACKAGES_01_BUILT: service seal published 0644, styled DMG; installation remains unverified.'
