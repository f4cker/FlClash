#!/usr/bin/python3
"""Fresh relay GUI qualification. PREPARED ONLY until the parent pins metadata.

Static modes never launch application code or access a keychain. The parent must
freeze all inputs/ancestors and exclude same-UID writers before approved use.
"""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import stat
import subprocess
import sys
import types

ROOT = Path('/Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup')
PACKAGING = ROOT / 'macos/packaging'
SELF = ROOT / '.airbuild/tools/relay-qualify-2026111304.py'
BUILD_ROOT = ROOT / '.airbuild/buildcandidate/relay-2026111304-attempt02'
BUILD_METADATA = BUILD_ROOT / 'build-metadata.json'
BUILD_METADATA_SHA256 = 'PARENT_REVIEW_REQUIRED_NEW_BUILD_METADATA_SHA256'
GUI_APP = ROOT / '.airbuild/artifacts/relay-2026111304/gui/Flash.app'
SDK = Path('/Users/layoute/fvm/versions/3.47.4')
EVIDENCE_ROOT = ROOT / '.airbuild/evidence/split-native-load-qualification'
EVIDENCE = EVIDENCE_ROOT / 'relay-2026111304-user2951.json'
ATTEMPT = EVIDENCE_ROOT / 'relay-2026111304-user2951.attempt.json'
APPROVAL = 'relay-2026111304-user2951-native-loads-exactly-once'
SCHEMA = 'flash-relay-native-loads-2026111304-v1'
STATE_SCHEMA = 'flash-relay-frozen-state-2026111304-v1'
PINS = {
    'qualify_split_loads.py': '70f06cc6caa2deecdcc62d8f01b52c2e07526a01daa4b9207bab0ff55295c8a1',
    'qualify_native_loads.py': '053311e347049f0ee4ba7745b7120817617600e27fc0014bf2f8bf389377b1bc',
    'sign_split_payload.py': '9023fbb047381d8b5a46802e6718eb449b49701557beb6b4e177da15e25f9a59',
    'sign_fixed_payload.py': '2574d8356c2ac9ad50cb94bc476a11463f6ee8f30d24fab97fbe7432c880771a',
    'library_constraint.py': 'b1a402989ca8fd4375b081c68df5d974cf5be635389f399ff9f4ba17e7b2d7de',
    'stage_managed_payload.py': '006b6d11b10d0875654fab009e7b6a231ebfb83f12cbb0a8c77ec0c463d65829',
}
PROOF_NAMES = frozenset((
    'input-freeze.json', 'sdk-inputs-before.json', 'sdk-inputs-after.json',
    'source-inputs-before.json', 'source-inputs-after.json', 'build-result.json',
    'fresh-build-input-inventory.json', 'candidate-file-manifest.json', 'macho-inventory.json',
    'unsigned-stage-inventory.json', 'unsigned-pre-sign-inventory.json',
    'core-source-byte-binding.json', 'native-bootstrap-objects.json',
    'sdk-framework-binary-proof.json', 'preservation-before.json', 'preservation-after.json',
))
DEPENDENCY_FREEZES = {
    'external_package_inputs': 'external-package-inputs',
    'sdk_native_inputs': 'sdk-native-inputs',
    'retained_native_inputs': 'retained-native-inputs',
}
DEPENDENCY_NAMES = frozenset(
    stem + '-' + phase + '.json'
    for stem in DEPENDENCY_FREEZES.values() for phase in ('before', 'after'))
COMPILE_NAMES = frozenset((
    'retained-native-bundle-proof.json', 'generated-output-policy.json',
    'preserved-generated-inventories.json',
    'commands.jsonl', 'build.started', 'flutter-build.log', 'setup-hook.log',
    'effective-xcode-settings.json', 'effective-xcode-settings.raw.txt',
    'effective-xcode-settings.stderr.txt', 'sealed-dart-defines.json',
    'runner-compile-responses.json', 'FlashFlutterEngine-object-disassembly.txt',
    'FlashFlutterEngine-object-objc.txt', 'compiled-bootstrap-object.json',
    'actual-aot-compile-commands.json', 'fresh-output-provenance.json', 'core-buildinfo.txt',
    'intermediate-helper-tools.json', 'stage-gui.log', 'candidate.xcconfig',
    'bootstrap-sdk-contract-tests.log', 'flutter-version.json', 'go-version.txt',
    'cargo-version.txt', 'rust-version.txt', 'rust-toolchains.txt', 'xcode-version.txt',
    'clang-version.txt', 'preserved-generated-paths.json', 'build_driver.py',
    'preparation-pins.json',
))
IDENTITY_FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink',
                   'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_flags')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha_value(value):
    return isinstance(value, str) and re.fullmatch(r'[0-9a-f]{64}', value) is not None


def metadata_pin():
    if not sha_value(BUILD_METADATA_SHA256):
        raise ValueError('STOP: parent must review and pin fresh build metadata before use')


def identity(info):
    return tuple(getattr(info, key, None) for key in IDENTITY_FIELDS)


def check_ancestors(path, fixed=None):
    if (not path.is_absolute() or '..' in path.parts or
            path.resolve(strict=True) != path):
        raise ValueError('Noncanonical protected path: ' + str(path))
    for node in path.parents:
        info = node.lstat()
        if (not stat.S_ISDIR(info.st_mode) or info.st_uid not in {0, os.getuid()} or
                info.st_mode & 0o7022):
            raise ValueError('Unsafe protected ancestor: ' + str(node))
        if fixed is not None and (node == ROOT / '.airbuild' or
                                  node.is_relative_to(ROOT / '.airbuild')):
            fixed.require_no_acl(node)


def read_protected(path, fixed=None):
    path = Path(path)
    check_ancestors(path, fixed)
    if fixed is not None:
        fixed.require_no_acl(path)
    before = path.lstat()
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        opened = os.fstat(stream.fileno())
        if (identity(before) != identity(opened) or not stat.S_ISREG(opened.st_mode) or
                opened.st_uid != os.getuid() or opened.st_nlink != 1 or
                opened.st_mode & 0o7022):
            raise ValueError('Unsafe protected regular file: ' + str(path))
        data = stream.read()
        if identity(opened) != identity(os.fstat(stream.fileno())):
            raise ValueError('Protected input changed during read')
    if fixed is not None:
        fixed.require_no_acl(path)
    if identity(before) != identity(path.lstat()) or path.resolve(strict=True) != path:
        raise ValueError('Protected path identity changed')
    return data


def json_protected(path, fixed):
    data = read_protected(path, fixed)
    return json.loads(data), digest(data)


def pinned_module(name, fixed=None):
    if name not in PINS:
        raise ValueError('Unreviewed frozen import: ' + name)
    path = PACKAGING / name
    source = read_protected(path, fixed)
    if digest(source) != PINS[name]:
        raise ValueError('Frozen import changed: ' + name)
    module = types.ModuleType('_relay_' + name.replace('.', '_'))
    module.__file__ = str(path)
    exec(compile(source, str(path), 'exec'), module.__dict__)
    return module


def dependencies():
    fixed = pinned_module('sign_fixed_payload.py')
    if digest(read_protected(PACKAGING / 'sign_fixed_payload.py', fixed)) != PINS['sign_fixed_payload.py']:
        raise ValueError('Fixed signer changed during bootstrap')
    modules = {'sign_fixed_payload.py': fixed}
    for name in PINS:
        if name not in modules:
            modules[name] = pinned_module(name, fixed)
    signer = modules['sign_split_payload.py']
    legacy = modules['qualify_native_loads.py']
    split = modules['qualify_split_loads.py']
    constraint = modules['library_constraint.py']
    verifier = modules['stage_managed_payload.py']
    verifier.subprocess = types.SimpleNamespace(check_output=fixed.verifier_output)
    def frozen_import(name, expected):
        if name not in modules or PINS[name] != expected:
            raise ValueError('Unreviewed frozen dependency request')
        return modules[name]

    fixed.trusted_verifier = lambda: verifier
    signer.frozen_module = frozen_import
    legacy.driver = lambda: fixed
    split.native = lambda: legacy
    split.driver = lambda: signer
    split.GUI_APP, split.BUILD_ROOT, split.BUILD_METADATA = GUI_APP, BUILD_ROOT, BUILD_METADATA
    split.BUILD_METADATA_SHA256 = BUILD_METADATA_SHA256
    split.SCHEMA, split.STATE_SCHEMA = SCHEMA, STATE_SCHEMA
    split.validate_metadata = validate_metadata
    split.build_provenance = build_provenance
    original_state = split.frozen_state

    def frozen_state(app, metadata_path, supplied_signer, scratch):
        metadata_pin()
        if app != GUI_APP or metadata_path != BUILD_METADATA or supplied_signer is not signer:
            raise ValueError('Only exact fresh relay inputs are allowed')
        before = source_state(fixed)
        json_protected(metadata_path, fixed)
        json_protected(app.parent / 'Flash.gui-signing-static.json', fixed)
        marker = validate_attempt(fixed, before['adapter_sha256'])
        state = original_state(app, metadata_path, signer, scratch)
        if (source_state(fixed) != before or
                validate_attempt(fixed, before['adapter_sha256']) != marker):
            raise ValueError('Qualification sources/attempt changed during static checks')
        state['adapter'] = before
        state['attempt_marker_sha256'] = marker
        return state

    split.frozen_state = frozen_state
    return split, signer, legacy, fixed


def source_state(fixed):
    if Path(__file__) != SELF:
        raise ValueError('Adapter must run from its reviewed path')
    sources = {name: digest(read_protected(PACKAGING / name, fixed)) for name in PINS}
    if sources != PINS:
        raise ValueError('Frozen qualification sources changed')
    return {'path': str(SELF), 'adapter_sha256': digest(read_protected(SELF, fixed)),
            'frozen_imports_sha256': sources}


def validate_metadata(metadata, info, fixed):
    defines = metadata.get('defines', {})
    if (metadata.get('schema') != 'flash-split-build-v1' or
            metadata.get('build_configuration') != 'Release' or
            metadata.get('version') != '0.9.7' or metadata.get('build_number') != '2026111304' or
            info.get('CFBundleShortVersionString') != '0.9.7' or
            info.get('CFBundleVersion') != '2026111304' or
            metadata.get('startup_hardened') is not True or
            metadata.get('certificate_sha1') != fixed.CERTIFICATE_SHA1 or
            metadata.get('apple_team') != '' or
            any(metadata.get(key) is not False for key in (
                'runtime_acceptance', 'actualGUIloads', 'packaging_accepted', 'signing_performed',
                'production_components_executed', 'xcode_code_signing_allowed', 'split_service_staged',
                'frozen_old03_qualifier_invoked')) or
            defines.get('APP_ENV') != 'stable' or defines.get('MACOS_MANAGED_HELPER') is not True or
            type(defines.get('FC_MANAGED_CANDIDATE_ENABLED')) is not int or
            defines.get('FC_MANAGED_CANDIDATE_ENABLED') != 1 or
            defines.get('FC_PINNED_CERTIFICATE_SHA1') != fixed.CERTIFICATE_SHA1 or
            metadata.get('gui_stage_path') != str(GUI_APP) or
            metadata.get('network_sandbox') != 'deny network*' or
            metadata.get('gui_cdhash_compile_default') != '' or
            metadata.get('helper_compile_with_gui_pin_pending') is not True or
            metadata.get('parent_owned_signing_probe_pending') is not True):
        raise ValueError('Missing immutable fresh Release relay metadata')
    values = [base64.b64decode(value, validate=True).decode('utf-8')
              for value in info.get('FlashDartDefines', '').split(',') if value]
    for prefix, expected in (
            ('MACOS_MANAGED_HELPER=', 'MACOS_MANAGED_HELPER=true'),
            ('FLUTTER_BUILD_NUMBER=', 'FLUTTER_BUILD_NUMBER=2026111304')):
        if [value for value in values if value.startswith(prefix)] != [expected]:
            raise ValueError('Sealed Dart metadata must describe the fresh managed build')


def relative_path(base, relative):
    if (not isinstance(relative, str) or not relative or Path(relative).is_absolute() or
            str(Path(relative)) != relative or '..' in Path(relative).parts or relative == '.'):
        raise ValueError('Noncanonical evidence/input reference')
    return base / relative


def validate_input_records(records):
    if not isinstance(records, dict) or not records:
        raise ValueError('Missing frozen source/SDK input records')
    for name, item in records.items():
        relative_path(ROOT, name)
        if not isinstance(item, dict):
            raise ValueError('Malformed frozen input')
        if 'sha256' in item:
            if (not sha_value(item['sha256']) or type(item.get('bytes')) is not int or
                    item['bytes'] < 0 or type(item.get('mode')) is not int):
                raise ValueError('Malformed frozen input hash/size/mode')
        elif 'gitlink_head' in item:
            if (not re.fullmatch(r'[0-9a-f]{40}', item['gitlink_head']) or
                    not isinstance(item.get('status'), str)):
                raise ValueError('Malformed frozen gitlink')
        elif 'symlink' in item:
            if not isinstance(item['symlink'], str):
                raise ValueError('Malformed frozen source link')
        elif item != {'missing': True}:
            raise ValueError('Unknown frozen input type')


def project_unsigned(inventory, manifest, macho, targets, fixed):
    exact_targets(targets)
    binaries = {target['binary'] for target in targets}
    if (len(targets) != 7 or len(binaries) != 7 or len(macho) != 7 or
            {item['path'] for item in macho} != binaries or
            inventory.get('.') != {'directory': True, 'mode': 0o755}):
        raise ValueError('Frozen unsigned inventory must contain the exact seven GUI targets')
    before, projected = {}, {}
    for relative, item in inventory.items():
        if relative == '.':
            continue
        relative_path(GUI_APP, relative)
        mode = item['mode']
        if type(mode) is not int or mode & 0o7022:
            raise ValueError('Unsafe frozen unsigned mode')
        entry, staged = {'mode': oct(mode)}, {'mode': mode}
        if item.get('directory') is True:
            if item != {'directory': True, 'mode': 0o755}:
                raise ValueError('Unexpected frozen directory')
            entry['kind'] = staged['kind'] = 'directory'
        elif 'symlink' in item:
            if set(item) != {'mode', 'symlink'} or not isinstance(item['symlink'], str):
                raise ValueError('Unexpected frozen symlink')
            entry.update(kind='symlink', target=item['symlink'])
            staged.update(kind='link', target=item['symlink'])
        else:
            if (set(item) != {'mode', 'bytes', 'sha256'} or not sha_value(item['sha256']) or
                    type(item['bytes']) is not int or item['bytes'] < 0 or
                    mode != (0o755 if relative in binaries else 0o644)):
                raise ValueError('Unexpected frozen file')
            entry.update(kind='file', sha256=item['sha256'], size=item['bytes'], macho=relative in binaries)
            staged.update(kind='file', sha256=item['sha256'])
        before[relative], projected[relative] = entry, staged
    for item in macho:
        relative = item['path']
        if (item.get('architectures') != ['arm64'] or item.get('sha256') != inventory[relative].get('sha256') or
                {key: value for key, value in item.items() if key not in {'path', 'architectures'}} != manifest[relative]):
            raise ValueError('Frozen Mach-O inventory differs from unsigned manifest')
    if manifest != projected:
        raise ValueError('Frozen unsigned manifest differs from inventory')
    return {'tree_sha256': fixed.tree_digest(before), 'entries': before}


def build_provenance(metadata_path, metadata, metadata_hash, report, targets, fixed):
    metadata_pin()
    if metadata_path != BUILD_METADATA or metadata_hash != BUILD_METADATA_SHA256:
        raise ValueError('Expected exact parent-pinned fresh relay metadata')
    proof = metadata.get('fresh_build_provenance', {})
    if (metadata.get('architectures') != ['arm64'] or type(metadata.get('macho_count')) is not int or
            metadata['macho_count'] != 7 or any(metadata.get(key) is not True for key in (
                'flutter_release_compile_succeeded', 'fresh_core_built', 'fresh_gui_aot_built',
                'static_stage_audit_passed')) or any(metadata.get(key) is not False for key in (
                'signing_performed', 'production_components_executed', 'runtime_acceptance',
                'actualGUIloads', 'packaging_accepted')) or
            proof.get('schema') != 'flash-relay-fresh-build-proof-v1' or
            type(proof.get('compile_count')) is not int or proof['compile_count'] != 1 or
            proof.get('rebuild_continuation') is not False or proof.get('evidence_root') != str(BUILD_ROOT)):
        raise ValueError('Incomplete fresh single-compile provenance')
    hashes = metadata.get('compile_evidence', {})
    if (not isinstance(hashes, dict) or not (PROOF_NAMES | COMPILE_NAMES | DEPENDENCY_NAMES) <= hashes.keys() or
            proof.get('compile_evidence') != hashes or set(proof.get('files', {})) != PROOF_NAMES):
        raise ValueError('Missing recorded compile/stage evidence hashes')
    documents = {}
    for relative, expected in hashes.items():
        path = relative_path(BUILD_ROOT, relative)
        if not sha_value(expected):
            raise ValueError('Invalid compile evidence SHA256')
        data = read_protected(path, fixed)
        if digest(data) != expected:
            raise ValueError('Frozen fresh build evidence changed: ' + relative)
        if relative in PROOF_NAMES | DEPENDENCY_NAMES or relative in {
                'effective-xcode-settings.json', 'sealed-dart-defines.json',
                'runner-compile-responses.json', 'fresh-output-provenance.json', 'preparation-pins.json'}:
            documents[relative] = json.loads(data)
    for relative, descriptor in proof['files'].items():
        if descriptor != {'path': relative, 'sha256': hashes[relative]}:
            raise ValueError('Fresh proof descriptor hash/path mismatch')
    if (proof.get('driver_sha256') != hashes['build_driver.py'] or
            proof.get('preparation_pins_sha256') != hashes['preparation-pins.json']):
        raise ValueError('Fresh build driver/preparation binding mismatch')
    freeze = documents['input-freeze.json']
    if (hashes['input-freeze.json'] != metadata.get('source_freeze_sha256') or
            not re.fullmatch(r'[0-9a-f]{40}', metadata.get('source_head', '')) or
            freeze.get('source_head') != metadata['source_head'] or
            not isinstance(freeze.get('source_status'), str) or
            freeze['source_status'] != metadata.get('source_status') or
            freeze.get('core_submodule_head') != metadata.get('core_submodule_head') or
            freeze.get('sdk') != metadata.get('sdk') or
            documents['source-inputs-before.json'] != freeze.get('source_inputs') or
            documents['source-inputs-after.json'] != freeze.get('source_inputs') or
            documents['sdk-inputs-before.json'] != freeze.get('sdk') or
            documents['sdk-inputs-after.json'] != freeze.get('sdk')):
        raise ValueError('Fresh source-head/status/input/SDK freeze binding mismatch')
    validate_input_records(freeze['source_inputs'])
    for field, stem in DEPENDENCY_FREEZES.items():
        frozen = freeze.get(field)
        if (not isinstance(frozen, dict) or not frozen or
                documents[stem + '-before.json'] != frozen or
                documents[stem + '-after.json'] != frozen):
            raise ValueError('Frozen dependency before/after binding mismatch: ' + field)
    if (set(freeze['retained_native_inputs']) != {'rust_api', 'objective_c', 'sqlite3'} or
            not isinstance(freeze.get('generated_before'), dict) or not freeze['generated_before']):
        raise ValueError('Missing retained native/generated-input freeze')
    sdk = freeze['sdk']
    validate_input_records(sdk.get('files'))
    if sdk != documents['preparation-pins.json'].get('sdk'):
        raise ValueError('SDK differs from reviewed fresh preparation inputs')
    if (sdk.get('version', {}).get('frameworkVersion') != '3.47.4' or
            not freeze.get('tooling') or not freeze.get('protected')):
        raise ValueError('Missing source/toolchain preservation freeze')
    for relative, item in sdk['files'].items():
        data = read_protected(relative_path(SDK, relative), fixed)
        if digest(data) != item['sha256'] or len(data) != item['bytes']:
            raise ValueError('SDK input changed: ' + relative)
    startup = {key: value for key, value in freeze['source_inputs'].items()
               if key.startswith('macos/Runner/') or key == 'macos/Runner.xcodeproj/project.pbxproj'}
    if not startup or metadata.get('startup_source_hashes') != startup:
        raise ValueError('Native startup source freeze mismatch')
    core = documents['core-source-byte-binding.json']
    if (core.get('core_source_inputs') != {key: value for key, value in freeze['source_inputs'].items()
                                         if key.startswith('core/')} or
            not core.get('core_source_inputs') or core.get('source_head') != metadata['source_head'] or
            core.get('submodule_head') != metadata['core_submodule_head'] or
            core.get('go_buildinfo_sha256') != hashes['core-buildinfo.txt'] or
            core.get('fresh_go_build_command') is not True):
        raise ValueError('Fresh Core compile/source binding mismatch')
    result = documents['build-result.json']
    if (result.get('status') != 'static-build-and-gui-stage-passed' or
            result.get('source_unchanged') is not True or
            result.get('sdk_unchanged') is not True or
            result.get('archived_generated_outputs_preserved') is not True or
            result.get('all_prior_artifacts_evidence_tools_preserved') is not True or
            any(result.get(key) is not False for key in (
                'runtime_acceptance', 'actualGUIloads', 'packaging_accepted', 'private_key_signing_performed')) or
            documents['preservation-before.json'] != freeze['protected'] or
            documents['preservation-after.json'] != freeze['protected']):
        raise ValueError('Fresh build result/preservation mismatch')
    unsigned = project_unsigned(documents['unsigned-stage-inventory.json'],
                                documents['candidate-file-manifest.json'],
                                documents['macho-inventory.json'], targets, fixed)
    if (documents['unsigned-pre-sign-inventory.json'] != unsigned or report.get('before') != unsigned or
            metadata.get('unsigned_tree_sha256') != unsigned['tree_sha256']):
        raise ValueError('Signing did not start from exact frozen fresh unsigned GUI')
    fixed.check_signing_delta(unsigned['entries'], report['after']['entries'], targets)
    return {'metadata_sha256': metadata_hash, 'source_freeze_sha256': hashes['input-freeze.json'],
            'source_head': metadata['source_head'], 'source_status': metadata['source_status'],
            'evidence_sha256': hashes, 'unsigned_tree_sha256': unsigned['tree_sha256']}


def exact_targets(targets):
    expected = {'Contents/MacOS/FlClashCore', 'Contents/MacOS/Flash'} | {
        f'Contents/Frameworks/{name}.framework/Versions/A/{name}'
        for name in ('App', 'FlutterMacOS', 'objective_c', 'rust_api', 'sqlite3')}
    if len(targets) != 7 or {target['binary'] for target in targets} != expected:
        raise ValueError('Only Core, five frameworks and GUI are permitted')


def preflight_unsigned(app=GUI_APP, metadata_path=BUILD_METADATA):
    metadata_pin()
    _, signer, _, fixed = dependencies()
    sources = source_state(fixed)
    app = fixed.staging_path(str(app))
    if app != GUI_APP or metadata_path != BUILD_METADATA or (app / 'Contents/Library').exists():
        raise ValueError('Only exact fresh GUI-only unsigned stage is permitted')
    metadata, metadata_hash = json_protected(metadata_path, fixed)
    info = plistlib.loads(read_protected(app / 'Contents/Info.plist', fixed))
    validate_metadata(metadata, info, fixed)
    verifier = fixed.trusted_verifier()
    entries = fixed.inventory(app, verifier)
    targets = signer.signing_targets(app, entries, 'gui', fixed)
    exact_targets(targets)
    signer.audit(app, 'gui', fixed, verifier, targets)
    report = {'before': {'tree_sha256': fixed.tree_digest(entries), 'entries': entries},
              'after': {'entries': entries}}
    provenance = build_provenance(metadata_path, metadata, metadata_hash, report, targets, fixed)
    if (fixed.inventory(app, verifier) != entries or source_state(fixed) != sources or
            json_protected(metadata_path, fixed)[1] != metadata_hash):
        raise ValueError('Unsigned inputs changed during static preflight')
    return {'schema': 'flash-relay-unsigned-preflight-2026111304-v1', 'app': str(app),
            'static_verification': True, 'actualGUIloads': False, 'runtime_acceptance': False,
            'packaging_accepted': False, 'signing_performed': False, 'adapter': sources,
            'build_provenance': provenance, 'unsigned': report['before'], 'targets': targets}


def attempt_value(adapter_hash):
    return {'schema': 'flash-relay-one-attempt-2026111304-v1', 'approval': APPROVAL,
            'app': str(GUI_APP), 'build_metadata': str(BUILD_METADATA),
            'build_metadata_sha256': BUILD_METADATA_SHA256, 'evidence': str(EVIDENCE),
            'adapter_path': str(SELF), 'adapter_sha256': adapter_hash,
            'frozen_imports_sha256': PINS}


def validate_attempt(fixed, adapter_hash):
    value, marker_hash = json_protected(ATTEMPT, fixed)
    if value != attempt_value(adapter_hash):
        raise ValueError('Missing/stale one-attempt adapter binding')
    return marker_hash


def evidence_location(path, legacy, fixed):
    if path != EVIDENCE:
        raise ValueError('Only fixed fresh relay-2026111304-user2951 evidence is allowed')
    legacy.canonical(str(EVIDENCE_ROOT))
    check_ancestors(EVIDENCE_ROOT, fixed)
    fixed.check_directory(EVIDENCE_ROOT)
    return path


def run_approved(app, metadata, evidence, parent_go, adapter_sha256):
    metadata_pin()
    if (app != GUI_APP or metadata != BUILD_METADATA or evidence != EVIDENCE or
            parent_go != APPROVAL or not sha_value(adapter_sha256)):
        raise ValueError('Exact inputs and explicit parent invocation are required')
    split, _, legacy, fixed = dependencies()
    if source_state(fixed)['adapter_sha256'] != adapter_sha256:
        raise ValueError('Parent-approved adapter hash mismatch')
    evidence_location(evidence, legacy, fixed)
    if evidence.exists() or evidence.is_symlink():
        raise ValueError('Evidence already exists; no retry')
    fd = os.open(ATTEMPT, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w') as stream:
        legacy.save(stream, attempt_value(adapter_sha256))
    split.evidence_location = evidence_location
    return split.run_approved(app, metadata, evidence)


def verify(app=GUI_APP, metadata=BUILD_METADATA, evidence=EVIDENCE):
    metadata_pin()
    if app != GUI_APP or metadata != BUILD_METADATA or evidence != EVIDENCE:
        raise ValueError('Only exact fresh relay evidence may be verified')
    split, _, legacy, fixed = dependencies()
    evidence_location(evidence, legacy, fixed)
    split.evidence_location = evidence_location
    return split.verify(app, metadata, evidence)


def main():
    if not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode) or os.getuid() == 0:
        print('Use non-root /usr/bin/python3 -I -S -B.', file=sys.stderr)
        return 1
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--preflight-unsigned', action='store_true')
    modes.add_argument('--verify-evidence', action='store_true')
    modes.add_argument('--run-approved', action='store_true')
    parser.add_argument('--app', default=str(GUI_APP), choices=(str(GUI_APP),))
    parser.add_argument('--build-metadata', default=str(BUILD_METADATA), choices=(str(BUILD_METADATA),))
    parser.add_argument('--evidence', default=str(EVIDENCE), choices=(str(EVIDENCE),))
    parser.add_argument('--parent-go')
    parser.add_argument('--parent-approved-adapter-sha256')
    args = parser.parse_args()
    try:
        if not args.run_approved and (args.parent_go or args.parent_approved_adapter_sha256):
            raise ValueError('Approval options are for the parent-owned run only')
        if args.preflight_unsigned:
            result = preflight_unsigned(Path(args.app), Path(args.build_metadata))
        elif args.verify_evidence:
            result = verify(Path(args.app), Path(args.build_metadata), Path(args.evidence))
        else:
            result = run_approved(Path(args.app), Path(args.build_metadata), Path(args.evidence),
                                  args.parent_go, args.parent_approved_adapter_sha256)
    except (ValueError, OSError, KeyError, TypeError, subprocess.SubprocessError) as error:
        print('Relay qualification failed closed: ' + str(error), file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True, indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())
