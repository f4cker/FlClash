#!/bin/bash
set -euo pipefail
export PATH="$HOME/.cargo/bin:$HOME/fvm/versions/3.47.4/bin:/opt/homebrew/bin:/opt/homebrew/go/bin:$PATH"
cd /Users/layoute/SideWork/FlClash/.airbuild/worktree/r6b
[[ -z "$(/usr/bin/git status --porcelain)" ]]
HEAD=$(/usr/bin/git rev-parse HEAD)
APP="$PWD/build/macos/Build/Products/Release/Flash.app"
rm -rf "$APP" .dart_tool/setup_build_cache
printf '{"APP_ENV":"stable"}\n' > env.json
flutter build macos --release --dart-define-from-file=env.json
codesign --verify --deep --strict "$APP"
P="$APP/Contents/Info.plist"
[[ "$(plutil -extract CFBundleShortVersionString raw "$P")" = 0.9.5 ]]
[[ "$(plutil -extract CFBundleVersion raw "$P")" = 2026111202 ]]
[[ "$(plutil -extract CFBundleIdentifier raw "$P")" = com.layoute.flash ]]
plutil -extract NSHumanReadableCopyright raw "$P"
go version -m "$APP/Contents/MacOS/FlClashCore" > /tmp/r6b_core_buildinfo.log
grep -F "vcs.revision=$HEAD" /tmp/r6b_core_buildinfo.log
grep -F 'vcs.modified=false' /tmp/r6b_core_buildinfo.log
TMP=$(mktemp -d /tmp/flash095.XXXXXX)
MNT="$TMP/mount"; mkdir "$MNT"
ATTACHED=0
cleanup() {
 if [[ "$ATTACHED" == 1 ]]; then hdiutil detach "$MNT" -quiet || true; fi
 rm -rf "$TMP"
}
trap cleanup EXIT
hdiutil convert "$HOME/Downloads/Flash-0.9.4-macos-arm64.dmg" -format UDRW -o "$TMP/rw.dmg" -quiet
hdiutil attach "$TMP/rw.dmg" -readwrite -nobrowse -mountpoint "$MNT" -quiet
ATTACHED=1
rm -rf "$MNT/Flash.app"
ditto "$APP" "$MNT/Flash.app"
chmod -R a+rX "$MNT/Flash.app"
[[ "$(readlink "$MNT/应用程序")" = /Applications ]]
rm -rf "$MNT/.fseventsd"
codesign --verify --deep --strict "$MNT/Flash.app"
hdiutil detach "$MNT" -quiet; ATTACHED=0
hdiutil convert "$TMP/rw.dmg" -format UDZO -imagekey zlib-level=9 -o "$TMP/final.dmg" -quiet
hdiutil verify "$TMP/final.dmg"
hdiutil attach "$TMP/final.dmg" -readonly -nobrowse -mountpoint "$MNT" -quiet; ATTACHED=1
codesign --verify --deep --strict "$MNT/Flash.app"
[[ "$(plutil -extract CFBundleShortVersionString raw "$MNT/Flash.app/Contents/Info.plist")" = 0.9.5 ]]
cmp "$MNT/Flash.app/Contents/MacOS/FlClashCore" "$APP/Contents/MacOS/FlClashCore"
[[ -f "$MNT/.DS_Store" && -f "$MNT/.background/background.tiff" ]]
hdiutil detach "$MNT" -quiet; ATTACHED=0
OUT="$HOME/Downloads/Flash-0.9.5-macos-arm64.dmg"
[[ ! -e "$OUT" ]]
cp "$TMP/final.dmg" "$OUT"
chmod 644 "$OUT"
shasum -a 256 "$OUT"
stat -f '%z bytes' "$OUT"
echo "BUILD_HEAD=$HEAD"
echo "DELIVERY=$OUT"
