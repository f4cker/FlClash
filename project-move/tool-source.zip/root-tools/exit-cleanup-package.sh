#!/bin/bash
set -euxo pipefail
cd /Users/layoute/SideWork/FlClash/.airbuild/worktree/exit-cleanup
HEAD=$(/usr/bin/git rev-parse HEAD)
APP="$PWD/build/macos/Build/Products/Release/Flash.app"
TMP=$(mktemp -d /tmp/flash096.XXXXXX)
MNT="$TMP/mount"; mkdir "$MNT"
ATTACHED=0
cleanup() {
 if [[ "$ATTACHED" == 1 ]]; then hdiutil detach "$MNT" -quiet || true; fi
 rm -rf "$TMP"
}
trap cleanup EXIT
hdiutil convert "/Users/layoute/SideWork/FlClash/.airbuild/artifacts/Flash-0.9.5-template.dmg" -format UDRW -o "$TMP/rw.dmg" -quiet
hdiutil attach "$TMP/rw.dmg" -readwrite -noautoopen -nobrowse -mountpoint "$MNT" -quiet
ATTACHED=1
rm -rf "$MNT/Flash.app"
ditto "$APP" "$MNT/Flash.app"
chmod -R a+rX "$MNT/Flash.app"
[[ "$(readlink "$MNT/应用程序")" = /Applications ]]
rm -rf "$MNT/.fseventsd"
codesign --verify --deep --strict "$MNT/Flash.app"
hdiutil detach "$MNT" -quiet; ATTACHED=0
hdiutil convert "$TMP/rw.dmg" -format UDZO -imagekey zlib-level=9 -o "$TMP/final.dmg" -quiet
hdiutil verify "$TMP/final.dmg"
hdiutil attach "$TMP/final.dmg" -readonly -noautoopen -nobrowse -mountpoint "$MNT" -quiet; ATTACHED=1
codesign --verify --deep --strict "$MNT/Flash.app"
[[ "$(plutil -extract CFBundleShortVersionString raw "$MNT/Flash.app/Contents/Info.plist")" = 0.9.6 ]]
cmp "$MNT/Flash.app/Contents/MacOS/FlClashCore" "$APP/Contents/MacOS/FlClashCore"
[[ -f "$MNT/.DS_Store" && -f "$MNT/.background/background.tiff" ]]
hdiutil detach "$MNT" -quiet; ATTACHED=0
OUT="$HOME/Downloads/Flash-0.9.6-macos-arm64.dmg"
[[ ! -e "$OUT" ]]
cp "$TMP/final.dmg" "$OUT"
chmod 644 "$OUT"
shasum -a 256 "$OUT"
stat -f '%z bytes' "$OUT"
echo "BUILD_HEAD=$HEAD"
echo "DELIVERY=$OUT"
